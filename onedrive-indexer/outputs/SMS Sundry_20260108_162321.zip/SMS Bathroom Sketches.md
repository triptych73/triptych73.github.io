# Source: SMS Bathroom Sketches.pdf [PDF]
**Path:** `SMS Bathroom Sketches.pdf`
---

### Page 1

[IMAGE CONTENT - REQUIRES OCR]