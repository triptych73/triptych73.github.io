# Source: Part F - 5 Lambeth Hill.pdf [PDF]
**Path:** `Part F - 5 Lambeth Hill.pdf`
---

### Page 1

Part 1 — System details and declarations
The &btall« mild tHs details of tip 
Dwelling rume/rumber
Street
Cnter •run—al extrxt «ntdation• •as 
rgrrbers
Serial rurbet *Owe)
of 'ants
2.
4.
O Eut&ioa
Address tire
Address tir*
1-4 to L))
A&fess tine 1
Ad&ess 2
•d&ess
•NOTE Mo system f.
fun
ONLINE VERSIONi
«vrrer.
F.
43


### Page 2

Part 2a — Installation details
The installer should complete this section before con-missioning is carried out.
2a-1 &æcHist — WI
Has system bem installed in accordance with the rnanufacture" requirenpnts? Yes
Have paragraphs 1.12 to 1.830 besi followed (if relevant)?
If there are
deviations from
paragraphs 1.12 to 183.
give details here
Description of installed
controls (e.g. timer,
central control.
humidistat, occuparry
sensor, thermal bypass,
if applicable. etc.)
Location of manual/
cmtrols
2a-2
Signature
Registr*im runber (if
Date of inspectim
NOTE
All references to tåles md par.aphs «e to Awoved [harnent F, Voltrne l: Dwellings.
44
ONLINE VERSION


### Page 3

ERS ION
Part 2b — Inspection of installation
The corrvnissimc awrer should cornplete this section before completing Part 3.
2bJ y*ans)
What is tte total installed ecuivalent area of backgrourxi ventilators in the dwelling?
What is total floor area of the dwelling?
Does the total installed equivalent ventilator area standards &tailed in
paragraph 1.570, as
Have all backgrcxjnd ventilaors left in the open position?
Have the correct runber and location extract fans/terminals been installed to satisfy
the staMards in Table IJ Table 1.2, as appropriate?
Is the installatim convlete, with no obvicx•s defects?
Do all internal doors have 6'10ugh tndercut to allow air transfer between roorns as
detailed paragraph 1.25 (Le- IOrnm above the floor friish or 20mrn above the floor
surface)?
Has all protection/packaging been removed (including frcxn background ventilators). so
that the system is fully fimctional?
Are systems clem internally and externally?
Has the entire system beel hstalled to allow access for routire maintenance arxi to
appropriate air terminal &vices been installed to allow system balance?
FOvetheheatrecoverymitand all dcrtworkbeeneffectively insulatedandsealedforall 
heated arxi unheated spaces?
Is cmdensate ccyvrctW1 cMnplete and does the cond«wate drain to an 
locatim (rnech&lical vavtil*ion with heat recovery a$•)?
Are fitters installed?
For syst«ns. has ttr åKtwork been installed so ttut air resistance and is 
400
Yes
Yes
with heat
Yes V/ No
YB No V/
Yesducted 
kept to a
b.3 Ott— 
At initial start—tv, was 
During continuous 
NOTE
l. All references to 
L-owEk SCOT IQ A
20
R.Aatm 200
"tens)
any abnormal sound or vibration, or unusual
was there any excessive noise?
are to Approved Doctrnent F, Volt.rne l: Dwellings.
tv-WH
45
ONLINE VER ION


### Page 4

Part 3 — Commissioning details
The commissioning engineer sh(XJld conplete this section after completing Part 2b.
Schedule of air flow measurement equiprnent used (mo&l and serial number) Date of last UKAS calibration
7-€sm I
2.
3.
32 extr«t
Fan refererxe 1.2 abm•e) Measured extract rate (l/s) extract rate (IVs)
Refer to Table 1.1m
Extract fan 1 (T O
Extract fan 2
Extract fan 3
Extract fan 4
For cooker hoods. only the highest setting needs to be recorded.
33 
Rocm ref«ence Meaqred air flow —
(locaticn of terminals) high (Vs)
Kitchen l'
Bathroom 243
En qjite
Utility
3.4 — 
ref«ence Maswed air flow —
(location of terminals) high (Vs)
Living room 1 F
Living roorn 2
Dining room
Bedroom 1 R )
Bedroom 2
Bedroom 3
Bedroorn 4
Bedroom 5
Study
3S
Engineer's signature
Registration runber (if
Date of commissicxüig
Nore
Design air flow — high 
rate
Refer to Table 12
with
Design air flow— high 
rate (IVs)
Refer to Table 1.2
Measured airflow — 
continuous rate (IVs) 
Measured üflow— 
cmtinuous rate (l/s) 
1. All ref«mcg to tables md to Approved Document F. Voltme l: Dwellings.
with
Design air flow —
cmtirunus rate (Vs) Q-.sels
Refer to Table 1.3
Design air flow —
cmtinuous rate (l/s)
Refer to Table 1.3
46 2021 2010
ONLINE VERSION


### Page 5

Table DI Checklist for ventila€m povision existing dwellings
What is the total equivalent area of backgromd ventilators currently in dwelling? 3
Doe each habitable room satisfy •.he minimum equivalent area in Table 1.10?
Have all 
Are fans 
Are 
valtilators been left jn the open position?
bEkgrand in same rocm at least 0.9n apart?
*ItarnittÜ't extract fans in all wet rooms?
Is 
Does 
Do all 
Does 
Do tir 
ru.rnber of extract fans to satisfy the standards in Table 1.1?
of fans satisW the standards in paragraph 1.20?
cmtrols have a rnanual override?
a syst«n fry purge ventilation (e.g. windows)?
in tie rooms the rninirnum opering area standards in Table 1.4?
DO all internal urdercut to allow air transfer between roorns as deOiled
in 1.25 (i.e. above the floor finish or 20rnrT1 above the floor surface)?
Continuous mechanical extract ventilation"
Dos "tan hwe a catral extract fan. individual roorn extract fans. or
Dæs the total rate of rnechanial extract æntilation satisfy the
standuds Table 13?
Does mhirmz•n extract ventilation high rate satisfr the
Is it that there are ventilators in wet
Do all ro«tv a equival of 5000mmZ?
Does each room have a systan fcx lation (e.g. windows)?
in Table 1.2?
Do the openirv in satisfy ttr rninirnum opening area standards in Table 1.4?
•
Do all ur&rcut to allow air transfer between rocrns as detailed
in 1-25 (iz above the floor finish or 20rnrn above tip floor surface)?
Mechanical ventilation with heat recoveryO)
Dos each habitable have rrrchanical supply ventilation?
Does the total cmtirunus rate Of mechanical ventilation with heat recovery satisfy the
standards Table 1.3?
Does euh minitrugn extract ventilation high rate satisfy the standards in Taue 1.2?
Have all backgrouu:i ventilators been removed or sealed shut?
Does roam a systan purge ventilation (e.g. windcms)?
Do the in roans satisfy the minimum opening area standards in Table 1.4?
Do all internal st%cient urdercut to allow air transfer between ro«ns as detailed
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes /
Yes
Yes
Yes
Yes 
rnma
No
No
No
No
No
No
No
No
No
No
in paragaph 1.25 (i.e. 10nrn above the floor finish or 20rnm above the floor surface)?
1. a visa-RI check cor&nsation. If either are install additbnal ventilatim provisions or
seek specialist advice.
Z All are to Approved Docurrmt F. Volurne 1:
48
ONLINE VERsiON
2010
