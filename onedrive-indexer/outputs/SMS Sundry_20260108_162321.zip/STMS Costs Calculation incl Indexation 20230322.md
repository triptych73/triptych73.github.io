# Source: STMS Costs Calculation incl Indexation 20230322.xlsx [EXCEL]
**Path:** `STMS Costs Calculation incl Indexation 20230322.xlsx`
---

## Sheet: COSTS WORKSHEET
|   Unnamed: 0 | Unnamed: 1   | Unnamed: 2   | Unnamed: 3     | Unnamed: 4    | "costs"/debt basis   | Unnamed: 6         | fixed asset basis                  | Unnamed: 8         | FROM PIVOT         | Unnamed: 10        | Unnamed: 11        | Unnamed: 12        | Unnamed: 13                        |
|-------------:|:-------------|:-------------|:---------------|:--------------|:---------------------|:-------------------|:-----------------------------------|:-------------------|:-------------------|:-------------------|:-------------------|:-------------------|:-----------------------------------|
|          nan | fixed assets | creditors    | current assets | cumul "costs" | annual "costs"       | indexed            | annual expense                     | indexed            | annual cost        | cumul              | indexed costs      | cumul              | nan                                |
|         2004 | nan          | nan          | nan            | nan           | nan                  | nan                | nan                                | nan                | 60776.1            | 60776.1            | 89947.58063443548  | 89947.58063443548  | nan                                |
|         2005 | nan          | nan          | nan            | nan           | nan                  | nan                | nan                                | nan                | 163459.05          | 224235.15          | 236655.82169335996 | 326603.40232779545 | nan                                |
|         2006 | 248492       | 248922       | 3              | 248919        | 248919               | 427597.8581524483  | 248492                             | 426864.34931852604 | 175968.82999999996 | 400203.98          | 246193.17308890662 | 572796.5754167021  | nan                                |
|         2007 | 248492       | 248922       | 3              | 248919        | 0                    | 0                  | 0                                  | 0                  | 153026.72999999995 | 553230.71          | 206511.65402537558 | 779308.2294420777  | nan                                |
|         2008 | 333390       | 609213       | 259613         | 349600        | 100681               | 159505.3272811918  | 84898                              | 134500.88175046555 | 259172.18          | 812402.8899999999  | 333387.79690186464 | 1112696.0263439424 | nan                                |
|         2009 | 907896       | 932760       | 23350          | 909410        | 559810               | 891452.2367805336  | 574506                             | 914854.430510061   | 322261.67000000004 | 1134664.56         | 424242.98275622784 | 1536939.0091001703 | nan                                |
|         2010 | 1002319      | 1029806      | 24801          | 1005005       | 95595                | 145487.38148479428 | 94423                              | 143703.6981216458  | 18869.65           | 1153534.21         | 23514.071200828315 | 1560453.0803009986 | nan                                |
|         2011 | 1006272      | 1019058      | 9421           | 1009637       | 4632                 | 6701.826530612246  | 3953                               | 5719.412840136055  | 1614               | 1155148.21         | 1913.9180007365867 | 1562366.9983017351 | nan                                |
|         2012 | 1006272      | 999672       | 15867          | 983805        | -25832               | -36220.14668314792 | 0                                  | 0                  | 0                  | 1155148.21         | 0                  | 1562366.9983017351 | nan                                |
|         2013 | 1009340      | 989299       | 25849          | 963450        | -20355               | -27696.14754098361 | 3068                               | 4174.491803278689  | 0                  | 1155148.21         | 0                  | 1562366.9983017351 | nan                                |
|         2014 | 1019665      | 1036943      | 17278          | 1019665       | 56215                | 74726.423828125    | 10325                              | 13724.990234375    | 69404.44           | 1224552.65         | 75405.29686865931  | 1637772.2951703945 | nan                                |
|         2015 | 1103510      | 1072797      | 23422          | 1049375       | 29710                | 39111.462282398454 | 83845                              | 110376.99613152805 | 92229.34000000005  | 1316781.99         | 99220.71113910353  | 1736993.006309498  | nan                                |
|         2016 | 1197179      | 1244627      | 77304          | 1167323       | 117948               | 152556.83922462942 | 93669                              | 121153.78449258837 | 182919.56          | 1499701.55         | 193419.85072783066 | 1930412.8570373286 | nan                                |
|         2017 | 1348067      | 1365226      | 13589          | 1351637       | 184314               | 230172.67596330275 | 150888                             | 188430.0418348624  | 154868.1699999999  | 1654569.72         | 158359.21040864306 | 2088772.0674459718 | nan                                |
|         2018 | 1376337      | 1495675      | 16848          | 1478827       | 127190               | 127190             | 28270                              | 28270              | 135661.79000000012 | 1790231.51         | 135661.79000000012 | 2224433.857445972  | nan                                |
|         2019 | 1378924      | 1557150      | 8984           | 1548166       | 69339                | 69339              | 2587                               | 2587               | 80405.89000000007  | 1870637.4000000001 | 80405.89000000007  | 2304839.747445972  | nan                                |
|         2020 | 1378923      | 1618877      | 15531          | 1603346       | 55180                | 55180              | -1                                 | -1                 | 41303.94000000004  | 1911941.34         | 41303.94000000004  | 2346143.687445972  | nan                                |
|         2021 | 1378923      | 1639681      | 6214           | 1633467       | 30121                | 30121              | 0                                  | 0                  | 109098.38          | 2021039.7200000002 | 109098.38          | 2455242.067445972  | nan                                |
|         2022 | 1378923      | 2063724      | 313012         | 1750712       | 117245               | 117245             | 0                                  | 0                  | 163720.5500000001  | 2184760.2700000005 | 163720.5500000001  | 2618962.6174459723 | nan                                |
|         2023 | nan          | nan          | nan            | nan           | nan                  | nan                | nan                                | nan                | 22825.770000000004 | 2207586.0400000005 | 22825.770000000004 | 2641788.3874459723 | nan                                |
|          nan | nan          | nan          | nan            | nan           | nan                  | 2462470.7373039043 | including the 260k in cash now 260 | nan                | nan                | nan                | nan                | 2901788.387445971  | including the 260k in cash now 260 |

---

## Sheet: FULL TANSACTIONAL
| Data Source   |   D | M   |    Y | Date                | Description             |    Debits |   Credits |   Balance |   Incurred Costs |      Indexed | Company                | Lookup Debit                               | Unnamed: 14            | Unnamed: 15         |   Unnamed: 16 | Unnamed: 18   | Unnamed: 19                                                 |
|:--------------|----:|:----|-----:|:--------------------|:------------------------|----------:|----------:|----------:|-----------------:|-------------:|:-----------------------|:-------------------------------------------|:-----------------------|:--------------------|--------------:|:--------------|:------------------------------------------------------------|
| Matrix        |  21 | JUN | 2004 | 2004-06-21 00:00:00 | CB201                   |  11225    |       nan |    nan    |         11225    | 16711.3      | Willingale Associates  | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  28 | JUN | 2004 | 2004-06-28 00:00:00 | CB205                   |    150    |       nan |    nan    |           150    |   223.314    | Associated Consult.    | Company Formation                          | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              | Services Ltd           |                                            |                        |                     |               |               |                                                             |
| Matrix        |   8 | NOV | 2004 | 2004-11-08 00:00:00 | CB216                   |   4241.75 |       nan |    nan    |          4241.75 |  6241.43     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  30 | SEP | 2004 | 2004-09-30 00:00:00 | CB149                   |   4911.5  |       nan |    nan    |          4911.5  |  7261.5      | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  30 | SEP | 2004 | 2004-09-30 00:00:00 | CB221                   |   1902.24 |       nan |    nan    |          1902.24 |  2812.4      | RPS                    | Heritage Chris Miele                       | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  10 | JUN | 2004 | 2004-06-10 00:00:00 | CB224                   |   5619.32 |       nan |    nan    |          5619.32 |  8365.81     | Boyarsky Murphy ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  21 | OCT | 2004 | 2004-10-21 00:00:00 | CB227                   |    705    |       nan |    nan    |           705    |  1039.56     | Locke Carey & Assoc    | Fire Safety Engineer                       | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  11 | JAN | 2004 | 2004-01-11 00:00:00 | CB229                   |   1175    |       nan |    nan    |          1175    |  1784.64     | RPS                    | Heritage Chris Miele                       | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   7 | JUN | 2004 | 2004-06-07 00:00:00 | CB210                   |   4284.05 |       nan |    nan    |          4284.05 |  6377.91     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  12 | OCT | 2004 | 2004-10-12 00:00:00 | CB241                   |  11225    |       nan |    nan    |         11225    | 16551.8      | Willinoale Associates  | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  12 | DEC | 2004 | 2004-12-12 00:00:00 | CB243                   |   1468.75 |       nan |    nan    |          1468.75 |  2150.92     | Locke Carey & Assoc    | Fire Safety Engineer                       | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  14 | DEC | 2004 | 2004-12-14 00:00:00 | CB247                   |   4150.36 |       nan |    nan    |          4150.36 |  6078.02     | Alan Baxter & Assoc.   | Structural Engineer                        | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   1 | AUG | 2005 | 2005-08-01 00:00:00 | CB250                   |   1266.06 |       nan |    nan    |          1266.06 |  1828.1      | RPS                    | Heritage Chris Miele                       | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   1 | AUG | 2005 | 2005-08-01 00:00:00 | CB252                   |   4200.62 |       nan |    nan    |          4200.62 |  6065.38     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  11 | OCT | 2004 | 2004-10-11 00:00:00 | CB233                   |   4846.88 |       nan |    nan    |          4846.88 |  7146.96     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  12 | SEP | 2004 | 2004-09-12 00:00:00 | CB237                   |   4871.25 |       nan |    nan    |          4871.25 |  7201.99     | Boyarsky Murphy ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   2 | JUL | 2005 | 2005-07-02 00:00:00 | CB257                   |    352.5  |       nan |    nan    |           352.5  |   510.043    | Locke Carey & Assoc    | Fire Safety Engineer                       | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   2 | JUL | 2005 | 2005-07-02 00:00:00 | CB259                   |   4670.62 |       nan |    nan    |          4670.62 |  6758.06     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  14 | FEB | 2005 | 2005-02-14 00:00:00 | CB261                   |   3365.2  |       nan |    nan    |          3365.2  |  4935.98     | Greenwood              | Planning                                   | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              | Development Planning   |                                            |                        |                     |               |               |                                                             |
| Matrix        |  19 | FEB | 2005 | 2005-02-19 00:00:00 | CB262                   |    264.26 |       nan |    nan    |           264.26 |   387.609    | RPS                    | Heritage Chris Miele                       | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   3 | JUL | 2005 | 2005-07-03 00:00:00 | CB268                   |   5106.55 |       nan |    nan    |          5106.55 |  7388.82     | Boyarsky Murphy ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  17 | MAR | 2005 | 2005-03-17 00:00:00 | CB272                   |    974.08 |       nan |    nan    |           974.08 |  1422        | RPS                    | Heritage Chris Miele                       | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  20 | MAR | 2005 | 2005-03-20 00:00:00 | CB273                   |   9242.01 |       nan |    nan    |          9242.01 | 13491.9      | Alan Baxter & Assoc.   | Structural Engineer                        | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  20 | MAR | 2005 | 2005-03-20 00:00:00 | CB275                   |   4974    |       nan |    nan    |          4974    |  7261.26     | Greenwood              | Planning                                   | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              | Development Plannino   |                                            |                        |                     |               |               |                                                             |
| Matrix        |   4 | JUN | 2005 | 2005-06-04 00:00:00 | CB278                   |  11225    |       nan |    nan    |         11225    | 16241.8      | Willinoale Associates  | Final Payment                              | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  14 | APR | 2005 | 2005-04-14 00:00:00 | CB280                   |   3055    |       nan |    nan    |          3055    |  4434.21     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  14 | APR | 2005 | 2005-04-14 00:00:00 | CB281                   |   4829.25 |       nan |    nan    |          4829.25 |  7009.47     | McDonnel Langley       | M&E Engineers                              | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   5 | MAY | 2005 | 2005-05-05 00:00:00 | a1119                   |   3301.75 |       nan |    nan    |          3301.75 |  4782.38     | Boyarsky Murphy ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  23 | MAY | 2005 | 2005-05-23 00:00:00 | a1124                   |    725.56 |       nan |    nan    |           725.56 |  1050.93     | Greenwood              | Planning                                   | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              | Development Planning   |                                            |                        |                     |               |               |                                                             |
| Matrix        |   6 | MAY | 2005 | 2005-05-06 00:00:00 | a1132                   |   4435.62 |       nan |    nan    |          4435.62 |  6424.72     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   6 | JUL | 2005 | 2005-07-06 00:00:00 | a1134                   |   1233.75 |       nan |    nan    |          1233.75 |  1785.15     | PT Projects            | QS                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   7 | OCT | 2005 | 2005-10-07 00:00:00 | a1144                   |   4448.62 |       nan |    nan    |          4448.62 |  6400.21     | Boyarsky Murphy ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  20 | AUG | 2005 | 2005-08-20 00:00:00 | a1153                   |      0    |       nan |    nan    |             0    |     0        | Greig-Ling             | Structural Engineer - lost 5753.62         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  24 | AUG | 2005 | 2005-08-24 00:00:00 | a1155                   |   4465    |       nan |    nan    |          4465    |  6447.13     | Boyarsky Murphy ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   9 | MAR | 2005 | 2005-03-09 00:00:00 | a1162                   |   4459.12 |       nan |    nan    |          4459.12 |  6509.61     | Boyarsky Murphy ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   9 | APR | 2005 | 2005-04-09 00:00:00 | a1163                   |      0    |       nan |    nan    |             0    |     0        | City of London         | License - Foundation Investigation         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | cxld 750                                   |                        |                     |               |               |                                                             |
| Matrix        |   9 | APR | 2005 | 2005-04-09 00:00:00 | a1164                   |    881.25 |       nan |    nan    |           881.25 |  1279.1      | City of London         | License - Foundation Investigation         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   9 | MAY | 2005 | 2005-05-09 00:00:00 | nan                     |    888.3  |       nan |    nan    |           888.3  |  1286.65     | JHAI                   | Approved Inspector                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  25 | SEP | 2005 | 2005-09-25 00:00:00 | c284                    |     30    |       nan |    nan    |            30    |    43.2056   | Companies House -      | Companies House annual filing              | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              | stms                   |                                            |                        |                     |               |               |                                                             |
| Matrix        |  11 | JUL | 2005 | 2005-07-11 00:00:00 | a1173                   |   4476.75 |       nan |    nan    |          4476.75 |  6477.55     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  11 | JUL | 2005 | 2005-07-11 00:00:00 | a1174                   |   1410    |       nan |    nan    |          1410    |  2040.17     | PT Projects            | QS                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  10 | JUL | 2005 | 2005-07-10 00:00:00 | a1179                   |   5758.44 |       nan |    nan    |          5758.44 |  8332.06     | Greio-Lino             | Structural Engineer                        | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  10 | NOV | 2005 | 2005-11-10 00:00:00 | a1182                   |   4465    |       nan |    nan    |          4465    |  6413.82     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  27 | NOV | 2005 | 2005-11-27 00:00:00 | a1188                   |  11867.5  |       nan |    nan    |         11867.5  | 17047.3      | oerard Huouenin        | Ground Works specialist                    | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  12 | JUN | 2005 | 2005-06-12 00:00:00 | a1201                   |   6043.62 |       nan |    nan    |          6043.62 |  8744.7      | Boyarsky Murphy ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  15 | JUN | 2005 | 2005-06-15 00:00:00 | nan                     |  45000    |       nan |    nan    |         45000    | 65111.9      | City of London         | STMS purchase - cheque to                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | Stella                                     |                        |                     |               |               |                                                             |
| Matrix        |   1 | JUN | 2006 | 2006-06-01 00:00:00 | a1197                   |   7344.69 |       nan |    nan    |          7344.69 | 10290        | Greig-Ling             | Structural Engineer (5753 +                | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | license fee)                               |                        |                     |               |               |                                                             |
| Matrix        |   1 | JUL | 2006 | 2006-07-01 00:00:00 | a1198                   |   5869.12 |       nan |    nan    |          5869.12 |  8222.68     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   1 | SEP | 2006 | 2006-09-01 00:00:00 | a1200                   |   4406.25 |       nan |    nan    |          4406.25 |  6123.83     | PT Projects            | QS - final payment                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  12 | JUN | 2005 | 2005-06-12 00:00:00 | a1201                   |   6043.62 |       nan |    nan    |          6043.62 |  8744.7      | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   2 | JUL | 2006 | 2006-07-02 00:00:00 | a1208                   |   6423.5  |       nan |    nan    |          6423.5  |  8999.37     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   2 | SEP | 2006 | 2006-09-02 00:00:00 | a1210                   |      0    |       nan |    nan    |             0    |     0        | Greig-Ling             | Pl Insurance for Eng. Returned             | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | £5,875                                     |                        |                     |               |               |                                                             |
| Matrix        |   3 | MAR | 2006 | 2006-03-03 00:00:00 | a1215                   |   5875    |       nan |    nan    |          5875    |  8378.65     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  13 | MAR | 2006 | 2006-03-13 00:00:00 | a1218                   |   4112.5  |       nan |    nan    |          4112.5  |  5865.06     | Eckersley o' callaghan | Stair Designers                            | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  16 | MAR | 2006 | 2006-03-16 00:00:00 | a1219                   |   2820    |       nan |    nan    |          2820    |  4021.75     | City of London         | Fee- Foundation Investigation -            | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | SAID never received £2,820 BUT             |                        |                     |               |               |                                                             |
| Matrix        |  30 | APR | 2006 | 2006-04-30 00:00:00 | a1225                   |   4059.63 |       nan |    nan    |          4059.63 |  5745.46     | gerard Huguenin        | Foundation digging                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   4 | JUL | 2006 | 2006-07-04 00:00:00 | a1227                   |   5904.38 |       nan |    nan    |          5904.38 |  8272.08     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  20 | APR | 2006 | 2006-04-20 00:00:00 | a1234                   |    450    |       nan |    nan    |           450    |   636.87     | St Sepulcre            | Storage                                    | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  29 | APR | 2006 | 2006-04-29 00:00:00 | a1236                   |      0    |       nan |    nan    |             0    |     0        | gerard Huguenin        | further foundation investigation -         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | cxld as had no VAT £3,455                  |                        |                     |               |               |                                                             |
| Matrix        |   5 | APR | 2006 | 2006-04-05 00:00:00 | a1238                   |   6710.35 |       nan |    nan    |          6710.35 |  9496.94     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   5 | MAY | 2006 | 2006-05-05 00:00:00 | a1239                   |   3548    |       nan |    nan    |          3548    |  4990.89     | Stella Currie          | Solicitor for DA and Lease                 | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   5 | SEP | 2006 | 2006-09-05 00:00:00 | a1241                   |  30000    |       nan |    nan    |         30000    | 41694.2      | City of London         | to Stella Currie For Corporation           | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | legal fees                                 |                        |                     |               |               |                                                             |
| Matrix        |  22 | JUN | 2005 | 2005-06-22 00:00:00 | nan                     |    nan    |       nan |    nan    |             0    |     0        | Alan Baxter & Assoc.   | in dispute £14,523.92                      | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   8 | NOV | 2005 | 2005-11-08 00:00:00 | nan                     |    nan    |       nan |    nan    |             0    |     0        | Alan Baxter & Assoc.   | in dispute £5,532.98                       | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   6 | MAY | 2006 | 2006-05-06 00:00:00 | a1249                   |   6456.62 |       nan |    nan    |          6456.62 |  9082.38     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  13 | JUN | 2006 | 2006-06-13 00:00:00 | a1276                   |   9608.92 |       nan |    nan    |          9608.92 | 13462.2      | Greig-Ling             | Structural Engineer 5753.62 +              | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | fees                                       |                        |                     |               |               |                                                             |
| Matrix        |  25 | JUN | 2006 | 2006-06-25 00:00:00 | a1280                   |     30    |       nan |    nan    |            30    |    42.0302   | Companies House -      | admin cono.5160890                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              | stms                   |                                            |                        |                     |               |               |                                                             |
| Matrix        |   7 | APR | 2006 | 2006-04-07 00:00:00 | a1283                   |   6444.9  |       nan |    nan    |          6444.9  |  9121.26     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |   7 | AUG | 2006 | 2006-08-07 00:00:00 | a1286                   |   5998.47 |       nan |    nan    |          5998.47 |  8374.37     | Greig-Ling             | Structural Engineer - for ARUP             | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | Geotechnics                                |                        |                     |               |               |                                                             |
| Matrix        |  27 | JUL | 2006 | 2006-07-27 00:00:00 | a1289                   |  11836.5  |       nan |    nan    |         11836.5  | 16583.1      | Greig-Ling             | Structural Engineer - for ARUP Geotechnics | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  28 | JUL | 2006 | 2006-07-28 00:00:00 | a1290                   |    855.99 |       nan |    nan    |           855.99 |  1199.25     | McDonnel Langley       | mechanical electrical engineers            | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  30 | AUG | 2006 | 2006-08-30 00:00:00 | a1295                   |   5992.5  |       nan |    nan    |          5992.5  |  8366.04     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  25 | SEP | 2006 | 2006-09-25 00:00:00 | CB284                   |     30    |       nan |    nan    |            30    |    41.6942   | Companies House -      | admin cono.5160890                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              | stms                   |                                            |                        |                     |               |               |                                                             |
| Matrix        |   9 | MAY | 2006 | 2006-05-09 00:00:00 | CB297                   |   5857.37 |       nan |    nan    |          5857.37 |  8239.43     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  10 | JUN | 2006 | 2006-06-10 00:00:00 | CB315                   |   5838.87 |       nan |    nan    |          5838.87 |  8180.3      | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  11 | SEP | 2006 | 2006-09-11 00:00:00 | CB325                   |   2820    |       nan |    nan    |          2820    |  3919.25     | City of London         | STMS AIP                                   | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  11 | SEP | 2006 | 2006-09-11 00:00:00 | CB327                   |   5845.62 |       nan |    nan    |          5845.62 |  8124.27     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  30 | NOV | 2006 | 2006-11-30 00:00:00 | CB331                   |   3025.27 |       nan |    nan    |          3025.27 |  4183.63     | michael barclay        | Keith Jerimiah AIP / Highway               | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              | partnership            |                                            |                        |                     |               |               |                                                             |
| Matrix        |  20 | DEC | 2006 | 2006-12-20 00:00:00 | CB340                   |   6515.37 |       nan |    nan    |          6515.37 |  8938.95     | Boyarsky Murphy Ltd    | Architect                                  | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  17 | JAN | 2007 | 2007-01-17 00:00:00 | CB344                   |      0    |       nan |    nan    |             0    |     0        | Boyarsky Murphy Ltd    | Architect torn up not paid                 | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | £6,515.37                                  |                        |                     |               |               |                                                             |
| Matrix        |   2 | FEB | 2007 | 2007-02-02 00:00:00 | not paid                |      0    |       nan |    nan    |             0    |     0        | Boyarsky Murphy Ltd    | £1850.62 BMA overpaid already              | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  12 | NOV | 2006 | 2006-11-12 00:00:00 | CB 336                  |  10000    |       nan |    nan    |         10000    | 13828.9      | Alan Baxter & Assoc.   | Full and final settlement for              | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | STMS and CCT                               |                        |                     |               |               |                                                             |
| Matrix        |  18 | DEC | 2006 | 2006-12-18 00:00:00 | CB338                   |   1288.97 |       nan |    nan    |          1288.97 |  1768.44     | Birketts               | Lawyers                                    | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  29 | JAN | 2007 | 2007-01-29 00:00:00 | CB346                   |  10000    |       nan |    nan    |         10000    | 13794.6      | Khalid Aslam           | Consultant                                 | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  14 | FEB | 2007 | 2007-02-14 00:00:00 | CB 351                  |  55000    |       nan |    nan    |         55000    | 75310.2      | CPM Ltd                | Project Managers                           | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  23 | APR | 2007 | 2007-04-23 00:00:00 | CB352                   |   1776.6  |       nan |    nan    |          1776.6  |  2405.42     | JHAI                   | Approved Inspector                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Matrix        |  18 | MAY | 2007 | 2007-05-18 00:00:00 | nan                     |   2277.55 |       nan |    nan    |          2277.55 |  3071.71     | michael barclay        | AIP temp. Retaining wall                   | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              | partnership            |                                            |                        |                     |               |               |                                                             |
| Matrix        |   6 | JUN | 2007 | 2007-06-06 00:00:00 | CB378                   |     98.53 |       nan |    nan    |            98.53 |   132.181    | Boyarsky Murphy Ltd    | copying documents                          | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  11 | JUN | 2007 | 2007-06-11 00:00:00 | CB380                   |    nan    |     50000 |  50000    |             0    |     0        | nan                    | nan                                        | CPM Ltd                | 2007-02-14 00:00:00 |      55000    | cb 351        | Project Managers                                            |
| Statement     |  15 | JUN | 2007 | 2007-06-15 00:00:00 | 1                       |   7000    |       nan |  43000    |          7000    |  9390.74     | CPM Ltd                | Overage payment prof fees -                | CPM Ltd                | 2007-02-14 00:00:00 |          0    | cb352         | replaced by STMS Cheque £55k                                |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | Mgmt Contract                              |                        |                     |               |               | stms cb 22                                                  |
| Statement     |  19 | JUL | 2007 | 2007-07-19 00:00:00 | 2                       |   2511.56 |       nan |  40488.4  |          2511.56 |  3388.96     | WSP                    | CAD drawings - structural -                | JHAI                   | 2007-04-23 00:00:00 |       1776.6  | nan           | Approved Inspector                                          |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | NK2487                                     |                        |                     |               |               |                                                             |
| Statement     |  19 | JUL | 2007 | 2007-07-19 00:00:00 | 3                       |   5875    |       nan |  34613.4  |          5875    |  7927.4      | WSP                    | Architect                                  | michael barclay        | 2007-05-18 00:00:00 |       2277.55 | cb378         | AIP temp. Retaining wall                                    |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            | partnership            |                     |               |               |                                                             |
| Statement     |  25 | JUL | 2007 | 2007-07-25 00:00:00 | Charges                 |      1.06 |       nan |  34612.4  |             1.06 |     1.43031  | Clydesdale Bank        | Charges                                    | Boyarsky Murphy Ltd    | 2007-06-06 00:00:00 |         98.53 | cb380         | copying documents                                           |
| Statement     |   9 | AUG | 2007 | 2007-08-09 00:00:00 | 4                       |    100    |       nan |  34512.4  |           100    |   134.153    | HMRC                   | Late filing fee                            | CPM Ltd                | 2007-12-06 00:00:00 |       7000    | stms cb001    | Overage payment prof fees -                                 |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | Mgmt Contract                                               |
| Statement     |  17 | AUG | 2007 | 2007-08-17 00:00:00 | Charges                 |      1.06 |       nan |  34511.3  |             1.06 |     1.42203  | Clydesdale Bank        | Charges                                    | Khalid Aslam           | 2007-03-07 00:00:00 |       7000    | cb385         | nan                                                         |
| Statement     |  24 | AUG | 2007 | 2007-08-24 00:00:00 | Incara Ltd              |    nan    |     50000 |  84511.3  |             0    |     0        | CPM Ltd                | nan                                        | WSP                    | 2007-07-13 00:00:00 |       2511.56 | stms cb 002   | CAD drawings - structural -                                 |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | NK2487                                                      |
| Statement     |  19 | SEP | 2007 | 2007-09-19 00:00:00 | Charges                 |      1.06 |       nan |  84510.3  |             1.06 |     1.41724  | Clydesdale Bank        | Charges                                    | WSP                    | 2007-07-13 00:00:00 |       5875    | stms cb 003   | Architects fees -April/May -                                |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | LE494 AND LE476                                             |
| Statement     |  28 | SEP | 2007 | 2007-09-28 00:00:00 | 7                       |   6750    |       nan |  77760.3  |          6750    |  9024.88     | WSP                    | Desk Study, ex-Vat structural -            | HMRC                   | 2007-05-08 00:00:00 |        100    | stms cb 004   | Late filing fee                                             |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | NK2486                                     |                        |                     |               |               |                                                             |
| Statement     |  28 | SEP | 2007 | 2007-09-28 00:00:00 | 11                      |   5888.96 |       nan |  71871.3  |          5888.96 |  7873.65     | WSP                    | July Architect Fees ex Vat -               | WSP                    | 2007-09-17 00:00:00 |       4950    | stms cb 005   | Structural Survey ex-Vat Invoice                            |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | LE524                                      |                        |                     |               |               | NK2517                                                      |
| Statement     |   1 | OCT | 2007 | 2007-10-01 00:00:00 | 5                       |   4950    |       nan |  66921.3  |          4950    |  6589.73     | WSP                    | Structural Survey ex-Vat Invoice           | WSP                    | 2007-09-17 00:00:00 |        866.25 | stms cb 006   | Structural Survey Vat - NB2517                              |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | NK2517                                     |                        |                     |               |               |                                                             |
| Statement     |   3 | OCT | 2007 | 2007-10-03 00:00:00 | 15                      |   5052.5  |       nan |  61868.8  |          5052.5  |  6726.19     | Greenwood              | full & final settlement to date            | WSP                    | 2007-09-17 00:00:00 |       6750    | stms cb 007   | Desk Study, ex-Vat structural -                             |
|               |     |     |      |                     |                         |           |           |           |                  |              | Development Planning   | Planning                                   |                        |                     |               |               | NK2486                                                      |
| Statement     |  17 | OCT | 2007 | 2007-10-17 00:00:00 | Charges                 |      1.06 |       nan |  61867.7  |             1.06 |     1.41113  | Clydesdale Bank        | Charges                                    | WSP                    | 2007-09-17 00:00:00 |       1181.25 | stms cb 008   | Desk Study Vat structural-                                  |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | NK2486                                                      |
| Statement     |  18 | OCT | 2007 | 2007-10-18 00:00:00 | 6                       |    866.25 |       nan |  61001.5  |           866.25 |  1153.2      | WSP                    | Structural Survey Vat - NB2517             | WSP                    | 2007-09-17 00:00:00 |       5549.68 | stms cb 009   | June Architecture Fees ex Vat -                             |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | LE512A                                                      |
| Statement     |  18 | OCT | 2007 | 2007-10-18 00:00:00 | 8                       |   1181.25 |       nan |  59820.2  |          1181.25 |  1572.55     | WSP                    | Desk Study Vat structural-                 | WSP                    | 2007-09-17 00:00:00 |       1177.2  | stms cb 010   | June Architecture Fees Vat -                                |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | NK2486                                     |                        |                     |               |               | LE512A                                                      |
| Statement     |  18 | OCT | 2007 | 2007-10-18 00:00:00 | 9                       |   5549.68 |       nan |  54270.6  |          5549.68 |  7388.06     | WSP                    | June Architecture Fees ex Vat -            | WSP                    | 2007-09-17 00:00:00 |       5888.96 | stms cb 011   | July Architect Fees ex Vat -                                |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | LE512A                                     |                        |                     |               |               | LE524                                                       |
| Statement     |  18 | OCT | 2007 | 2007-10-18 00:00:00 | 10                      |   1177.2  |       nan |  53093.4  |          1177.2  |  1567.16     | WSP                    | June Architecture Fees Vat -               | WSP                    | 2007-09-17 00:00:00 |       1249.17 | stms cb 012   | July Architect Fees Vat - LE524                             |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | LE512A                                     |                        |                     |               |               |                                                             |
| Statement     |  18 | OCT | 2007 | 2007-10-18 00:00:00 | 12                      |   1249.17 |       nan |  51844.2  |          1249.17 |  1662.97     | WSP                    | July Architect Fees Vat - LE524            | WSP                    | 2007-09-17 00:00:00 |       3920    | stms cb 013   | half Aug Architect Fees ex Vat -                            |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | LE538                                                       |
| Statement     |  18 | OCT | 2007 | 2007-10-18 00:00:00 | 13                      |   3920    |       nan |  47924.2  |          3920    |  5218.54     | WSP                    | half Aug Architect Fees ex Vat -           | WSP                    | 2007-09-17 00:00:00 |        686    | stms cb 014   | Aug Architect Fees Vat - LE538                              |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | LE538                                      |                        |                     |               |               |                                                             |
| Statement     |  18 | OCT | 2007 | 2007-10-18 00:00:00 | 14                      |    686    |       nan |  47238.2  |           686    |   913.244    | WSP                    | Aug Architect Fees Vat - LE538             | Greenwood              | 2007-09-27 00:00:00 |       5052.5  | stms cb 015   | full & final settlement to date                             |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            | Development Planning   |                     |               |               | Planning                                                    |
| Statement     |  13 | NOV | 2007 | 2007-11-13 00:00:00 | 16                      |   7046.4  |       nan |  40191.8  |          7046.4  |  9344.8      | City of London         | Stopping up order                          | City of London         | 2007-04-11 00:00:00 |       7046.4  | stms cb 016   | Stopping up order                                           |
| Statement     |  15 | NOV | 2007 | 2007-11-15 00:00:00 | Incara Ltd              |    nan    |     50000 |  90191.8  |             0    |     0        | CPM Ltd                | nan                                        | WSP                    | 2007-05-11 00:00:00 |       3328.59 | stms cb 017   | Architects CAD conversion Inv NK2516 (half)                 |
| Statement     |  16 | NOV | 2007 | 2007-11-16 00:00:00 | 21                      |   3710.65 |       nan |  86481.1  |          3710.65 |  4920.99     | Birketts               | legal fees bma letters                     | WSP                    | 2007-06-11 00:00:00 |       3328.6  | stms cb 018   | Architects CAD conversion Inv                               |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | NK?516                                                      |
| Statement     |  19 | NOV | 2007 | 2007-11-19 00:00:00 | Charges                 |      4.77 |       nan |  86476.4  |             4.77 |     6.32588  | Clydesdale Bank        | Charges                                    | McDonnel Langley       | NaT                 |          0    | stms cb 019   | torn up                                                     |
| Statement     |  20 | NOV | 2007 | 2007-11-20 00:00:00 | 17                      |   3238.59 |       nan |  83237.8  |          3238.59 |  4294.95     | WSP                    | WSP - ?? Why duplicate                     | McDonnel Langley       | NaT                 |          0    | stms cb 020   | torn up                                                     |
| Statement     |  20 | NOV | 2007 | 2007-11-20 00:00:00 | 18                      |   3238.59 |       nan |  79999.2  |          3238.59 |  4294.95     | WSP                    | WSP - ?? Why duplicate                     | Birketts               | 2007-12-11 00:00:00 |       3710.65 | stms cb 021   | legal fees bma letters                                      |
| Statement     |  26 | NOV | 2007 | 2007-11-26 00:00:00 | 25                      |  11480    |       nan |  68519.2  |         11480    | 15224.5      | McDonnel Langley       | CPM Ltd for for M&E McDonnell              | CPM Ltd                | 2007-11-15 00:00:00 |          0    | stms cb 022   | £55K replacement cheque for cb 352 This has been returned & |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | langley                                    |                        |                     |               |               | 1"'.Ylrl                                                    |
| Statement     |  26 | NOV | 2007 | 2007-11-26 00:00:00 | 26                      |   2009    |       nan |  66510.2  |          2009    |  2664.3      | McDonnel Langley       | CPM for VAT on M&E                         | City of London         | 2007-11-15 00:00:00 |        380    | stms cb 023   | 12 mo. Hoarding license                                     |
| Statement     |  29 | NOV | 2007 | 2007-11-29 00:00:00 | 23                      |    380    |       nan |  66130.2  |           380    |   503.948    | City of London         | 12 mo. Hoarding license                    | vat blank fot topo     | 2007-11-15 00:00:00 |          0    | stms cb 024   | 750 fee plus vat 131.25                                     |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            | r , ·-                 |                     |               |               |                                                             |
| Statement     |  19 | DEC | 2007 | 2007-12-19 00:00:00 | Charges                 |      4.24 |       nan |  66126    |             4.24 |     5.59101  | Clydesdale Bank        | Charges                                    | McDonnel Langley       | 2007-11-15 00:00:00 |      11480    | stms cb 025   | CPM Ltd for for M&E McDonnell                               |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | langley                                                     |
| Statement     |  13 | FEB | 2008 | 2008-02-13 00:00:00 | 29                      |   4000    |       nan |  62126    |          4000    |  5262.06     | Khalid Aslam           | repay cash payments grd works              | McDonnel Langley       | 2007-11-15 00:00:00 |       2009    | stms cb 026   | CPM for VAT on M&E                                          |
| Statement     |  19 | FEB | 2008 | 2008-02-19 00:00:00 | Recvd Tower Loan        |    nan    |     50000 | 112126    |             0    |     0        | nan                    | nan                                        | vat for Topo survey    | 2007-11-15 00:00:00 |          0    | stms cb 027   | vat for topo - a duplicate??                                |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | 131.25 o/s                                                  |
| Statement     |  19 | FEB | 2008 | 2008-02-19 00:00:00 | Part Repay Loan         |  30000    |       nan |  82126    |             0    |     0        | nan                    | nan                                        | blank                  | NaT                 |          0    | stms cb 028   | Torn up                                                     |
| Statement     |  26 | FEB | 2008 | 2008-02-26 00:00:00 | 32                      |   1552.18 |       nan |  80573.8  |          1552.18 |  2041.92     | EDF                    | 3 phase 100 amp temp electric              | Khalid Aslam           | 2007-04-12 00:00:00 |       4000    | stms cb 029   | repay cash payments grd works                               |
| Statement     |   4 | MAR | 2008 | 2008-03-04 00:00:00 | L829192064000022        |     24    |       nan |  80549.8  |            24    |    31.4682   | nan                    | ??                                         | Thames Water           | 2007-04-12 00:00:00 |        117.5  | stms cb 030   | quotation fee                                               |
| Statement     |   4 | MAR | 2008 | 2008-03-04 00:00:00 | L829192064000022        |  10686.6  |       nan |  69863.2  |         10686.6  | 14012        | nan                    | WSP                                        | City of London         | 2008-01-24 00:00:00 |        380    | stms cb 031   | I year skip license                                         |
| Statement     |  19 | MAR | 2008 | 2008-03-19 00:00:00 | Charges                 |      2.12 |       nan |  69861    |             2.12 |     2.77969  | Clydesdale Bank        | Charges                                    | EDF                    | 2008-02-15 00:00:00 |       1552.18 | stms cb 032   | 3 phase 100 amp temp electric                               |
| Statement     |  17 | APR | 2008 | 2008-04-17 00:00:00 | Loan                    |    nan    |    100000 | 169861    |             0    |     0        | CPM Ltd                | nan                                        | Khalid Aslam           | 2008-03-19 00:00:00 |       8000    | cash          | for utilites connections, trenches                          |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | etc. Prelims.                                               |
| Statement     |  19 | MAY | 2008 | 2008-05-19 00:00:00 | Charges                 |      0.53 |       nan | 169861    |             0.53 |     0.68523  | Clydesdale Bank        | Charges                                    | WSP                    | 2008-03-03 00:00:00 |      10686.6  | cash xfer     | Birketts holding for o/s WSP                                |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | invoices NK2682 NK2809 and                                  |
| Statement     |  23 | JUN | 2008 | 2008-06-23 00:00:00 | 42                      |    108.69 |       nan | 169752    |           108.69 |   139.422    | Drainage Express Ltd   | 1/2 fee inspection waste systems           | Khalid Aslam           | 2008-04-17 00:00:00 |          0    | stms cb 033   | grd works £25k cxld                                         |
| Statement     |  24 | JUN | 2008 | 2008-06-24 00:00:00 | Loan                    |    nan    |     90000 | 259752    |             0    |     0        | nan                    | nan                                        | Khalid Aslam           | 2008-04-17 00:00:00 |          0    | stms cb 034   | grd works £25k cxld                                         |
| Statement     |  30 | JUN | 2008 | 2008-06-30 00:00:00 | 43                      |    138.69 |       nan | 259613    |           138.69 |   177.904    | Drainage Express Ltd   | 1/2 fee inspection waste systems           | Khalid Aslam           | 2008-04-17 00:00:00 |          0    | stms cb 035   | grd works £35k cxld                                         |
| Statement     |   2 | JUL | 2008 | 2008-07-02 00:00:00 | Credit                  |    nan    |     90000 | 349613    |             0    |     0        | nan                    | nan                                        | Khalid Aslam           | 2008-04-17 00:00:00 |          0    | stms cb 036   | grd works £15k cxld                                         |
| Statement     |   2 | JUL | 2008 | 2008-07-02 00:00:00 | lbcwyko02844893         |    nan    |    173916 | 523529    |             0    |     0        | nan                    | nan                                        | WSP                    | 2008-06-06 00:00:00 |          0    | stms cb 037   | arch o/s inv LE552 £3,920                                   |
| Statement     |  17 | JUL | 2008 | 2008-07-17 00:00:00 | Charges                 |      1.84 |       nan | 523527    |             1.84 |     2.36353  | Clydesdale Bank        | Charges                                    | WSP                    | 2008-06-06 00:00:00 |          0    | stms cb 038   | arch o/s inv LE552 - vat £686                               |
| Statement     |  18 | JUL | 2008 | 2008-07-18 00:00:00 | Self Withdrawal         |   3300    |       nan | 520227    |          3300    |  4238.94     | Khalid Aslam           | ground works - Cash                        | WSP                    | 2008-06-06 00:00:00 |          0    | stms cb 039   | struc NK2682 + NK 2809                                      |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | £2,587.50 x2                                                |
| Statement     |  18 | JUL | 2008 | 2008-07-18 00:00:00 | 41                      |    333.92 |       nan | 519893    |           333.92 |   428.929    | City of London         | survey manholes 1803 / 04                  | WSP                    | 2008-06-06 00:00:00 |          0    | stms cb 040   | struc NK2682 + NK2809 vat 452.81x2                          |
| Statement     |  31 | JUL | 2008 | 2008-07-31 00:00:00 | Transfer                |  14000    |       nan | 505893    |             0    |     0        | nan                    | LOAN REPAY??                               | City of London         | 2008-09-06 00:00:00 |        333.92 | stms cb 041   | survey manholes 1803 / 04                                   |
| Statement     |  18 | AUG | 2008 | 2008-08-18 00:00:00 | 44                      |  10000    |       nan | 495893    |         10000    | 12803.9      | Khalid Aslam           | Cash                                       | Drainage Express Ltd   | 2008-09-06 00:00:00 |        108.69 | stms cb 042   | 1/2 fee inspection waste systems                            |
| Statement     |  19 | AUG | 2008 | 2008-08-19 00:00:00 | Charges                 |     23.29 |       nan | 495870    |            23.29 |    29.8202   | Clydesdale Bank        | Charges                                    | Khalid Aslam           | 2008-06-24 00:00:00 |      11000    | cb433 - 44?   | cash                                                        |
| Statement     |   3 | SEP | 2008 | 2008-09-03 00:00:00 | 47                      |   5000    |       nan | 490870    |          5000    |  6366.76     | Khalid Aslam           | cash for sewage work                       | Drainage Express Ltd   | 2008-06-25 00:00:00 |        138.69 | stms cb 043   | 1/2 fee inspection waste systems                            |
| Statement     |   8 | SEP | 2008 | 2008-09-08 00:00:00 | 49                      |  25000    |       nan | 465870    |         25000    | 31833.8      | nan                    | Part Loan Repayment                        | Khalid Aslam           | 2008-07-18 00:00:00 |       3300    | cash          | ground works                                                |
| Statement     |  10 | SEP | 2008 | 2008-09-10 00:00:00 | 48                      |  13343.3  |       nan | 452527    |         13343.3  | 16990.7      | Nabarro                | cct legal                                  | Khalid Aslam           | 2008-08-21 00:00:00 |       1200    | stms cb 045   | consultants - engineer for temporary works                  |
| Statement     |  19 | SEP | 2008 | 2008-09-19 00:00:00 | Charges                 |      0.53 |       nan | 452526    |             0.53 |     0.674876 | Clydesdale Bank        | Charges                                    | Khalid Aslam           | 2008-03-09 00:00:00 |      18963    | stms cb 046   | drainage works                                              |
| Statement     |  25 | SEP | 2008 | 2008-09-25 00:00:00 | 45                      |   1200    |       nan | 451326    |          1200    |  1528.02     | Khalid Aslam           | consultants - engineer for temporary works | Khalid Aslam           | 2008-03-09 00:00:00 |       5000    | stms cb 047   | cash for sewage work                                        |
| Statement     |  25 | SEP | 2008 | 2008-09-25 00:00:00 | 46                      |  18963    |       nan | 432363    |         18963    | 24146.6      | Khalid Aslam           | drainage works                             | Nabarro                | 2008-05-09 00:00:00 |      13343.3  | stms cb 048   | cct legal                                                   |
| Statement     |  30 | SEP | 2008 | 2008-09-30 00:00:00 | 50                      |   2574.43 |       nan | 429789    |          2574.43 |  3278.15     | Birketts               | forwsp                                     | K Renwick              | 2008-05-09 00:00:00 |          0    | stms cb 049   | part loan repayment £25,000                                 |
| Statement     |  30 | SEP | 2008 | 2008-09-30 00:00:00 | 51                      |    370.12 |       nan | 429419    |           370.12 |   471.293    | Birketts               | korubuild ref stms                         | Birketts               | 2008-09-25 00:00:00 |       2574.43 | stms cb 050   | forwsp                                                      |
| Statement     |   1 | OCT | 2008 | 2008-10-01 00:00:00 | 52                      |  15000    |       nan | 414419    |         15000    | 19161.7      | Khalid Aslam           | consltants hse / cdm - £8,000 credit       | Birketts               | 2008-09-25 00:00:00 |        370.12 | stms cb 051   | korubuild ref stms                                          |
| Statement     |   3 | OCT | 2008 | 2008-10-03 00:00:00 | L829192277000707        |     24    |       nan | 414395    |            24    |    30.6587   | nan                    | Transfer Charge                            | Khalid Aslam           | 2008-09-25 00:00:00 |      15000    | stms cb 052   | consltants hse / cdm - £8,000 credit                        |
| Statement     |   3 | OCT | 2008 | 2008-10-03 00:00:00 | L829192277000707        | 300000    |       nan | 114395    |             0    |     0        | nan                    | LOAN REPAY??                               | Khalid Aslam           | 2008-10-17 00:00:00 |          0    | stms cb 053   | £35K replacement cheque for no.                             |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | 35 Incomplete cheque rejected                               |
| Statement     |   3 | OCT | 2008 | 2008-10-03 00:00:00 | To Renwick (loan repay) |  35000    |       nan |  79394.7  |             0    |     0        | nan                    | nan                                        | Khalid Aslam           | 2008-10-17 00:00:00 |      15000    | stms cb 054   | replacement cheque for no. 36                               |
| Statement     |  20 | OCT | 2008 | 2008-10-20 00:00:00 | Transfer                |    nan    |    102697 | 182091    |             0    |     0        | CPM Ltd                | nan                                        | Khalid Aslam           | 2008-10-17 00:00:00 |      25000    | stms cb 055   | replacement cheque for no. 33                               |
| Statement     |  21 | OCT | 2008 | 2008-10-21 00:00:00 | Charges                 |     36.21 |       nan | 182055    |            36.21 |    46.2563   | Clydesdale Bank        | Charges                                    | Khalid Aslam           | 2008-10-17 00:00:00 |      25000    | stms cb 056   | replacement cheque for no. 34                               |
| Statement     |  29 | OCT | 2008 | 2008-10-29 00:00:00 | 54                      |  15000    |       nan | 167055    |         15000    | 19161.7      | Khalid Aslam           | replacement cheque for no. 36              | Khalid Aslam           | 2008-10-17 00:00:00 |      25000    | stms cb 057   | replacement cheque for no. ?                                |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | (dup)                                                       |
| Statement     |  30 | OCT | 2008 | 2008-10-30 00:00:00 | 56                      |  25000    |       nan | 142055    |         25000    | 31936.2      | Khalid Aslam           | replacement cheque for no. 34              | Khalid Aslam           | 2008-10-17 00:00:00 |      35000    | stms cb 058   | replacement cheque for no. 35 /                             |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | 53                                                          |
| Statement     |   6 | NOV | 2008 | 2008-11-06 00:00:00 | 59                      |  35000    |       nan | 107055    |         35000    | 45062.5      | Khalid Aslam           | replacement cheque for no. 35 /            | Khalid Aslam           | 2008-01-11 00:00:00 |      35000    | stms cb 059   | replacement cheque for no. 53 (dup)                         |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        | 53                                         |                        |                     |               |               |                                                             |
| Statement     |  13 | NOV | 2008 | 2008-11-13 00:00:00 | 4A13118S51311726        |    nan    |    250000 | 357055    |             0    |     0        | nan                    | nan                                        | Warner Land Surveys    | 2008-04-11 00:00:00 |       1000    | stms cb 060   | Topo survey first payment of total                          |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            | Ltd                    |                     |               |               | £3000 cost                                                  |
| Statement     |  21 | NOV | 2008 | 2008-11-21 00:00:00 | Charges                 |      2.12 |       nan | 357053    |             2.12 |     2.7295   | Clydesdale Bank        | Charges                                    | Shere Group Ltd        | 2008-11-11 00:00:00 |          0    | temp cheques  | Simon - engineer £900 -                                     |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               | 59321         | RETURNED replace -chk 123                                   |
| Statement     |  28 | NOV | 2008 | 2008-11-28 00:00:00 | 55                      |  25000    |       nan | 332053    |         25000    | 32187.5      | Khalid Aslam           | replacement cheque for no. 33              | Khalid Aslam           | 2009-06-04 00:00:00 |          0    | stms cb 149   | March 25K                                                   |
| Statement     |  28 | NOV | 2008 | 2008-11-28 00:00:00 | 60                      |   1000    |       nan | 331053    |          1000    |  1287.5      | Warner Land Surveys    | Topo survey first payment of total         | Khalid Aslam           | 2009-06-04 00:00:00 |          0    | stms cb 150   | March 25K                                                   |
|               |     |     |      |                     |                         |           |           |           |                  |              | Ltd                    | £3000 cost                                 |                        |                     |               |               |                                                             |
| Statement     |   2 | DEC | 2008 | 2008-12-02 00:00:00 | 121                     |    175    |       nan | 330878    |           175    |   228.593    | ??                     | ??                                         | Khalid Aslam           | 2009-06-04 00:00:00 |          0    | stms cb 151   | March 25K                                                   |
| Statement     |   3 | DEC | 2008 | 2008-12-03 00:00:00 | 123                     |    900    |       nan | 329978    |           900    |  1175.62     | ??                     | ??                                         | Khalid Aslam           | 2009-06-04 00:00:00 |          0    | stms cb 152   | March 30K                                                   |
| Statement     |  10 | DEC | 2008 | 2008-12-10 00:00:00 | Debit Under Advice      |     10    |       nan | 329968    |            10    |    13.0625   | ??                     | ??                                         | SME Invoice Finance    | 2009-04-17 00:00:00 |       2127.5  | stms cb 153   | Topo Survey CADSurveys Ltd                                  |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            | Ltd                    |                     |               |               |                                                             |
| Statement     |  15 | DEC | 2008 | 2008-12-15 00:00:00 | 128                     |   5000    |       nan | 324968    |          5000    |  6531.24     | ??                     | ??                                         | Companies House -      | 2009-02-07 00:00:00 |         15    | stms cb 154   | to CAS 4 Annual Return                                      |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            | stms                   |                     |               |               |                                                             |
| Statement     |  16 | DEC | 2008 | 2008-12-16 00:00:00 | 59322                   |  40000    |       nan | 284968    |         40000    | 52249.9      | nan                    | Temp Works David                           | Khalid Aslam           | 2009-01-08 00:00:00 |          0    | stms cb 155   | Loan Repay 5k + Molas 3396                                  |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | (£8,396)                                                    |
| Statement     |  17 | DEC | 2008 | 2008-12-17 00:00:00 | 122                     |    400    |       nan | 284568    |           400    |   522.499    | City of London         | Skip Licence                               | Khalid Aslam           | 2009-01-08 00:00:00 |          0    | stms cb 156   | Loan Repay - Dup SK                                         |
| Statement     |  19 | DEC | 2008 | 2008-12-19 00:00:00 | Charges                 |      1.59 |       nan | 284566    |             1.59 |     2.07693  | Clydesdale Bank        | Charges                                    | Brian Hendry Architect | 2009-08-27 00:00:00 |       1600    | stms cb 157   | nan                                                         |
| Statement     |  12 | JAN | 2009 | 2009-01-12 00:00:00 | 58                      |  35000    |       nan | 249566    |         35000    | 46327.9      | Khalid Aslam           | nan                                        | Brian Hendry Architect | 2009-09-30 00:00:00 |        800    | stms cb 158   | paid at Sal Meeting                                         |
| Statement     |  12 | JAN | 2009 | 2009-01-12 00:00:00 | 133                     |   5000    |       nan | 244566    |          5000    |  6618.28     | Khalid Aslam           | ??                                         | Brian Hendry Architect | 2009-09-30 00:00:00 |        350    | stms cb 159   | paid at Sal Meeting                                         |
| Statement     |  13 | JAN | 2009 | 2009-01-13 00:00:00 | 57                      |  25000    |       nan | 219566    |         25000    | 33091.4      | Khalid Aslam           | nan                                        | Brian Hendry Architect | 2009-10-19 00:00:00 |       1750    | stms cb 160   | Cash paid into Brian Bos acct for                           |
|               |     |     |      |                     |                         |           |           |           |                  |              |                        |                                            |                        |                     |               |               | invoices 03 and 04                                          |
| Statement     |  23 | JAN | 2009 | 2009-01-23 00:00:00 | Charges                 |     35.68 |       nan | 219531    |            35.68 |    47.228    | Clydesdale Bank        | Charges                                    | City of London         | 2009-11-25 00:00:00 |       1400    | stms cb 161   | Hoarding I skip lie to nov 11 2010                          |
| Statement     |  28 | JAN | 2009 | 2009-01-28 00:00:00 | 124                     |  25000    |       nan | 194531    |         25000    | 33091.4      | Khalid Aslam ??        | ??                                         | Birketts               | 2009-12-15 00:00:00 |       7812.12 | stms cb 162   | Legal fees wsp/city for stms                                |
| Statement     |  28 | JAN | 2009 | 2009-01-28 00:00:00 | 136                     |   5000    |       nan | 189531    |          5000    |  6618.28     | ??                     | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  30 | JAN | 2009 | 2009-01-30 00:00:00 | 135                     |    763    |       nan | 188768    |           763    |  1009.95     | ??                     | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  10 | FEB | 2009 | 2009-02-10 00:00:00 | 125                     |  25000    |       nan | 163768    |         25000    | 32887.9      | Khalid Aslam ??        | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  17 | FEB | 2009 | 2009-02-17 00:00:00 | 126                     |  25000    |       nan | 138768    |         25000    | 32887.9      | Khalid Aslam ??        | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  19 | FEB | 2009 | 2009-02-19 00:00:00 | Self Withdrawal         |   5000    |       nan | 133768    |          5000    |  6577.58     | Khalid Aslam ??        | Cash??                                     | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  20 | FEB | 2009 | 2009-02-20 00:00:00 | Charges                 |     35.68 |       nan | 133732    |            35.68 |    46.9376   | Clydesdale Bank        | Charges                                    | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  24 | FEB | 2009 | 2009-02-24 00:00:00 | 137                     |    800    |       nan | 132932    |           800    |  1052.41     | ??                     | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |   2 | MAR | 2009 | 2009-03-02 00:00:00 | Transfer                |   2000    |       nan | 130932    |          2000    |  2632.28     | Khalid Aslam/=??       | Cash??                                     | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |   3 | MAR | 2009 | 2009-03-03 00:00:00 | 127                     |  30000    |       nan | 100932    |         30000    | 39484.1      | Khalid Aslam ??        | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |   9 | MAR | 2009 | 2009-03-09 00:00:00 | Transfer                |   2000    |       nan |  98932.1  |          2000    |  2632.28     | Khalid Aslam           | Cash??                                     | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  11 | MAR | 2009 | 2009-03-11 00:00:00 | 138                     |   5000    |       nan |  93932.1  |          5000    |  6580.69     | Khalid Aslam ??        | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  19 | MAR | 2009 | 2009-03-19 00:00:00 | 131                     |  25000    |       nan |  68932.1  |         25000    | 32903.5      | Khalid Aslam ??        | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  20 | MAR | 2009 | 2009-03-20 00:00:00 | Charges                 |     34.62 |       nan |  68897.5  |            34.62 |    45.5647   | Clydesdale Bank        | Charges                                    | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  26 | MAR | 2009 | 2009-03-26 00:00:00 | 130                     |  25000    |       nan |  43897.5  |         25000    | 32903.5      | Khalid Aslam ??        | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  30 | MAR | 2009 | 2009-03-30 00:00:00 | Transfer                |   3000    |       nan |  40897.5  |             0    |     0        | Khalid Aslam ??        | Cash??                                     | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |   2 | APR | 2009 | 2009-04-02 00:00:00 | 147                     |   3829.5  |       nan |  37068    |          3829.5  |  5035.39     | ??                     | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |   6 | APR | 2009 | 2009-04-06 00:00:00 | 148                     |   5000    |       nan |  32068    |          5000    |  6574.47     | Khalid Aslam ??        | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  14 | APR | 2009 | 2009-04-14 00:00:00 | 129                     |  25000    |       nan |   7067.95 |         25000    | 32872.3      | Khalid Aslam ??        | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  21 | APR | 2009 | 2009-04-21 00:00:00 | Charges                 |     34.62 |       nan |   7033.33 |            34.62 |    45.5216   | Clydesdale Bank        | Charges                                    | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  22 | APR | 2009 | 2009-04-22 00:00:00 | 153                     |   2127.5  |       nan |   4905.83 |          2127.5  |  2797.44     | SME Invoice Finance    | Topo Survey CADSurveys Ltd                 | nan                    | NaT                 |        nan    | nan           | nan                                                         |
|               |     |     |      |                     |                         |           |           |           |                  |              | Ltd                    |                                            |                        |                     |               |               |                                                             |
| Statement     |  28 | APR | 2009 | 2009-04-28 00:00:00 | Salafia K               |    nan    |     27000 |  31905.8  |             0    |     0        | nan                    | nan                                        | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  28 | APR | 2009 | 2009-04-28 00:00:00 | 132                     |  30000    |       nan |   1905.83 |         30000    | 39446.8      | Khalid Aslam ??        | ??                                         | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  30 | APR | 2009 | 2009-04-30 00:00:00 | Credit                  |    nan    |      4000 |   5905.83 |             0    |     0        | CPM Ltd                | nan                                        | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |   1 | MAY | 2009 | 2009-05-01 00:00:00 | Birketts                |     24    |       nan |   5881.83 |            24    |    31.3647   | Clydesdale Bank        | Transfer Charge                            | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |   1 | MAY | 2009 | 2009-05-01 00:00:00 | Birketts                |   1800    |       nan |   4081.83 |          1800    |  2352.35     | Birketts               | Legal fees City DA/Lease                   | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  22 | MAY | 2009 | 2009-05-22 00:00:00 | Charges                 |     35.93 |       nan |   4045.9  |            35.93 |    46.9555   | Clydesdale Bank        | Charges                                    | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  16 | JUL | 2009 | 2009-07-16 00:00:00 | 154                     |     15    |       nan |   4030.9  |            15    |    19.5478   | Companies House        | to CAS 4 Annual Return                     | nan                    | NaT                 |        nan    | nan           | nan                                                         |
| Statement     |  11 | AUG | 2009 | 2009-08-11 00:00:00 | Transfer                |    nan    |      9000 |  13030.9  |             0    |     0        | nan                    | nan                                        | nan                    | NaT                 |        nan    | nan           | nan                                                         |

*(Note: Truncated after 200 rows for readability)*

---

## Sheet: NEW STATEMENTS
| Unnamed: 0   |   Unnamed: 1 | Unnamed: 2   |   Unnamed: 3 | Date                | Description                        |    Debit |   Credit | Unnamed: 12         |
|:-------------|-------------:|:-------------|-------------:|:--------------------|:-----------------------------------|---------:|---------:|:--------------------|
| Statement    |           11 | MAY          |         2010 | 2010-05-11 00:00:00 | 163                                |  8396    |   nan    | nan                 |
| Statement    |           23 | JAN          |         2012 | 2012-01-23 00:00:00 | PC World Hemel                     |    59.99 |   nan    | nan                 |
| Statement    |           23 | JAN          |         2012 | 2012-01-23 00:00:00 | LLGS LTD                           |   215.66 |   nan    | nan                 |
| Statement    |           23 | JAN          |         2012 | 2012-01-23 00:00:00 | Amazon                             |   662.66 |   nan    | nan                 |
| Statement    |           25 | JAN          |         2012 | 2012-01-25 00:00:00 | Greater Anglia - TRAIN TO Birketts |    24.5  |   nan    | nan                 |
| Statement    |            5 | NOV          |         2012 | 2012-11-05 00:00:00 | Part Loan Repayment                |  6000    |   nan    | nan                 |
| Statement    |           12 | DEC          |         2012 | 2012-12-12 00:00:00 | 68                                 |   550    |   nan    | nan                 |
| Statement    |           15 | FEB          |         2013 | 2013-02-15 00:00:00 | LOAN                               |   nan    |  4500    | nan                 |
| Statement    |           12 | MAR          |         2013 | 2013-03-12 00:00:00 | 69                                 |   396    |   nan    | nan                 |
| Statement    |            2 | APR          |         2013 | 2013-04-02 00:00:00 | 70                                 |  5000    |   nan    | nan                 |
| Statement    |            4 | APR          |         2013 | 2013-04-04 00:00:00 | Thompson Reuters Ltd               |   nan    |  2033.92 | nan                 |
| Statement    |           11 | APR          |         2013 | 2013-04-11 00:00:00 | HSBC Clerkenwell                   |   300    |   nan    | nan                 |
| Statement    |            1 | MAY          |         2013 | 2013-05-01 00:00:00 | Thompson Reuters Ltd               |   nan    | 26880    | nan                 |
| Statement    |           13 | MAY          |         2013 | 2013-05-13 00:00:00 | Part Loan Repayment                |  8000    |   nan    | nan                 |
| Statement    |           25 | JUN          |         2013 | 2013-06-25 00:00:00 | Businesss Online Charges           |     3    |   nan    | nan                 |
| Statement    |           27 | JUN          |         2013 | 2013-06-27 00:00:00 | Charges                            |     6.7  |   nan    | nan                 |
| Statement    |            4 | JUL          |         2013 | 2013-07-04 00:00:00 | Reuters Ltd                        |   nan    |  2083.35 | Part Loan Repayment |
| Statement    |            5 | JUL          |         2013 | 2013-07-05 00:00:00 | Part Loan Repayment                |  8000    |   nan    | nan                 |
| Statement    |           10 | JUL          |         2013 | 2013-07-10 00:00:00 | G Renwick                          |   500    |   nan    | nan                 |
| Statement    |           17 | JUL          |         2013 | 2013-07-17 00:00:00 | 72                                 |    13    |   nan    | nan                 |
| Statement    |           22 | JUL          |         2013 | 2013-07-22 00:00:00 | Part Loan Repayment                |  8000    |   nan    | nan                 |
| Statement    |           22 | JUL          |         2013 | 2013-07-22 00:00:00 | 73                                 |  2500    |   nan    | nan                 |
| Statement    |           30 | JUL          |         2013 | 2013-07-30 00:00:00 | 74                                 |  5657.88 |   nan    | nan                 |
| Statement    |            1 | AUG          |         2013 | 2013-08-01 00:00:00 | G Renwick                          |   500    |   nan    | nan                 |
| Statement    |            2 | AUG          |         2013 | 2013-08-02 00:00:00 | Loan                               |   nan    |  5000    | nan                 |
| Statement    |            5 | AUG          |         2013 | 2013-08-05 00:00:00 | HMRC                               |    24    |   nan    | nan                 |
| Statement    |            5 | AUG          |         2013 | 2013-08-05 00:00:00 | HMRC                               |  4179.83 |   nan    | nan                 |
| Statement    |            6 | AUG          |         2013 | 2013-08-06 00:00:00 | Copy Statements                    |     5    |   nan    | nan                 |
| Statement    |           28 | AUG          |         2013 | 2013-08-28 00:00:00 | Part Loan Repayment                |  5000    |   nan    | nan                 |
| Statement    |           29 | AUG          |         2013 | 2013-08-29 00:00:00 | 75                                 |  5667.55 |   nan    | nan                 |
| Statement    |            2 | SEP          |         2013 | 2013-09-02 00:00:00 | G Renwick                          |   500    |   nan    | nan                 |
| Statement    |           25 | SEP          |         2013 | 2013-09-25 00:00:00 | 76                                 |  1000    |   nan    | nan                 |
| Statement    |           26 | SEP          |         2013 | 2013-09-26 00:00:00 | Charges                            |     8.1  |   nan    | nan                 |
| Statement    |           27 | SEP          |         2013 | 2013-09-27 00:00:00 | HMRC CREDIT                        |   nan    |  5658.05 | nan                 |
| Statement    |           27 | SEP          |         2013 | 2013-09-27 00:00:00 | Part Loan Repayment                |  5000    |   nan    | nan                 |
| Statement    |           21 | OCT          |         2013 | 2013-10-21 00:00:00 | Part Loan Repayment                |  5000    |   nan    | nan                 |
| Statement    |           23 | OCT          |         2013 | 2013-10-23 00:00:00 | 77                                 |  3998.52 |   nan    | nan                 |
| Statement    |           25 | OCT          |         2013 | 2013-10-25 00:00:00 | BOL Charges                        |     3    |   nan    | nan                 |
| Statement    |           29 | OCT          |         2013 | 2013-10-29 00:00:00 | Reuters Ltd                        | 22800    |   nan    | nan                 |
| Statement    |           29 | OCT          |         2013 | 2013-10-29 00:00:00 | Charges                            |     7.7  |   nan    | nan                 |
| Statement    |            1 | NOV          |         2013 | 2013-11-01 00:00:00 | G Renwick                          |   500    |   nan    | nan                 |
| Statement    |            4 | NOV          |         2013 | 2013-11-04 00:00:00 | Part Loan Repayment                |  5000    |   nan    | nan                 |
| Statement    |            6 | NOV          |         2013 | 2013-11-06 00:00:00 | 78                                 |  1800    |   nan    | nan                 |
| Statement    |           25 | NOV          |         2013 | 2013-11-25 00:00:00 | BOL Charges                        |     3    |   nan    | nan                 |
| Statement    |           25 | NOV          |         2013 | 2013-11-25 00:00:00 | 79                                 |  3000    |   nan    | nan                 |
| Statement    |           27 | NOV          |         2013 | 2013-11-27 00:00:00 | Reuters Ltd                        |   nan    |  1071.27 | nan                 |
| Statement    |           27 | NOV          |         2013 | 2013-11-27 00:00:00 | Charges                            |     6.7  |   nan    | nan                 |
| Statement    |            2 | DEC          |         2013 | 2013-12-02 00:00:00 | G Renwick                          |   500    |   nan    | nan                 |
| Statement    |            4 | DEC          |         2013 | 2013-12-04 00:00:00 | Part Loan Repayment                |  8000    |   nan    | nan                 |
| Statement    |           13 | DEC          |         2013 | 2013-12-13 00:00:00 | 80                                 |   995.11 |   nan    | nan                 |
| Statement    |           27 | DEC          |         2013 | 2013-12-27 00:00:00 | BOL Charges                        |     3    |   nan    | nan                 |
| Statement    |           27 | DEC          |         2013 | 2013-12-27 00:00:00 | Charges                            |     7.4  |   nan    | nan                 |
| Statement    |            2 | JAN          |         2014 | 2014-01-02 00:00:00 | G Renwick                          |   500    |   nan    | nan                 |
| Statement    |           13 | JAN          |         2014 | 2014-01-13 00:00:00 | Reuters Ltd                        |   nan    |   313.3  | nan                 |
| Statement    |           20 | JAN          |         2014 | 2014-01-20 00:00:00 | HMRC                               |  3920    |   nan    | nan                 |
| Statement    |           27 | JAN          |         2014 | 2014-01-27 00:00:00 | BOL Charges                        |     3    |   nan    | nan                 |
| Statement    |           29 | JAN          |         2014 | 2014-01-29 00:00:00 | Charges                            |     6.7  |   nan    | nan                 |

---

## Sheet: PIVOT
| Row Labels   |   Sum of Indexed | Sum of Incurred Costs   |   RPI FIGURE |   Unnamed: 4 |   YEAR |     CALC INDEXED |
|:-------------|-----------------:|:------------------------|-------------:|-------------:|-------:|-----------------:|
| 2004         |  89947.6         | 60776.100000000006      |        nan   |          nan |    nan |    nan           |
| Jan          |   1784.64        | 1175                    |        183.1 |            1 |   2004 |   1784.64        |
| Jun          |  31678.3         | 21278.37                |        186.8 |            6 |   2004 |  31678.3         |
| Sep          |  17275.9         | 11684.99                |        188.1 |            9 |   2004 |  17275.9         |
| Oct          |  24738.3         | 16776.88                |        188.6 |           10 |   2004 |  24738.3         |
| Nov          |   6241.43        | 4241.75                 |        189   |           11 |   2004 |   6241.43        |
| Dec          |   8228.93        | 5619.11                 |        189.9 |           12 |   2004 |   8228.93        |
| 2005         | 236656           | 163459.04999999996      |        nan   |          nan |    nan |    nan           |
| Feb          |   5323.59        | 3629.46                 |        189.6 |            2 |   2005 |   5323.59        |
| Mar          |  28684.8         | 19649.21                |        190.5 |            3 |   2005 |  28684.8         |
| Apr          |  12722.8         | 8765.5                  |        191.6 |            4 |   2005 |  12722.8         |
| May          |  13544.7         | 9351.23                 |        192   |            5 |   2005 |  13544.7         |
| Jun          |  98843           | 68312.23999999999       |        192.2 |            6 |   2005 |  98843           |
| Jul          |  33291.9         | 23008.609999999997      |        192.2 |            7 |   2005 |  33291.9         |
| Aug          |  14340.6         | 9931.68                 |        192.6 |            8 |   2005 |  14340.6         |
| Sep          |     43.2056      | 30                      |        193.1 |            9 |   2005 |     43.2056      |
| Oct          |   6400.21        | 4448.62                 |        193.3 |           10 |   2005 |   6400.21        |
| Nov          |  23461.1         | 16332.5                 |        193.6 |           11 |   2005 |  23461.1         |
| 2006         | 246193           | 175968.83               |        nan   |          nan |    nan |    nan           |
| Mar          |  18265.5         | 12807.5                 |        195   |            3 |   2006 |  18265.5         |
| Apr          |  25000.5         | 17664.879999999997      |        196.5 |            4 |   2006 |  25000.5         |
| May          |  22312.7         | 15861.989999999998      |        197.7 |            5 |   2006 |  22312.7         |
| Jun          |  31974.5         | 22822.48                |        198.5 |            6 |   2006 |  31974.5         |
| Jul          |  43276.5         | 30889.530000000002      |        198.5 |            7 |   2006 |  43276.5         |
| Aug          |  16740.4         | 11990.970000000001      |        199.2 |            8 |   2006 |  16740.4         |
| Sep          |  59903.2         | 43101.87                |        200.1 |            9 |   2006 |  59903.2         |
| Nov          |  18012.6         | 13025.27                |        201.1 |           11 |   2006 |  18012.6         |
| Dec          |  10707.4         | 7804.34                 |        202.7 |           12 |   2006 |  10707.4         |
| 2007         | 206512           | 153026.72999999998      |        nan   |          nan |    nan |    nan           |
| Jan          |  13794.6         | 10000                   |        201.6 |            1 |   2007 |  13794.6         |
| Feb          |  75310.2         | 55000                   |        203.1 |            2 |   2007 |  75310.2         |
| Apr          |   2405.42        | 1776.6                  |        205.4 |            4 |   2007 |   2405.42        |
| May          |   3071.71        | 2277.55                 |        206.2 |            5 |   2007 |   3071.71        |
| Jun          |   9522.92        | 7098.53                 |        207.3 |            6 |   2007 |   9522.92        |
| Jul          |  11317.8         | 8387.619999999999       |        206.1 |            7 |   2007 |  11317.8         |
| Aug          |    135.575       | 101.06                  |        207.3 |            8 |   2007 |    135.575       |
| Sep          |  16899.9         | 12640.02                |        208   |            9 |   2007 |  16899.9         |
| Oct          |  32793           | 24633.11                |        208.9 |           10 |   2007 |  32793           |
| Nov          |  41254.8         | 31108                   |        209.7 |           11 |   2007 |  41254.8         |
| Dec          |      5.59101     | 4.24                    |        210.9 |           12 |   2007 |      5.59101     |
| 2008         | 333388           | 259172.18               |        nan   |          nan |    nan |    nan           |
| Feb          |   7303.98        | 5552.18                 |        211.4 |            2 |   2008 |   7303.98        |
| Mar          |  14046.3         | 10712.740000000002      |        212.1 |            3 |   2008 |  14046.3         |
| Apr          |      0           | 0                       |        214   |            4 |   2008 |      0           |
| May          |      0.68523     | 0.53                    |        215.1 |            5 |   2008 |      0.68523     |
| Jun          |    317.326       | 247.38                  |        216.8 |            6 |   2008 |    317.326       |
| Jul          |   4670.23        | 3635.76                 |        216.5 |            7 |   2008 |   4670.23        |
| Aug          |  12833.7         | 10023.29                |        217.2 |            8 |   2008 |  12833.7         |
| Sep          |  84616           | 66451.37999999999       |        218.4 |            9 |   2008 |  84616           |
| Oct          |  70336.4         | 55060.21                |        217.7 |           10 |   2008 |  70336.4         |
| Nov          |  78540.2         | 61002.12                |        216   |           11 |   2008 |  78540.2         |
| Dec          |  60723           | 46486.59                |        212.9 |           12 |   2008 |  60723           |
| 2009         | 424243           | 322261.67000000004      |        nan   |          nan |    nan |    nan           |
| Jan          | 126804           | 95798.68                |        210.1 |            1 |   2009 | 126804           |
| Feb          |  73452.7         | 55835.68                |        211.4 |            2 |   2009 |  73452.7         |
| Mar          | 117182           | 89034.62                |        211.3 |            3 |   2009 | 117182           |
| Apr          |  86772           | 65991.62                |        211.5 |            4 |   2009 |  86772           |
| May          |   2430.67        | 1859.93                 |        212.8 |            5 |   2009 |   2430.67        |
| Jul          |     19.5478      | 15                      |        213.4 |            7 |   2009 |     19.5478      |
| Aug          |      0.687467    | 0.53                    |        214.4 |            8 |   2009 |      0.687467    |
| Sep          |   2066.7         | 1600                    |        215.3 |            9 |   2009 |   2066.7         |
| Oct          |   3734.43        | 2900.53                 |        216   |           10 |   2009 |   3734.43        |
| Nov          |   1814.15        | 1412.96                 |        216.6 |           11 |   2009 |   1814.15        |
| Dec          |   9965.83        | 7812.12                 |        218   |           12 |   2009 |   9965.83        |
| 2010         |  23514.1         | 18869.65                |        nan   |          nan |    nan |    nan           |
| Mar          |   3481.61        | 2763                    |        220.7 |            3 |   2010 |   3481.61        |
| May          |  18534.2         | 14901.970000000001      |        223.6 |            5 |   2010 |  18534.2         |
| Jul          |   1498.31        | 1204.68                 |        223.6 |            7 |   2010 |   1498.31        |
| 2011         |   1913.92        | 1614                    |        nan   |          nan |    nan |    nan           |
| Mar          |    478.452       | 400                     |        232.5 |            3 |   2011 |    478.452       |
| Apr          |      0           | 0                       |        234.4 |            4 |   2011 |      0           |
| May          |      0           | 0                       |        235.2 |            5 |   2011 |      0           |
| Jun          |   1418.88        | 1200                    |        235.2 |            6 |   2011 |   1418.88        |
| Jul          |     16.5888      | 14                      |        234.7 |            7 |   2011 |     16.5888      |
| 2014         |  75405.3         | 69404.43999999999       |        nan   |          nan |    nan |    nan           |
| Jan          |      6.6057      | 6                       |        252.6 |            1 |   2014 |      6.6057      |
| Feb          |  11946.7         | 10920                   |        254.2 |            2 |   2014 |  11946.7         |
| Mar          |  11451.3         | 10491.9                 |        254.8 |            3 |   2014 |  11451.3         |
| Apr          |   6049.51        | 5562.24                 |        255.7 |            4 |   2014 |   6049.51        |
| May          |   2957.71        | 2721.6                  |        255.9 |            5 |   2014 |   2957.71        |
| Jun          |   6200.45        | 5714.4                  |        256.3 |            6 |   2014 |   6200.45        |
| Jul          |  13564.9         | 12486.9                 |        256   |            7 |   2014 |  13564.9         |
| Aug          |   6461.44        | 5971.2                  |        257   |            8 |   2014 |   6461.44        |
| Sep          |   9777.55        | 9056.8                  |        257.6 |            9 |   2014 |   9777.55        |
| Oct          |   4484.35        | 4155.4                  |        257.7 |           10 |   2014 |   4484.35        |
| Nov          |    871.834       | 806                     |        257.1 |           11 |   2014 |    871.834       |
| Dec          |   1632.96        | 1512                    |        257.5 |           12 |   2014 |   1632.96        |
| 2015         |  99220.7         | 92229.34000000001       |        nan   |          nan |    nan |    nan           |
| Jan          |   7076.43        | 6498.81                 |        255.4 |            1 |   2015 |   7076.43        |
| Feb          |   6264.69        | 5782.62                 |        256.7 |            2 |   2015 |   6264.69        |
| Mar          |   8317.33        | 7689.27                 |        257.1 |            3 |   2015 |   8317.33        |
| Apr          |   8406.08        | 7798.519999999999       |        258   |            4 |   2015 |   8406.08        |
| May          |  18051.5         | 16779.25                |        258.5 |            5 |   2015 |  18051.5         |
| Jun          |   2199.92        | 2048.04                 |        258.9 |            6 |   2015 |   2199.92        |
| Jul          |  14900.4         | 13855.57                |        258.6 |            7 |   2015 |  14900.4         |
| Aug          |   4560.01        | 4259.94                 |        259.8 |            8 |   2015 |   4560.01        |
| Sep          |   5249.14        | 4899.95                 |        259.6 |            9 |   2015 |   5249.14        |
| Oct          |   3284.38        | 3064.7100000000005      |        259.5 |           10 |   2015 |   3284.38        |
| Nov          |  14728.8         | 13759.559999999998      |        259.8 |           11 |   2015 |  14728.8         |
| Dec          |   6182.12        | 5793.1                  |        260.6 |           12 |   2015 |   6182.12        |
| 2016         | 193420           | 182919.56000000003      |        nan   |          nan |    nan |    nan           |
| Jan          |  19627.2         | 18265.110000000004      |        258.8 |            1 |   2016 |  19627.2         |
| Feb          |   8456.52        | 7906.13                 |        260   |            2 |   2016 |   8456.52        |
| Mar          |   8990.23        | 8440.67                 |        261.1 |            3 |   2016 |   8990.23        |
| Apr          |  28460.4         | 26751.35000000001       |        261.4 |            4 |   2016 |  28460.4         |
| May          |  -1774.22        | -1672.1400000000024     |        262.1 |            5 |   2016 |  -1774.22        |
| Jun          |  28175.4         | 26655.670000000006      |        263.1 |            6 |   2016 |  28175.4         |
| Jul          |  32301.2         | 30593.83000000001       |        263.4 |            7 |   2016 |  32301.2         |
| Aug          |  22590.9         | 21477.99                |        264.4 |            8 |   2016 |  22590.9         |
| Sep          |  15655.3         | 14912.219999999996      |        264.9 |            9 |   2016 |  15655.3         |
| Oct          |   4856.64        | 4624.37                 |        264.8 |           10 |   2016 |   4856.64        |
| Nov          |  14654.5         | 13990.539999999995      |        265.5 |           11 |   2016 |  14654.5         |
| Dec          |  11425.8         | 10973.820000000002      |        267.1 |           12 |   2016 |  11425.8         |
| 2017         | 158359           | 154868.17               |        nan   |          nan |    nan |    nan           |
| Jan          |   5073.84        | 4843.959999999999       |        265.5 |            1 |   2017 |   5073.84        |
| Feb          |  33271.2         | 32110.67                |        268.4 |            2 |   2017 |  33271.2         |
| Mar          |  15304.6         | 14820.340000000004      |        269.3 |            3 |   2017 |  15304.6         |
| Apr          |  24691.6         | 24025.730000000003      |        270.6 |            4 |   2017 |  24691.6         |
| May          |   4041.32        | 3948.319999999999       |        271.7 |            5 |   2017 |   4041.32        |
| Jun          |   9272.73        | 9079.339999999998       |        272.3 |            6 |   2017 |   9272.73        |
| Jul          |  11081           | 10873.85                |        272.9 |            7 |   2017 |  11081           |
| Aug          |  10307.5         | 10181.519999999999      |        274.7 |            8 |   2017 |  10307.5         |
| Sep          |   3755.12        | 3714.6099999999988      |        275.1 |            9 |   2017 |   3755.12        |
| Oct          |  11248.8         | 11135.519999999995      |        275.3 |           10 |   2017 |  11248.8         |
| Nov          |  21415           | 21237.870000000003      |        275.8 |           11 |   2017 |  21415           |
| Dec          |   8896.44        | 8896.44                 |        278.1 |           12 |   2017 |   8896.44        |
| 2018         | 135662           | 135661.78999999998      |        nan   |          nan |    nan |    nan           |
| Jan          |  13275.6         | 13275.569999999998      |        nan   |            1 |   2018 |  13275.6         |
| Feb          |  11222.4         | 11222.39                |        nan   |            2 |   2018 |  11222.4         |
| Mar          |  14352.9         | 14352.900000000001      |        nan   |            3 |   2018 |  14352.9         |
| Apr          |  13283.9         | 13283.889999999998      |        nan   |            4 |   2018 |  13283.9         |
| May          |   4729.26        | 4729.259999999999       |        nan   |            5 |   2018 |   4729.26        |
| Jun          |  14011.2         | 14011.239999999998      |        nan   |            6 |   2018 |  14011.2         |
| Jul          |   8114.26        | 8114.259999999999       |        nan   |            7 |   2018 |   8114.26        |
| Aug          |  10659.6         | 10659.589999999998      |        nan   |            8 |   2018 |  10659.6         |
| Sep          |  10331.3         | 10331.32                |        nan   |            9 |   2018 |  10331.3         |
| Oct          |  15518.3         | 15518.309999999998      |        nan   |           10 |   2018 |  15518.3         |
| Nov          |   5430.81        | 5430.809999999997       |        nan   |           11 |   2018 |   5430.81        |
| Dec          |  14732.2         | 14732.249999999998      |        nan   |           12 |   2018 |  14732.2         |
| 2019         |  80405.9         | 80405.88999999998       |        nan   |          nan |    nan |    nan           |
| Jan          |   4008.59        | 4008.5899999999997      |        nan   |            1 |   2019 |   4008.59        |
| Feb          |   2645.09        | 2645.089999999999       |        nan   |            2 |   2019 |   2645.09        |
| Mar          |  11532           | 11532.009999999998      |        nan   |            3 |   2019 |  11532           |
| Apr          |  12744.6         | 12744.589999999998      |        nan   |            4 |   2019 |  12744.6         |
| May          |   3806.61        | 3806.6099999999997      |        nan   |            5 |   2019 |   3806.61        |
| Jun          |  12338.1         | 12338.119999999995      |        nan   |            6 |   2019 |  12338.1         |
| Jul          |   6476.54        | 6476.54                 |        nan   |            7 |   2019 |   6476.54        |
| Aug          |   4777.84        | 4777.839999999998       |        nan   |            8 |   2019 |   4777.84        |
| Sep          |   6100.69        | 6100.6900000000005      |        nan   |            9 |   2019 |   6100.69        |
| Oct          |   3294.52        | 3294.5199999999986      |        nan   |           10 |   2019 |   3294.52        |
| Nov          |   6622.67        | 6622.669999999999       |        nan   |           11 |   2019 |   6622.67        |
| Dec          |   6058.62        | 6058.619999999998       |        nan   |           12 |   2019 |   6058.62        |
| 2020         |  41303.9         | 41303.939999999995      |        nan   |          nan |    nan |    nan           |
| Jan          |  14342.9         | 14342.879999999997      |        nan   |            1 |   2020 |  14342.9         |
| Feb          |   2944.14        | 2944.139999999999       |        nan   |            2 |   2020 |   2944.14        |
| Mar          |   2644.39        | 2644.3900000000003      |        nan   |            3 |   2020 |   2644.39        |
| Apr          |   1079.15        | 1079.1500000000003      |        nan   |            4 |   2020 |   1079.15        |
| May          |    420.47        | 420.46999999999986      |        nan   |            5 |   2020 |    420.47        |
| Jun          |   1308.82        | 1308.82                 |        nan   |            6 |   2020 |   1308.82        |
| Jul          |   2280.04        | 2280.04                 |        nan   |            7 |   2020 |   2280.04        |
| Aug          |   2170.23        | 2170.2299999999996      |        nan   |            8 |   2020 |   2170.23        |
| Sep          |   2974.01        | 2974.01                 |        nan   |            9 |   2020 |   2974.01        |
| Oct          |   3659.67        | 3659.67                 |        nan   |           10 |   2020 |   3659.67        |
| Nov          |   3272.54        | 3272.539999999999       |        nan   |           11 |   2020 |   3272.54        |
| Dec          |   4207.6         | 4207.599999999999       |        nan   |           12 |   2020 |   4207.6         |
| 2021         | 109098           | 109098.38               |        nan   |          nan |    nan |    nan           |
| Jan          |   2129.48        | 2129.4800000000005      |        nan   |            1 |   2021 |   2129.48        |
| Feb          |   2827.06        | 2827.0600000000004      |        nan   |            2 |   2021 |   2827.06        |
| Mar          |   4404.3         | 4404.299999999999       |        nan   |            3 |   2021 |   4404.3         |
| Apr          |   3165.29        | 3165.29                 |        nan   |            4 |   2021 |   3165.29        |
| May          |   3703.83        | 3703.8299999999986      |        nan   |            5 |   2021 |   3703.83        |
| Jun          |   6812.05        | 6812.049999999999       |        nan   |            6 |   2021 |   6812.05        |
| Jul          |   2491.35        | 2491.3500000000004      |        nan   |            7 |   2021 |   2491.35        |
| Aug          |   2764.99        | 2764.9900000000007      |        nan   |            8 |   2021 |   2764.99        |
| Sep          |   7699.31        | 7699.3099999999995      |        nan   |            9 |   2021 |   7699.31        |
| Oct          |   2504.12        | 2504.1199999999994      |        nan   |           10 |   2021 |   2504.12        |
| Nov          |   5449.89        | 5449.890000000001       |        nan   |           11 |   2021 |   5449.89        |
| Dec          |  65146.7         | 65146.71                |        nan   |           12 |   2021 |  65146.7         |
| 2022         | 163721           | 163720.55000000002      |        nan   |          nan |    nan |    nan           |
| Jan          |  14818.1         | 14818.080000000004      |        nan   |            1 |   2022 |  14818.1         |
| Feb          |  25041.7         | 25041.74                |        nan   |            2 |   2022 |  25041.7         |
| Mar          |  35425.5         | 35425.490000000005      |        nan   |            3 |   2022 |  35425.5         |
| Apr          |  33863.1         | 33863.11                |        nan   |            4 |   2022 |  33863.1         |
| May          |   5935.11        | 5935.109999999999       |        nan   |            5 |   2022 |   5935.11        |
| Jun          |  31110.4         | 31110.449999999997      |        nan   |            6 |   2022 |  31110.4         |
| Jul          |   1399.35        | 1399.3500000000001      |        nan   |            7 |   2022 |   1399.35        |
| Aug          |   3550.27        | 3550.2700000000004      |        nan   |            8 |   2022 |   3550.27        |
| Sep          |   1196.7         | 1196.6999999999998      |        nan   |            9 |   2022 |   1196.7         |
| Oct          |   2076.75        | 2076.7500000000005      |        nan   |           10 |   2022 |   2076.75        |
| Nov          |   2546.21        | 2546.21                 |        nan   |           11 |   2022 |   2546.21        |
| Dec          |   6757.29        | 6757.290000000001       |        nan   |           12 |   2022 |   6757.29        |
| 2023         |  22825.8         | 22825.770000000004      |        nan   |          nan |    nan |    nan           |
| Jan          |  13763.4         | 13763.350000000002      |        nan   |            1 |   2023 |  13763.4         |
| Feb          |   5352.04        | 5352.04                 |        nan   |            2 |   2023 |   5352.04        |
| Mar          |   3710.38        | 3710.3800000000006      |        nan   |            3 |   2023 |   3710.38        |
| Grand Total  |      2.64179e+06 | 2207586.040000002       |        nan   |          nan |    nan |    nan           |
| nan          |    nan           | nan                     |        nan   |          nan |    nan |      2.64179e+06 |
| nan          |    nan           | CASH ON ACCOUNT         |        nan   |          nan |    nan | 260000           |

---

## Sheet: RPI
| Title             | RPI All Items Index: Jan 1987=100   |
|:------------------|:------------------------------------|
| CDID              | CHAW                                |
| Source dataset ID | MM23                                |
| PreUnit           | nan                                 |
| Unit              | Index, base year = 100              |
| Release date      | 22-03-2023                          |
| Next release      | 19 April 2023                       |
| Important notes   | nan                                 |
| 1987              | 101.9                               |
| 1988              | 106.9                               |
| 1989              | 115.2                               |
| 1990              | 126.1                               |
| 1991              | 133.5                               |
| 1992              | 138.5                               |
| 1993              | 140.7                               |
| 1994              | 144.1                               |
| 1995              | 149.1                               |
| 1996              | 152.7                               |
| 1997              | 157.5                               |
| 1998              | 162.9                               |
| 1999              | 165.4                               |
| 2000              | 170.3                               |
| 2001              | 173.3                               |
| 2002              | 176.2                               |
| 2003              | 181.3                               |
| 2004              | 186.7                               |
| 2005              | 192                                 |
| 2006              | 198.1                               |
| 2007              | 206.6                               |
| 2008              | 214.8                               |
| 2009              | 213.7                               |
| 2010              | 223.6                               |
| 2011              | 235.2                               |
| 2012              | 242.7                               |
| 2013              | 250.1                               |
| 2014              | 256                                 |
| 2015              | 258.5                               |
| 2016              | 263.1                               |
| 2017              | 272.5                               |
| 2018              | 281.6                               |
| 2019              | 288.8                               |
| 2020              | 293.1                               |
| 2021              | 305                                 |
| 2022              | 340.3                               |
| 1987 Q1           | 100.3                               |
| 1987 Q2           | 101.9                               |
| 1987 Q3           | 102.1                               |
| 1987 Q4           | 103.2                               |
| 1988 Q1           | 103.7                               |
| 1988 Q2           | 106.2                               |
| 1988 Q3           | 107.7                               |
| 1988 Q4           | 109.9                               |
| 1989 Q1           | 111.7                               |
| 1989 Q2           | 114.9                               |
| 1989 Q3           | 116                                 |
| 1989 Q4           | 118.3                               |
| 1990 Q1           | 120.4                               |
| 1990 Q2           | 126                                 |
| 1990 Q3           | 128.1                               |
| 1990 Q4           | 130.1                               |
| 1991 Q1           | 130.8                               |
| 1991 Q2           | 133.6                               |
| 1991 Q3           | 134.2                               |
| 1991 Q4           | 135.5                               |
| 1992 Q1           | 136.2                               |
| 1992 Q2           | 139.1                               |
| 1992 Q3           | 139                                 |
| 1992 Q4           | 139.6                               |
| 1993 Q1           | 138.7                               |
| 1993 Q2           | 140.9                               |
| 1993 Q3           | 141.3                               |
| 1993 Q4           | 141.8                               |
| 1994 Q1           | 142                                 |
| 1994 Q2           | 144.5                               |
| 1994 Q3           | 144.6                               |
| 1994 Q4           | 145.5                               |
| 1995 Q1           | 146.8                               |
| 1995 Q2           | 149.5                               |
| 1995 Q3           | 149.9                               |
| 1995 Q4           | 150.1                               |
| 1996 Q1           | 150.9                               |
| 1996 Q2           | 152.8                               |
| 1996 Q3           | 153.1                               |
| 1996 Q4           | 154                                 |
| 1997 Q1           | 154.9                               |
| 1997 Q2           | 156.9                               |
| 1997 Q3           | 158.4                               |
| 1997 Q4           | 159.7                               |
| 1998 Q1           | 160.2                               |
| 1998 Q2           | 163.2                               |
| 1998 Q3           | 163.7                               |
| 1998 Q4           | 164.4                               |
| 1999 Q1           | 163.7                               |
| 1999 Q2           | 165.5                               |
| 1999 Q3           | 165.6                               |
| 1999 Q4           | 166.8                               |
| 2000 Q1           | 167.5                               |
| 2000 Q2           | 170.6                               |
| 2000 Q3           | 170.9                               |
| 2000 Q4           | 172                                 |
| 2001 Q1           | 171.8                               |
| 2001 Q2           | 173.9                               |
| 2001 Q3           | 174                                 |
| 2001 Q4           | 173.8                               |
| 2002 Q1           | 173.9                               |
| 2002 Q2           | 176                                 |
| 2002 Q3           | 176.6                               |
| 2002 Q4           | 178.2                               |
| 2003 Q1           | 179.2                               |
| 2003 Q2           | 181.3                               |
| 2003 Q3           | 181.8                               |
| 2003 Q4           | 182.9                               |
| 2004 Q1           | 183.8                               |
| 2004 Q2           | 186.3                               |
| 2004 Q3           | 187.4                               |
| 2004 Q4           | 189.2                               |
| 2005 Q1           | 189.7                               |
| 2005 Q2           | 191.9                               |
| 2005 Q3           | 192.6                               |
| 2005 Q4           | 193.7                               |
| 2006 Q1           | 194.2                               |
| 2006 Q2           | 197.6                               |
| 2006 Q3           | 199.3                               |
| 2006 Q4           | 201.4                               |
| 2007 Q1           | 203                                 |
| 2007 Q2           | 206.3                               |
| 2007 Q3           | 207.1                               |
| 2007 Q4           | 209.8                               |
| 2008 Q1           | 211.1                               |
| 2008 Q2           | 215.3                               |
| 2008 Q3           | 217.4                               |
| 2008 Q4           | 215.5                               |
| 2009 Q1           | 210.9                               |
| 2009 Q2           | 212.6                               |
| 2009 Q3           | 214.4                               |
| 2009 Q4           | 216.9                               |
| 2010 Q1           | 219.3                               |
| 2010 Q2           | 223.5                               |
| 2010 Q3           | 224.5                               |
| 2010 Q4           | 227                                 |
| 2011 Q1           | 230.9                               |
| 2011 Q2           | 234.9                               |
| 2011 Q3           | 236.2                               |
| 2011 Q4           | 238.6                               |
| 2012 Q1           | 239.6                               |
| 2012 Q2           | 242.2                               |
| 2012 Q3           | 243.1                               |
| 2012 Q4           | 246                                 |
| 2013 Q1           | 247.4                               |
| 2013 Q2           | 249.7                               |
| 2013 Q3           | 250.9                               |
| 2013 Q4           | 252.5                               |
| 2014 Q1           | 253.9                               |
| 2014 Q2           | 256                                 |
| 2014 Q3           | 256.9                               |
| 2014 Q4           | 257.4                               |
| 2015 Q1           | 256.4                               |
| 2015 Q2           | 258.5                               |
| 2015 Q3           | 259.3                               |
| 2015 Q4           | 260                                 |
| 2016 Q1           | 260                                 |
| 2016 Q2           | 262.2                               |
| 2016 Q3           | 264.2                               |
| 2016 Q4           | 265.8                               |
| 2017 Q1           | 267.7                               |
| 2017 Q2           | 271.5                               |
| 2017 Q3           | 274.2                               |
| 2017 Q4           | 276.4                               |
| 2018 Q1           | 277.5                               |
| 2018 Q2           | 280.6                               |
| 2018 Q3           | 283.3                               |
| 2018 Q4           | 284.9                               |
| 2019 Q1           | 284.4                               |
| 2019 Q2           | 289                                 |
| 2019 Q3           | 290.7                               |
| 2019 Q4           | 291.1                               |
| 2020 Q1           | 291.7                               |
| 2020 Q2           | 292.5                               |
| 2020 Q3           | 293.9                               |
| 2020 Q4           | 294.4                               |
| 2021 Q1           | 295.8                               |
| 2021 Q2           | 302.3                               |
| 2021 Q3           | 307.2                               |
| 2021 Q4           | 314.7                               |
| 2022 Q1           | 320.5                               |
| 2022 Q2           | 337.2                               |
| 2022 Q3           | 345.3                               |
| 2022 Q4           | 358.3                               |
| 1987 JAN          | 100                                 |
| 1987 FEB          | 100.4                               |
| 1987 MAR          | 100.6                               |
| 1987 APR          | 101.8                               |
| 1987 MAY          | 101.9                               |
| 1987 JUN          | 101.9                               |
| 1987 JUL          | 101.8                               |
| 1987 AUG          | 102.1                               |
| 1987 SEP          | 102.4                               |
| 1987 OCT          | 102.9                               |
| 1987 NOV          | 103.4                               |
| 1987 DEC          | 103.3                               |
| 1988 JAN          | 103.3                               |

*(Note: Truncated after 200 rows for readability)*

---

## Sheet: RPI ANNUAL
|   1987 |   101.9 |
|-------:|--------:|
|   1988 |   106.9 |
|   1989 |   115.2 |
|   1990 |   126.1 |
|   1991 |   133.5 |
|   1992 |   138.5 |
|   1993 |   140.7 |
|   1994 |   144.1 |
|   1995 |   149.1 |
|   1996 |   152.7 |
|   1997 |   157.5 |
|   1998 |   162.9 |
|   1999 |   165.4 |
|   2000 |   170.3 |
|   2001 |   173.3 |
|   2002 |   176.2 |
|   2003 |   181.3 |
|   2004 |   186.7 |
|   2005 |   192   |
|   2006 |   198.1 |
|   2007 |   206.6 |
|   2008 |   214.8 |
|   2009 |   213.7 |
|   2010 |   223.6 |
|   2011 |   235.2 |
|   2012 |   242.7 |
|   2013 |   250.1 |
|   2014 |   256   |
|   2015 |   258.5 |
|   2016 |   263.1 |
|   2017 |   272.5 |
|   2018 |   281.6 |
|   2019 |   288.8 |
|   2020 |   293.1 |
|   2021 |   305   |
|   2022 |   340.3 |

---

## Sheet: MATRIX
|              Key | Vendor                 | Date                |   Amount |   Cumulative Amount | Cheque no       | Type                                                        | Rec.   |
|-----------------:|:-----------------------|:--------------------|---------:|--------------------:|:----------------|:------------------------------------------------------------|:-------|
|      3.81591e+09 | Willingale Associates  | 2004-06-21 00:00:00 | 11225    |             11225   | CB201           | Architect                                                   | C      |
|      3.81662e+07 | Associated Consult.    | 2004-06-28 00:00:00 |   150    |             11375   | CB205           | Company Formation                                           | C      |
|                  | Services Ltd           |                     |          |                     |                 |                                                             |        |
|      3.82994e+08 | Boyarsky Murphy Ltd    | 2004-11-08 00:00:00 |  4241.75 |             15616.8 | CB216           | Architect                                                   | C      |
|      3.82605e+08 | Boyarsky Murphy Ltd    | 2004-09-30 00:00:00 |  4911.5  |             20528.2 | CB149           | Architect                                                   | C      |
|      3.82602e+08 | RPS                    | 2004-09-30 00:00:00 |  1902.24 |             22430.5 | cb221           | Heritage Chris Miele                                        | C      |
|      3.81486e+08 | Boyarsky Murphy ltd    | 2004-06-10 00:00:00 |  5619.32 |             28049.8 | cb224           | Architect                                                   | C      |
|      3.82817e+07 | Locke Carey & Assoc    | 2004-10-21 00:00:00 |   705    |             28754.8 | cb227           | Fire Safety Engineer                                        | C      |
|      3.79971e+08 | RPS                    | 2004-01-11 00:00:00 |  1175    |             29929.8 | cb229           | Heritage Chris Miele                                        | C      |
|      3.81454e+08 | Boyarsky Murphy Ltd    | 2004-06-07 00:00:00 |  4284.05 |             34213.9 | cb210           | Architect                                                   | C      |
|      3.82721e+09 | Willinoale Associates  | 2004-10-12 00:00:00 | 11225    |             45438.9 | cb241           | Architect                                                   | C      |
|      3.83331e+08 | Locke Carey & Assoc    | 2004-12-12 00:00:00 |  1468.75 |             46907.6 | cb243           | Fire Safety Engineer                                        | C      |
|      3.83354e+08 | Alan Baxter & Assoc.   | 2004-12-14 00:00:00 |  4150.36 |             51058   | cb247           | Structural Engineer                                         | C      |
|      3.85651e+08 | RPS                    | 2005-08-01 00:00:00 |  1266.06 |             52324   | cb250           | Heritage Chris Miele                                        | C      |
|      3.85654e+08 | Boyarsky Murphy Ltd    | 2005-08-01 00:00:00 |  4200.62 |             56524.7 | cb252           | Architect                                                   | C      |
|      3.82715e+08 | Boyarsky Murphy Ltd    | 2004-10-11 00:00:00 |  4846.88 |             61371.5 | cb233           | Architect                                                   | C      |
|      3.82425e+08 | Boyarsky Murphy ltd    | 2004-09-12 00:00:00 |  4871.25 |             66242.8 | cb237           | Architect                                                   | C      |
|      3.85354e+07 | Locke Carey & Assoc    | 2005-07-02 00:00:00 |   352.5  |             66595.3 | cb257           | Fire Safety Engineer                                        | C      |
|      3.85355e+08 | Boyarsky Murphy Ltd    | 2005-07-02 00:00:00 |  4670.62 |             71265.9 | cb259           | Architect                                                   | C      |
|      3.83973e+08 | Greenwood              | 2005-02-14 00:00:00 |  3365.2  |             74631.1 | cb261           | Planning                                                    | C      |
|                  | Development Planning   |                     |          |                     |                 |                                                             |        |
|      3.84023e+07 | RPS                    | 2005-02-19 00:00:00 |   264.26 |             74895.4 | cb262           | Heritage Chris Miele                                        | C      |
|      3.85365e+08 | Boyarsky Murphy ltd    | 2005-07-03 00:00:00 |  5106.55 |             80001.9 | cb268           | Architect                                                   | C      |
|      3.8429e+07  | RPS                    | 2005-03-17 00:00:00 |   974.08 |             80976   | cb272           | Heritage Chris Miele                                        | C      |
|      3.84319e+08 | Alan Baxter & Assoc.   | 2005-03-20 00:00:00 |  9242.01 |             90218   | cb273           | Structural Engineer                                         | C      |
|      3.84315e+08 | Greenwood              | 2005-03-20 00:00:00 |  4974    |             95192   | cb275           | Planning                                                    | C      |
|                  | Development Plannino   |                     |          |                     |                 |                                                             |        |
|      3.85071e+09 | Willinoale Associates  | 2005-06-04 00:00:00 | 11225    |            106417   | cb278           | Final Payment                                               | C      |
|      3.84563e+08 | Boyarsky Murphy Ltd    | 2005-04-14 00:00:00 |  3055    |            109472   | cb280           | Architect                                                   | C      |
|      3.84565e+08 | McDonnel Langley       | 2005-04-14 00:00:00 |  4829.25 |            114301   | cb281           | M&E Engineers                                               | C      |
|      3.84773e+08 | Boyarsky Murphy ltd    | 2005-05-05 00:00:00 |  3301.75 |            117603   | a1119           | Architect                                                   | C      |
|      3.84957e+07 | Greenwood              | 2005-05-23 00:00:00 |   725.56 |            118329   | a1124           | Planning                                                    | C      |
|                  | Development Planning   |                     |          |                     |                 |                                                             |        |
|      3.84784e+08 | Boyarsky Murphy Ltd    | 2005-05-06 00:00:00 |  4435.62 |            122764   | a1132           | Architect                                                   | C      |
|      3.85391e+08 | PT Projects            | 2005-07-06 00:00:00 |  1233.75 |            123998   | a1134           | QS                                                          | C      |
|      3.86324e+08 | Boyarsky Murphy ltd    | 2005-10-07 00:00:00 |  4448.62 |            128447   | a1144           | Architect                                                   | C      |
| 385840           | Greig-Ling             | 2005-08-20 00:00:00 |     0    |            128447   | a1153           | Structural Engineer - lost 5753.62                          | nan    |
|      3.85884e+08 | Boyarsky Murphy ltd    | 2005-08-24 00:00:00 |  4465    |            132912   | a1155           | Architect                                                   | C      |
|      3.84204e+08 | Boyarsky Murphy ltd    | 2005-03-09 00:00:00 |  4459.12 |            137371   | a1162           | Architect                                                   | C      |
| 384510           | City of London         | 2005-04-09 00:00:00 |     0    |            137371   | a1163           | License - Foundation Investigation                          | nan    |
|                  |                        |                     |          |                     |                 | cxld 750                                                    |        |
|      3.84519e+07 | City of London         | 2005-04-09 00:00:00 |   881.25 |            138252   | a1164           | License - Foundation Investigation                          | C      |
|      3.84819e+07 | JHAI                   | 2005-05-09 00:00:00 |   888.3  |            139140   | nan             | Approved Inspector                                          | C      |
|      3.86203e+06 | Companies House -      | 2005-09-25 00:00:00 |    30    |            139170   | c284            | Companies House annual filing                               | C      |
|                  | stms                   |                     |          |                     |                 |                                                             |        |
|      3.85444e+08 | Boyarsky Murphy Ltd    | 2005-07-11 00:00:00 |  4476.75 |            143647   | a1173           | Architect                                                   | C      |
|      3.85441e+08 | PT Projects            | 2005-07-11 00:00:00 |  1410    |            145057   | a1174           | QS                                                          | C      |
|      3.85436e+08 | Greio-Lino             | 2005-07-10 00:00:00 |  5758.44 |            150815   | a1179           | Structural Engineer                                         | C      |
|      3.86664e+08 | Boyarsky Murphy Ltd    | 2005-11-10 00:00:00 |  4465    |            155280   | a1182           | Architect                                                   | C      |
|      3.86831e+09 | oerard Huouenin        | 2005-11-27 00:00:00 | 11867.5  |            167148   | a1188           | Ground Works specialist                                     | C      |
|      3.85156e+08 | Boyarsky Murphy ltd    | 2005-06-12 00:00:00 |  6043.62 |            173192   | a1201           | Architect                                                   | C      |
|  45000           | City of London         | NaT                 | 45000    |            218192   | nan             | STMS purchase - cheque to                                   | nan    |
|                  |                        |                     |          |                     |                 | Stella                                                      |        |
|      3.88697e+08 | Greig-Ling             | 2006-06-01 00:00:00 |  7344.69 |            225536   | a1197           | Structural Engineer (5753 +                                 | C      |
|                  |                        |                     |          |                     |                 | license fee)                                                |        |
|      3.88996e+08 | Boyarsky Murphy Ltd    | 2006-07-01 00:00:00 |  5869.12 |            231405   | a1198           | Architect                                                   | C      |
|      3.89614e+08 | PT Projects            | 2006-09-01 00:00:00 |  4406.25 |            235812   | a1200           | QS - final payment                                          | C      |
|      3.85156e+08 | Boyarsky Murphy Ltd    | 2005-06-12 00:00:00 |  6043.62 |            241855   | a1201           | Architect                                                   | C      |
|      3.89006e+08 | Boyarsky Murphy Ltd    | 2006-07-02 00:00:00 |  6423.5  |            248279   | a1208           | Architect                                                   | C      |
| 389620           | Greig-Ling             | 2006-09-02 00:00:00 |     0    |            248279   | a1210           | Pl Insurance for Eng. Returned                              | C      |
|                  |                        |                     |          |                     |                 | £5,875                                                      |        |
|      3.87796e+08 | Boyarsky Murphy Ltd    | 2006-03-03 00:00:00 |  5875    |            254154   | a1215           | Architect                                                   | C      |
|      3.87894e+08 | Eckersley o' callaghan | 2006-03-13 00:00:00 |  4112.5  |            258266   | a1218           | Stair Designers                                             | C      |
|      3.87923e+08 | City of London         | 2006-03-16 00:00:00 |  2820    |            261086   | a1219           | Fee- Foundation Investigation -                             | C      |
|                  |                        |                     |          |                     |                 | SAID never received £2,820 BUT                              |        |
|      3.88374e+08 | gerard Huguenin        | 2006-04-30 00:00:00 |  4059.63 |            265146   | a1225           | Foundation digging                                          | C      |
|      3.89026e+08 | Boyarsky Murphy Ltd    | 2006-07-04 00:00:00 |  5904.38 |            271050   | a1227           | Architect                                                   | C      |
|      3.88274e+07 | St Sepulcre            | 2006-04-20 00:00:00 |   450    |            271500   | a1234           | Storage                                                     | nan    |
| 388360           | gerard Huguenin        | 2006-04-29 00:00:00 |     0    |            271500   | a1236           | further foundation investigation -                          | nan    |
|                  |                        |                     |          |                     |                 | cxld as had no VAT £3,455                                   |        |
|      3.88127e+08 | Boyarsky Murphy Ltd    | 2006-04-05 00:00:00 |  6710.35 |            278211   | a1238           | Architect                                                   | C      |
|      3.88424e+08 | Stella Currie          | 2006-05-05 00:00:00 |  3548    |            281759   | a1239           | Solicitor for DA and Lease                                  | nan    |
|      3.89653e+09 | City of London         | 2006-09-05 00:00:00 | 30000    |            311759   | a1241           | to Stella Currie For Corporation                            | nan    |
|                  |                        |                     |          |                     |                 | legal fees                                                  |        |
|  38525           | Alan Baxter & Assoc.   | 2005-06-22 00:00:00 |   nan    |            311759   | nan             | in dispute £14,523.92                                       | nan    |
|  38664           | Alan Baxter & Assoc.   | 2005-11-08 00:00:00 |   nan    |            311759   | nan             | in dispute £5,532.98                                        | nan    |
|      3.88436e+08 | Boyarsky Murphy Ltd    | 2006-05-06 00:00:00 |  6456.62 |            318215   | a1249           | Architect                                                   | C      |
|      3.8882e+08  | Greig-Ling             | 2006-06-13 00:00:00 |  9608.92 |            327824   | a1276           | Structural Engineer 5753.62 +                               | C      |
|                  |                        |                     |          |                     |                 | fees                                                        |        |
|      3.88933e+06 | Companies House -      | 2006-06-25 00:00:00 |    30    |            327854   | a1280           | admin cono.5160890                                          | C      |
|                  | stms                   |                     |          |                     |                 |                                                             |        |
|      3.88146e+08 | Boyarsky Murphy Ltd    | 2006-04-07 00:00:00 |  6444.9  |            334299   | a1283           | Architect                                                   | C      |
|      3.89366e+08 | Greig-Ling             | 2006-08-07 00:00:00 |  5998.47 |            340297   | a1286           | Structural Engineer - for ARUP                              | C      |
|                  |                        |                     |          |                     |                 | Geotechnics                                                 |        |
|      3.89251e+09 | Greig-Ling             | 2006-07-27 00:00:00 | 11836.5  |            352134   | a1289           | Structural Engineer - for ARUP Geotechnics                  | C      |
|      3.89269e+07 | McDonnel Langley       | 2006-07-28 00:00:00 |   855.99 |            352990   | a1290           | mechanical electrical engineers                             | C      |
|      3.89596e+08 | Boyarsky Murphy Ltd    | 2006-08-30 00:00:00 |  5992.5  |            358983   | a1295           | Architect                                                   | C      |
|      3.89853e+06 | Companies House -      | 2006-09-25 00:00:00 |    30    |            359013   | cb284           | admin cono.5160890                                          | nan    |
|                  | stms                   |                     |          |                     |                 |                                                             |        |
|      3.88466e+08 | Boyarsky Murphy Ltd    | 2006-05-09 00:00:00 |  5857.37 |            364870   | cb297           | Architect                                                   | C      |
|      3.88786e+08 | Boyarsky Murphy Ltd    | 2006-06-10 00:00:00 |  5838.87 |            370709   | cb315           | Architect                                                   | C      |
|      3.89713e+08 | City of London         | 2006-09-11 00:00:00 |  2820    |            373529   | cb325           | STMS AIP                                                    | nan    |
|      3.89716e+08 | Boyarsky Murphy Ltd    | 2006-09-11 00:00:00 |  5845.62 |            379374   | cb327           | Architect                                                   | C      |
|      3.90513e+08 | michael barclay        | 2006-11-30 00:00:00 |  3025.27 |            382400   | cb331           | Keith Jerimiah AIP / Highway                                | C      |
|                  | partnership            |                     |          |                     |                 |                                                             |        |
|      3.90717e+08 | Boyarsky Murphy Ltd    | 2006-12-20 00:00:00 |  6515.37 |            388915   | cb340           | Architect                                                   | C      |
| 390990           | Boyarsky Murphy Ltd    | 2007-01-17 00:00:00 |     0    |            388915   | cb344           | Architect torn up not paid                                  | nan    |
|                  |                        |                     |          |                     |                 | £6,515.37                                                   |        |
| 391150           | Boyarsky Murphy Ltd    | 2007-02-02 00:00:00 |     0    |            388915   | not paid        | £1850.62 BMA overpaid already                               | nan    |
|      3.90331e+09 | Alan Baxter & Assoc.   | 2006-11-12 00:00:00 | 10000    |            398915   | cb 336          | Full and final settlement for                               | C      |
|                  |                        |                     |          |                     |                 | STMS and CCT                                                |        |
|      3.90691e+08 | Birketts               | 2006-12-18 00:00:00 |  1288.97 |            400204   | cb338           | Lawyers                                                     | nan    |
|      3.91111e+09 | Khalid Aslam           | 2007-01-29 00:00:00 | 10000    |            410204   | cb346           | Consultant                                                  | C      |
|      3.91276e+09 | CPM Ltd                | 2007-02-14 00:00:00 | 55000    |            465204   | cb 351          | Project Managers                                            | C      |
| 391270           | CPM Ltd                | 2007-02-14 00:00:00 |     0    |            465204   | cb352           | replaced by STMS Cheque £55k                                | nan    |
|                  |                        |                     |          |                     |                 | stms cb 22                                                  |        |
|      3.91952e+08 | JHAI                   | 2007-04-23 00:00:00 |  1776.6  |            466981   | nan             | Approved Inspector                                          | C      |
|      3.92202e+08 | michael barclay        | 2007-05-18 00:00:00 |  2277.55 |            469258   | cb378           | AIP temp. Retaining wall                                    | C      |
|                  | partnership            |                     |          |                     |                 |                                                             |        |
|      3.924e+06   | Boyarsky Murphy Ltd    | 2007-06-06 00:00:00 |    98.53 |            469357   | cb380           | copying documents                                           | C      |
|      3.94227e+08 | CPM Ltd                | 2007-12-06 00:00:00 |  7000    |            476357   | stms cb001      | Overage payment prof fees -                                 | C      |
|                  |                        |                     |          |                     |                 | Mgmt Contract                                               |        |
|      3.91487e+08 | Khalid Aslam           | 2007-03-07 00:00:00 |  7000    |            483357   | cb385           | nan                                                         | C      |
|      3.92763e+08 | WSP                    | 2007-07-13 00:00:00 |  2511.56 |            485868   | stms cb 002     | CAD drawings - structural -                                 | C      |
|                  |                        |                     |          |                     |                 | NK2487                                                      |        |
|      3.92766e+08 | WSP                    | 2007-07-13 00:00:00 |  5875    |            491743   | stms cb 003     | Architects fees -April/May -                                | C      |
|                  |                        |                     |          |                     |                 | LE494 AND LE476                                             |        |
|      3.92101e+07 | HMRC                   | 2007-05-08 00:00:00 |   100    |            491843   | stms cb 004     | Late filing fee                                             | C      |
|      3.93425e+08 | WSP                    | 2007-09-17 00:00:00 |  4950    |            496793   | stms cb 005     | Structural Survey ex-Vat Invoice                            | C      |
|                  |                        |                     |          |                     |                 | NK2517                                                      |        |
|      3.93429e+07 | WSP                    | 2007-09-17 00:00:00 |   866.25 |            497659   | stms cb 006     | Structural Survey Vat - NB2517                              | C      |
|      3.93427e+08 | WSP                    | 2007-09-17 00:00:00 |  6750    |            504409   | stms cb 007     | Desk Study, ex-Vat structural -                             | C      |
|                  |                        |                     |          |                     |                 | NK2486                                                      |        |
|      3.93421e+08 | WSP                    | 2007-09-17 00:00:00 |  1181.25 |            505591   | stms cb 008     | Desk Study Vat structural-                                  | C      |
|                  |                        |                     |          |                     |                 | NK2486                                                      |        |
|      3.93426e+08 | WSP                    | 2007-09-17 00:00:00 |  5549.68 |            511140   | stms cb 009     | June Architecture Fees ex Vat -                             | C      |
|                  |                        |                     |          |                     |                 | LE512A                                                      |        |
|      3.93421e+08 | WSP                    | 2007-09-17 00:00:00 |  1177.2  |            512318   | stms cb 010     | June Architecture Fees Vat -                                | C      |
|                  |                        |                     |          |                     |                 | LE512A                                                      |        |
|      3.93426e+08 | WSP                    | 2007-09-17 00:00:00 |  5888.96 |            518207   | stms cb 011     | July Architect Fees ex Vat -                                | C      |
|                  |                        |                     |          |                     |                 | LE524                                                       |        |
|      3.93421e+08 | WSP                    | 2007-09-17 00:00:00 |  1249.17 |            519456   | stms cb 012     | July Architect Fees Vat - LE524                             | C      |
|      3.93424e+08 | WSP                    | 2007-09-17 00:00:00 |  3920    |            523376   | stms cb 013     | half Aug Architect Fees ex Vat -                            | C      |
|                  |                        |                     |          |                     |                 | LE538                                                       |        |
|      3.93427e+07 | WSP                    | 2007-09-17 00:00:00 |   686    |            524062   | stms cb 014     | Aug Architect Fees Vat - LE538                              | C      |
|      3.93525e+08 | Greenwood              | 2007-09-27 00:00:00 |  5052.5  |            529114   | stms cb 015     | full & final settlement to date                             | C      |
|                  | Development Planning   |                     |          |                     |                 | Planning                                                    |        |
|      3.91837e+08 | City of London         | 2007-04-11 00:00:00 |  7046.4  |            536161   | stms cb 016     | Stopping up order                                           | C      |
|      3.92133e+08 | WSP                    | 2007-05-11 00:00:00 |  3328.59 |            539489   | stms cb 017     | Architects CAD conversion Inv NK2516 (half)                 | C      |
|      3.92443e+08 | WSP                    | 2007-06-11 00:00:00 |  3328.6  |            542818   | stms cb 018     | Architects CAD conversion Inv                               | C      |
|                  |                        |                     |          |                     |                 | NK?516                                                      |        |
|      0           | McDonnel Langley       | NaT                 |     0    |            542818   | stms cb 019     | torn up                                                     | nan    |
|      0           | McDonnel Langley       | NaT                 |     0    |            542818   | stms cb 020     | torn up                                                     | nan    |
|      3.94274e+08 | Birketts               | 2007-12-11 00:00:00 |  3710.65 |            546528   | stms cb 021     | legal fees bma letters                                      | C      |
| 394010           | CPM Ltd                | 2007-11-15 00:00:00 |     0    |            546528   | stms cb 022     | £55K replacement cheque for cb 352 This has been returned & | nan    |
|                  |                        |                     |          |                     |                 | 1"'.Ylrl                                                    |        |
|      3.94014e+07 | City of London         | 2007-11-15 00:00:00 |   380    |            546908   | stms cb 023     | 12 mo. Hoarding license                                     | C      |
| 394010           | vat blank fot topo     | 2007-11-15 00:00:00 |     0    |            546908   | stms cb 024     | 750 fee plus vat 131.25                                     | nan    |
|                  | r , ·-                 |                     |          |                     |                 |                                                             |        |
|      3.94011e+09 | McDonnel Langley       | 2007-11-15 00:00:00 | 11480    |            558388   | stms cb 025     | CPM Ltd for for M&E McDonnell                               | C      |
|                  |                        |                     |          |                     |                 | langley                                                     |        |
|      3.94012e+08 | McDonnel Langley       | 2007-11-15 00:00:00 |  2009    |            560397   | stms cb 026     | CPM for VAT on M&E                                          | C      |
| 394010           | vat for Topo survey    | 2007-11-15 00:00:00 |     0    |            560397   | stms cb 027     | vat for topo - a duplicate??                                | nan    |
|                  |                        |                     |          |                     |                 | 131.25 o/s                                                  |        |
|      0           | blank                  | NaT                 |     0    |            560397   | stms cb 028     | Torn up                                                     | nan    |
|      3.91844e+08 | Khalid Aslam           | 2007-04-12 00:00:00 |  4000    |            564397   | stms cb 029     | repay cash payments grd works                               | C      |
|      3.91841e+07 | Thames Water           | 2007-04-12 00:00:00 |   117.5  |            564515   | stms cb 030     | quotation fee                                               | nan    |
|      3.94714e+07 | City of London         | 2008-01-24 00:00:00 |   380    |            564895   | stms cb 031     | I year skip license                                         | C      |
|      3.94932e+08 | EDF                    | 2008-02-15 00:00:00 |  1552.18 |            566447   | stms cb 032     | 3 phase 100 amp temp electric                               | C      |
|      3.95268e+08 | Khalid Aslam           | 2008-03-19 00:00:00 |  8000    |            574447   | cash            | for utilites connections, trenches                          | C      |
|                  |                        |                     |          |                     |                 | etc. Prelims.                                               |        |
|      3.95101e+09 | WSP                    | 2008-03-03 00:00:00 | 10687    |            585134   | cash xfer       | Birketts holding for o/s WSP                                | C      |
|                  |                        |                     |          |                     |                 | invoices NK2682 NK2809 and                                  |        |
| 395550           | Khalid Aslam           | 2008-04-17 00:00:00 |     0    |            585134   | stms cb 033     | grd works £25k cxld                                         | nan    |
| 395550           | Khalid Aslam           | 2008-04-17 00:00:00 |     0    |            585134   | stms cb 034     | grd works £25k cxld                                         | nan    |
| 395550           | Khalid Aslam           | 2008-04-17 00:00:00 |     0    |            585134   | stms cb 035     | grd works £35k cxld                                         | nan    |
| 395550           | Khalid Aslam           | 2008-04-17 00:00:00 |     0    |            585134   | stms cb 036     | grd works £15k cxld                                         | nan    |
| 396050           | WSP                    | 2008-06-06 00:00:00 |     0    |            585134   | stms cb 037     | arch o/s inv LE552 £3,920                                   | nan    |
| 396050           | WSP                    | 2008-06-06 00:00:00 |     0    |            585134   | stms cb 038     | arch o/s inv LE552 - vat £686                               | nan    |
| 396050           | WSP                    | 2008-06-06 00:00:00 |     0    |            585134   | stms cb 039     | struc NK2682 + NK 2809                                      | nan    |
|                  |                        |                     |          |                     |                 | £2,587.50 x2                                                |        |
| 396050           | WSP                    | 2008-06-06 00:00:00 |     0    |            585134   | stms cb 040     | struc NK2682 + NK2809 vat 452.81x2                          | nan    |
|      3.96973e+07 | City of London         | 2008-09-06 00:00:00 |   333.92 |            585468   | stms cb 041     | survey manholes 1803 / 04                                   | C      |
|      3.96971e+07 | Drainage Express Ltd   | 2008-09-06 00:00:00 |   108.69 |            585577   | stms cb 042     | 1/2 fee inspection waste systems                            | C      |
|      3.96231e+09 | Khalid Aslam           | 2008-06-24 00:00:00 | 11000    |            596577   | cb433           | cash                                                        | C      |
|      3.96241e+07 | Drainage Express Ltd   | 2008-06-25 00:00:00 |   138.69 |            596715   | stms cb 043     | 1/2 fee inspection waste systems                            | C      |
|      3.96473e+08 | Khalid Aslam           | 2008-07-18 00:00:00 |  3300    |            600015   | cash            | ground works                                                | C      |
|      3.96811e+08 | Khalid Aslam           | 2008-08-21 00:00:00 |  1200    |            601215   | stms cb 045     | consultants - engineer for temporary works                  | C      |
|      3.95162e+09 | Khalid Aslam           | 2008-03-09 00:00:00 | 18963    |            620178   | stms cb 046     | drainage works                                              | C      |
|      3.95165e+08 | Khalid Aslam           | 2008-03-09 00:00:00 |  5000    |            625178   | stms cb 047     | cash for sewage work                                        | C      |
|      3.95771e+09 | Nabarro                | 2008-05-09 00:00:00 | 13343.3  |            638522   | stms cb 048     | cct legal                                                   | C      |
| 395770           | K Renwick              | 2008-05-09 00:00:00 |     0    |            638522   | stms cb 049     | part loan repayment £25,000                                 | C      |
|      3.97163e+08 | Birketts               | 2008-09-25 00:00:00 |  2574.43 |            641096   | stms cb 050     | forwsp                                                      | C      |
|      3.97164e+07 | Birketts               | 2008-09-25 00:00:00 |   370.12 |            641466   | stms cb 051     | korubuild ref stms                                          | C      |
|      3.97162e+09 | Khalid Aslam           | 2008-09-25 00:00:00 | 15000    |            656466   | stms cb 052     | consltants hse / cdm - £8,000 credit                        | C      |
| 397380           | Khalid Aslam           | 2008-10-17 00:00:00 |     0    |            656466   | stms cb 053     | £35K replacement cheque for no.                             | nan    |
|                  |                        |                     |          |                     |                 | 35 Incomplete cheque rejected                               |        |
|      3.97382e+09 | Khalid Aslam           | 2008-10-17 00:00:00 | 15000    |            671466   | stms cb 054     | replacement cheque for no. 36                               | C      |
|      3.97382e+09 | Khalid Aslam           | 2008-10-17 00:00:00 | 25000    |            696466   | stms cb 055     | replacement cheque for no. 33                               | C      |
|      3.97382e+09 | Khalid Aslam           | 2008-10-17 00:00:00 | 25000    |            721466   | stms cb 056     | replacement cheque for no. 34                               | C      |
|      3.97382e+09 | Khalid Aslam           | 2008-10-17 00:00:00 | 25000    |            746466   | stms cb 057     | replacement cheque for no. ?                                | C      |
|                  |                        |                     |          |                     |                 | (dup)                                                       |        |
|      3.97384e+09 | Khalid Aslam           | 2008-10-17 00:00:00 | 35000    |            781466   | stms cb 058     | replacement cheque for no. 35 /                             | C      |
|                  |                        |                     |          |                     |                 | 53                                                          |        |
|      3.94584e+09 | Khalid Aslam           | 2008-01-11 00:00:00 | 35000    |            816466   | stms cb 059     | replacement cheque for no. 53 (dup)                         | C      |
|      3.95491e+08 | Warner Land Surveys    | 2008-04-11 00:00:00 |  1000    |            817466   | stms cb 060     | Topo survey first payment of total                          | C      |
|                  | Ltd                    |                     |          |                     |                 | £3000 cost                                                  |        |
| 397630           | Shere Group Ltd        | 2008-11-11 00:00:00 |     0    |            817466   | temp cheques    | Simon - engineer £900 -                                     | nan    |
|                  |                        |                     |          |                     | 59321           | RETURNED replace -chk 123                                   |        |
| 399680           | Khalid Aslam           | 2009-06-04 00:00:00 |     0    |            817466   | stms cb 149     | March 25K                                                   | nan    |
| 399680           | Khalid Aslam           | 2009-06-04 00:00:00 |     0    |            817466   | stms cb 150     | March 25K                                                   | nan    |
| 399680           | Khalid Aslam           | 2009-06-04 00:00:00 |     0    |            817466   | stms cb 151     | March 25K                                                   | nan    |
| 399680           | Khalid Aslam           | 2009-06-04 00:00:00 |     0    |            817466   | stms cb 152     | March 30K                                                   | nan    |
|      3.99202e+08 | SME Invoice Finance    | 2009-04-17 00:00:00 |  2127.5  |            819594   | stms cb 153     | Topo Survey CADSurveys Ltd                                  | C      |
|                  | Ltd                    |                     |          |                     |                 |                                                             |        |
|      3.98512e+06 | Companies House -      | 2009-02-07 00:00:00 |    15    |            819609   | stms cb 154     | to CAS 4 Annual Return                                      | C      |
|                  | stms                   |                     |          |                     |                 |                                                             |        |
| 398210           | Khalid Aslam           | 2009-01-08 00:00:00 |     0    |            819609   | stms cb 155     | Loan Repay 5k + Molas 3396                                  | nan    |
|                  |                        |                     |          |                     |                 | (£8,396)                                                    |        |
| 398210           | Khalid Aslam           | 2009-01-08 00:00:00 |     0    |            819609   | stms cb 156     | Loan Repay - Dup SK                                         | nan    |
|      4.00522e+08 | Brian Hendry Architect | 2009-08-27 00:00:00 |  1600    |            821209   | stms cb 157     | nan                                                         | C      |
|      4.00868e+07 | Brian Hendry Architect | 2009-09-30 00:00:00 |   800    |            822009   | stms cb 158     | paid at Sal Meeting                                         | C      |
|      4.00864e+07 | Brian Hendry Architect | 2009-09-30 00:00:00 |   350    |            822359   | stms cb 159     | paid at Sal Meeting                                         | C      |
|      4.01052e+08 | Brian Hendry Architect | 2009-10-19 00:00:00 |  1734    |            824093   | stms cb 160     | Cash paid into Brian Bos acct for                           | C      |
|                  |                        |                     |          |                     |                 | invoices 03 and 04                                          |        |
|      4.01421e+08 | City of London         | 2009-11-25 00:00:00 |  1400    |            825493   | stms cb 161     | Hoarding I skip lie to nov 11 2010                          | C      |
|      4.01628e+08 | Birketts               | 2009-12-15 00:00:00 |  7812.12 |            833305   | stms cb 162     | Legal fees wsp/city for stms                                | C      |
|      4.03028e+08 | Khalid Aslam           | 2010-05-04 00:00:00 |  8396    |            841701   | stms cb 163     | Replacement cheque for 155 Loan and Molas £3905.40 of       | C      |
|                  |                        |                     |          |                     |                 | I which VAT is i:;nq 40                                     |        |
|      4.03027e+08 | Birketts               | 2010-05-04 00:00:00 |  6505.97 |            848207   | stms cb 164     | Vat is 968.97                                               | C      |
|  40386           | Birketts               | 2010-07-27 00:00:00 |   nan    |            848207   | stms cb 165     | cxld                                                        | nan    |
|      4.03861e+08 | Birketts               | 2010-07-27 00:00:00 |  1189.68 |            849397   | stms cb 166     | inv no. 156253 dated 29.apr.10                              | C      |
|                  |                        |                     |          |                     |                 | vat=                                                        |        |
|      4.03862e+06 | CASolutions            | 2010-07-27 00:00:00 |    15    |            849412   | stms cb 167     | stms 2010 annual accounts                                   | C      |
|      4.02453e+08 | Birketts               | 2010-03-08 00:00:00 |  2763    |            852175   | stms cb 168     | may-26june (10 hrs), Inv 159394.                            | C      |
|                  |                        |                     |          |                     |                 | vat=411.60                                                  |        |
| 406310           | K Renwick              | 2011-03-29 00:00:00 |     0    |            852175   | stms cb 169     | part loan re-payment £6000                                  | C      |
|      4.06314e+07 | City of London         | 2011-03-29 00:00:00 |   400    |            852575   | stms cb 170     | Hoarding I skip lie 29 Mar 11 29                            | nan    |
|                  |                        |                     |          |                     |                 | June 2011                                                   |        |
|  40659           | K Renwick              | 2011-04-26 00:00:00 |   nan    |            852575   | stms cb 171     | part loan re-payment £3000                                  | nan    |
|  40679           | K Renwick              | 2011-05-16 00:00:00 |   nan    |            852575   | stms cb 172     | part loan re-payment £4600                                  | nan    |
|      4.07231e+08 | City of London         | 2011-06-29 00:00:00 |  1200    |            853775   | stms cb 173     | Hoarding I skip lie 29 June 2011                            | nan    |
|                  |                        |                     |          |                     |                 | to 29 sept 11                                               |        |
|  40722           | nan                    | 2011-06-28 00:00:00 |   nan    |            853775   | credit          | £8500 loan from RCLO                                        | nan    |
|                  |                        |                     |          |                     | transferred in  |                                                             |        |
|  40751           | nan                    | 2011-07-27 00:00:00 |   nan    |            853775   | credit          | £8500 loan from RCLO                                        | nan    |
|                  |                        |                     |          |                     | transferred in  |                                                             |        |
|      4.07511e+06 | CA Solutions           | 2011-07-27 00:00:00 |    14    |            853789   | stms cb 174     | STMS annual accounts                                        | nan    |
|      4.16755e+08 | Customs & Excise       | 2014-02-05 00:00:00 |  5000    |            858789   | online transfer | VATI owed £5376.00 5k bank                                  | nan    |
|                  |                        |                     |          |                     |                 | limit                                                       |        |
|      4.16754e+07 | Customs & Excise       | 2014-02-05 00:00:00 |   376    |            859165   | online transfer | VAT owed                                                    | nan    |
|      4.18562e+08 | RM Eaton               | 2014-08-05 00:00:00 |  1740    |            860905   | online transfer | stone masons                                                | nan    |
|      4.17042e+08 | Cistec Ltd             | 2014-03-06 00:00:00 |  1783.8  |            862688   | online transfer | Structural Engineer                                         | nan    |
|      4.17043e+08 | Pilbrow & Partners LLP | 2014-03-06 00:00:00 |  2721.6  |            865410   | online transfer | architects invoice no.                                      | nan    |
|      4.19494e+07 | Mr le Scully           | 2014-11-06 00:00:00 |   360    |            865770   | online transfer | ?                                                           | nan    |
|      4.18135e+07 | Integral Engine        | 2014-06-23 00:00:00 |   456    |            866226   | online transfer | site work                                                   | nan    |
|      4.19192e+07 | City of London         | 2014-10-07 00:00:00 |   195    |            866421   | stms cb 082     | NON MATERIAL AMMENDMENT PLANNING APPLICATION                | nan    |
|      4.18465e+08 | Pilbrow & Partners LLP | 2014-07-26 00:00:00 |  5258.4  |            871679   | online transfer | done in 2 payments (5k +                                    | nan    |
|                  |                        |                     |          |                     |                 | 258.40)                                                     |        |
|      4.18283e+08 | Cistec Ltd             | 2014-07-08 00:00:00 |  2675.7  |            874355   | online transfer | Structural Engineer                                         | nan    |
|      4.18714e+08 | Pilbrow & Partners LLP | 2014-08-20 00:00:00 |  4231.2  |            878586   | online transfer | Architects invoice no.                                      | nan    |
|      4.19002e+08 | Pilbrow & Partners LLP | 2014-09-18 00:00:00 |  2326.8  |            880913   | online transfer | Architects invoice no.                                      | nan    |
|      4.19042e+08 | Birketts               | 2014-09-22 00:00:00 |  1800    |            882713   | online transfer | Legal fees City DA/Lease                                    | nan    |
|      4.17081e+08 | Cistec Ltd             | 2014-03-10 00:00:00 |  1486.5  |            884200   | online transfer | Structural Engineer                                         | nan    |
|      4.19405e+06 | digital river          | 2014-10-28 00:00:00 |    46    |            884246   | online transfer | cpu equipment                                               | nan    |
|      4.19403e+08 | Pilbrow & Partners LLP | 2014-10-28 00:00:00 |  2604    |            886850   | stms cb 083     | Inv 10114Architects                                         | nan    |
|      4.19685e+06 | digital river          | 2014-11-25 00:00:00 |    46    |            886896   | online transfer | cpu equipment                                               | nan    |
|      4.19714e+07 | Bradley Moore          | 2014-11-28 00:00:00 |   400    |            887296   | online transfer | prelims                                                     | nan    |

*(Note: Truncated after 200 rows for readability)*

---
