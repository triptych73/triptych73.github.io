# Source: arc for step 3.pdf [PDF]
**Path:** `arc for step 3.pdf`
---

### Page 1

[IMAGE CONTENT - REQUIRES OCR]