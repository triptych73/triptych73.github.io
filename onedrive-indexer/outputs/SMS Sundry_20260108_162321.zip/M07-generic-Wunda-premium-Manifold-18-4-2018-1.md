# Source: M07-generic-Wunda-premium-Manifold-18-4-2018-1.pdf [PDF]
**Path:** `M07-generic-Wunda-premium-Manifold-18-4-2018-1.pdf`
---

### Page 1

1
Before you start:
Check the contents
Check the manifold box contents against the list below.
1. 2 x Manifold end blanks
2. 2 x Manual air vent & drain cocks
3. 2x Adjustable mounting brackets
4. Manifold flow & return bar assembly 
5. Flow gauges
6. Manual return valves
7. Euro cone connectors
In the unlikely event of any shortage please contact us and a replacement will be despatched immediately. Tel. 0800 5420 816
5. Flow gauges
1. Manifold end blanks
2. Manual air vents 
& drain cocks
1. Manifold end blanks
3. Adjustable Mounting Brackets
3. Adjustable Mounting 
Brackets
M07
Wunda Premium Manifold
✆ 0800 5420 816       www.wundafloorheating.co.ukTHE BRAND YOU CAN TRUST
Optional Electronic 
Actuator (left) or Auto 
Balancing 
Actuator (right)
(second fix)
4. Manifold flow and 
return assembly
7. E uro cone connectors
6. Manual return valves
IMPORTANT:
The manifold supplied has 
adjustable brackets which must 
be adjusted to fit the pump set 
you have purchased BEFORE 
mounting the manifold, or fitting 
any pipe work.
(If this has been purchased as a 
heat pump manifold, then the 
bracket can be set at the most 
convenient size)
Adjust both brackets evenly 
ensuring the bars remain parallel 
and level.
Wunda pumpset flow and return 
bars are set at 230mm between 
bar centres
Revision date: 18/4/2018


### Page 2

2
M07
Wunda Premium Manifold
✆ 0800 5420 816       www.wundafloorheating.co.ukTHE BRAND YOU CAN TRUST
Understanding how the  
manifold & Pumpset work
Warm water is pumped from the heat source to the manifold 
and pumpset assembly. If the system requires a top up of 
heated water, the temperature control valve will allow more 
heated water into the floor heating system via a one-way 
valve or release cooled water back to the heat source for 
re-heating.
Temperature input is easily increased or decreased by turning 
the mixer valve control head. Clockwise closes the valve and 
decreases the flow temperature, anti-clockwise opens the 
valve and increases flow temperature (see page .
From the upper flow bar, warm water is distributed to each loop 
of floor heating pipe via a flow gauge. The water then returns via 
the return valves into the lower return bar.
When the room reaches the required temperature the room 
thermostat sends a signal to the wiring centre to switch off 
the circulating pump and close the actuators. This shuts 
off the water supply to the loops of pipe in the floor and 
therefore shuts off the heat supply to that zone.
Before assembly of the manifold, pumpset or pressure testing, 
familiarise yourself with the various stages of assembly and 
the relevant fact sheet. We also advise to watch the online 
tutorials and technical support videos.
Free Technical support - 0800 5420 816
Warm water from  
heat source enters
Cool water returns to 
the heat source for 
reheating
(Isolation valves are  
an optional extra)
Please note: 
Pump set not included with manifold
Flow Bar
Return Bar
Manual air vent with hose 
attachment for filling and 
draining the system
Manual air vent with hose 
attachment for filling and 
draining the system
Revision date: 18/4/2018

### Page 3

   
3
Manifold Mounting &  
Pipe Connection
If you are mounting the manifold directly to the wall, make 
sure the bottom bar of the manifold is a minimum of 600mm
from the floor.
Before connecting floor pipes to the manifold ensure each 
loop of pipe has been identified using a permanent marker 
and that flow and return is clearly marked.
Open Wunda pipe cutters by pulling the handles fully open 
(pic B), ensure all pipes are cut cleanly and squarely being 
careful not to cut the pipe short or it will not reach the 
manifold.
The freshly cut end of pipe must now be reamed using a 
Wunda reamer (pic C) insert the reamer fully into the end of 
the pipe so that the pipe is in contact with the 3 cutting teeth 
(pic D) push and turn the reamer clockwise 2-3 full turns, this 
will give the pipe a chamfered finish.
A good tip is to grip the pipe wearing a rubber glove, this will 
stop the pipe twisting in your hand.
Place the threaded pipe connector over the prepared pipe 
followed by the olive, push pipe insert into the end of the pipe 
ensuring it is fully seated against the end of the pipe (pic E).
Pipe is now ready to be connected to the manifold ensure the 
connector is tightened sufficiently using a 27mm spanner (pic 
F,G & H)
M07
Wunda Premium Manifold
✆ 0800 5420 816       www.wundafloorheating.co.ukTHE BRAND YOU CAN TRUST
A
D E
F G H
B C
Wall Fixing
Wall Fixing
Olive
Threaded
Pipe
Connector
Pipe
insert
✘
✔
If mounting into Wunda’s waterproof cabinet, use this 
factsheet in conjunction with fact sheet T08
For total peace of mind we recommend that manifolds 
should be installed into a Wunda Waterproof cabinet, 
these cabinets have an integral drain off and water 
curtain. (refer to fact sheet T08)
Revision date: 18/4/2018

### Page 4

4
Manifold Pressure Test Remove lower temperature gauge and unscrew brass housing 
(pic E) Screw pressure gauge* into the exposed aperture, PTFE 
may be required to seal) (pic F)
*not supplied with manifold but available from Wunda
Connect the mains supply hose to the top flow bar red tap. 
Connect the drain off hose to the lower return bar blue tap, 
place the end of the drain hose into a bucket. Open both the 
red and blue drain taps, turn on the mains water supply to the 
fill hose.
Starting at the pump side of the manifold, open the first, flow 
gauge using the correct flow gauge adjusting tool . 
Open the corresponding manual return valve, directly below 
the flow gauge that has been opened. (pic G)
M07
Wunda Premium Manifold
✆ 0800 5420 816       www.wundafloorheating.co.ukTHE BRAND YOU CAN TRUST
Before pressure testing ensure all floor heating loops have 
been laid and all connections and pipes are tightened.
Ensure isolation valves are fully closed  (pic A)
Close both manual Air vents and both 
drain/fill taps (pic B) close all flow 
gauges  by turning sight glass clockwise 
(pic C) and turning black plastic lock 
ring at base of sight glass clockwise until 
shut. Turn white return valve manual 
heads (pic D) by turning clockwise again 
until shut.
A
C D
B
G
Lock
Clip
Remove temp gauge
E
F
Revision date: 18/4/2018

### Page 5

   
5
Allow the pressure to rise to 3-4 bar, (pic K) close the red tap 
on the flow bar (pic L). Turn off the mains water supply hose at 
source and leave the system under pressure for a minimum of 
3 hours. 
If pressure drops investigate and remedy, the mains water 
supply hose can be removed, leave the drain hose in place as 
this will be required to release the pressure at a later stage.
It is good practice to leave the system under pressure whilst 
laying of final floor finish to indicate any possible damage to 
the loops of pipe.
When you are fully satisfied that the system is pressure tight. 
Shut all flow gauges, return valves, isolation valves. release 
the manifold pressure through a drain hose connected to the 
return bar blue drain cock. Briefly open the drain tap, then 
re-close. remove the pressure gauge and re-fit temperature 
gauge and housing. Now it can be connected to the heat 
source by a qualified professional and a suitable inhibitor 
added.
When a steady flow is achieved and ALL air has been passed, 
close the manual return valve on the return bar, leaving the flow 
gauge open. (pic G previous page) Repeat this exercise with each 
individual loop, one at a time.
Once all floor heating loops have been filled with water and 
purged of any air, close the blue drain tap on the lower return 
bar. Open the manual air vents in turn, any air trapped in the 
flow or return bar will be forced out of the air vents, close the 
air vents after ALL air has been expelled. (pic J)
M07
Wunda Premium Manifold
✆ 0800 5420 816       www.wundafloorheating.co.ukTHE BRAND YOU CAN TRUST
The flow gauge will start to move erratically until a steady flow 
of water is achieved through this loop of pipe. (pic H)
By placing the end of the drain hose in the bucket it is 
possible to see when all air has been purged from this loop 
by the reduction in bubbles. (pic I)
J
K
L
I
H
Revision date: 18/4/2018
PLEASE NOTE:
Do not leave an un-commissioned system filled with water 
and unprotected from freezing conditions - introduce & 
circulate a suitable inhibited antifreeze or alternatively 
the water should be forced out of the UFH pies using a 
compressor.
Free technical support call 0800 083 2677

### Page 6

6
Standard Actuators - Manual flow rate setting Flow input temperature setting
*NOTE 
Flow rates may be increased or decreased to adjust performance. 
A flow and return temperature differential of approx 7
0C is 
preferred.
If two pipe circuits are attached to one port with a ‘Y’ connector, 
then both lengths should be added when working out flow rate.
**NOTE  
The maximum advisable circuit lengths are: 
16mm pipe – 100m per circuit 
12mm pipe – 60m per circuit
Length of heating** 
circuit (Metres)
Approximate Flow Rate Guide*
20
30
40
50
60
70
80
90
100
110
120
0.5
0.6
0.8
1.2
1.4
1.7
1.9
2.3
2.5
2.8
3.0
Flow rate 
(litres per min)
IMPORTANT: Adjust by hand only and do not force beyond 
two full turns from shut as this may cause damage to the 
flow meter.
Do not use pliers or grips to adjust flow gauges.
 
T
o adjust, remove lock clip (see pic.1) and turn black nut 
 
of flo
w meter by hand (see pic 2). 
- clockwise to decrease flow rate.
- anti-clockwise to increase flow rate. 
•
F
low rate is indicated by red marker in flow meter.
• Check with table in pic 3. t
o match Lts / Min with length 
of each pipe run. 
• R
efit lock clip to hold each flow meter at adjusted setting.
Lock 
Clip
M07
Wunda Premium Manifold
✆ 0800 5420 816       www.wundafloorheating.co.ukTHE BRAND YOU CAN TRUST
To protect final floor finish and have the correct settings for floor 
constructions, the mixer valve must be set correctly. Flow temperature 
input is adjusted by turning the black temperature control knob. 
Clockwise reduces flow temperature and anti clockwise increases flow 
temperature. 
Adjust the flow temperature to suit the floor construction and floor 
finish. Flow temperature is indicated by the temperature gauge on the 
top flow elbow. 
• Pipe in Overfloor panel systems 35°C*.
• Pipe in Solid screed construction (staples, cliptrack,  multipanel) 45°C*.
• Pipe in Joisted floor construction (spreader plate, foiltec) 65°C*.
* Check with floor finish suppliers before introducing 
warm water into the floor heating system as some flooring 
materials, in particular wood, require limiting of floor surface 
temperatures. Floor surface temperatures can be automatically 
controlled with the installation of our floor probe and correct 
thermostat programming.
Clockwise 
decreases flow 
temperature
Anti clockwise 
increases flow 
temperature
1a
2a
3a
Revision date: 18/4/2018

### Page 7

   
7
Auto Balancing Actuator - Installation
M07
Wunda Premium Manifold
✆ 0800 5420 816       www.wundafloorheating.co.ukTHE BRAND YOU CAN TRUST
Flow input temperature setting
*NOTE  
Flow rates may be increased or decreased to adjust performance. 
A flow and return temperature differential of approx 7
0C is 
preferred.
If two pipe circuits are attached to one port with a ‘Y’ connector, 
then both lengths should be added when working out flow rate.
**NOTE  
The maximum advisable circuit lengths are: 
16mm pipe – 100m per circuit 
12mm pipe – 60m per circuit
To protect final floor finish and have the correct settings for floor 
constructions, the mixer valve must be set correctly. Flow temperature 
input is adjusted by turning the black temperature control knob. 
Clockwise reduces flow temperature and anti clockwise increases flow 
temperature. 
Adjust the flow temperature to suit the floor construction and floor 
finish. Flow temperature is indicated by the temperature gauge on the 
top flow elbow. 
Wunda Auto Balancing Actuators have sensors that constantly measure the temperature and adjust the actuator position to maintain a constant 
temperature differential (pic 3a) of delta T set to 7°C between the flow and return floor heating pipes. This ensures correct circuit balance every-time with 
no need to set flow rates.  Automatic flow adjustment means that flow gauges DO-NOT need balancing and must be set to their fully open position.
Open and close flow gauge by hand only – DO-NOT force beyond two full turns from shut as this may cause damage to the flow meter.
To adjust, remove lock clip (pic 
1b) and turn black nut at base 
of flow gauge by hand (2b)
DO-NOT USE PLIERS OR 
WRENCH TO ADJUST FLOW 
GAUGE.
Each Auto Balancing actuator 
has two pipe sensors (pic 3b), 
one is simply clipped onto the 
flow and the other onto the 
corresponding return of each 
individual circuit. Either clip can 
be placed on the flow or return 
pipe (pic 4b)
Turn flow gauge anti-clockwise to open 
and clockwise to close (pic 2b) the flow 
gauge is fully open when turned two full 
turns from closed position, do not force 
pass 2 full turns. Re-fit black lock clip 
once adjusted.
Auto balancing actuators must be wired 
in accordance with Wunda wiring guide.
When the floor heating system is fully 
commissioned and thermostats call 
for heat, each individual actuator will 
activate and self-calibrate. 
Once a flow temperature is detected by 
the sensors the Auto Balancing actuator 
will maintain a constant temperature 
differential of 7°C between the flow and 
return floor heating pipes. Until the room 
thermostat signals that heating has been 
achieved.
Ensure that sensors are 
positioned correctly and 
secured in place with the 
clips (pic 5b)
• Pipe in Overfloor panel systems 35°C*.
• Pipe in Solid screed construction (staples, cliptrack,  multipanel) 45°C*.
• Pipe in Joisted floor construction (spreader plate, foiltec) 65°C*.
* Check with floor finish suppliers before introducing 
warm water into the floor heating system as some flooring 
materials, in particular wood, require limiting of floor surface 
temperatures. Floor surface temperatures can be automatically 
controlled with the installation of our floor probe and correct 
thermostat programming.
Clockwise 
decreases flow 
temperature
Anti clockwise 
increases flow 
temperature
1b 2b
3b
4b
5b
Revision date: 18/4/2018

### Page 8

PLEASE READ: Important set-up info
• Check that the red dot of the mixer valve is connected to the flow
• Check that y
our feed and return pipe sizes meet the requirements of the
manifold.
• Make sure your isolation valves are fully open
Please call tech support should you need any further guidance
Red Dot
In some cases, if the pump circulation speed and flow 
meters are not set up properly, the premium mixing valve 
may whistle. To avoid this, check you have covered the 
following points during installation.
MANIFOLD SIZE:
2-4 ports - total floor heating pipe length of up to 400 metres, the pump should 
be set at no higher than speed 1
4-8 ports - total floor heating pipe length of up to 800 metres, the pump should 
be set no higher than speed 2
8-12 ports - total floor heating pipe length of up to 1200 metres, the pump 
should be set no higher than speed 3
FLOW RATES:
Each flow meter should be set up to harmonise the flow rate of each loop with 
the system - please follow the instruction  laid out in Fact Sheet M07 page 6 
(downloadable from www.wundatrade.co.uk/factsheets/) or see the online video.
OTHER THINGS TO CHECK:
Wilo
 Grundfos
Pump speed selector
8
Revision date: 18/4/2018

### Page 9

Supplementary information.
Floor surface temperatures
Before introducing heat into the floor heating system check with the 
final floor finish supplier about maximum floor surface temperatures.
Generally a maximum floor surface temperature of 29ºC should not 
be exceeded however many wooden floor finishes have a maximum 
floor surface temperature of 27 ºC and must be layed in conjunction 
with relevant underlay and moisture barriers.
We advise the use of floor probes in conjunction with room 
thermostats be used in order to limit floor surface temperatures and 
avoid damage to chosen floor finish.
In particularly large areas several probes and thermostats may be 
required.
Wooden floor coverings
When installing wooden floor coverings over floor heating the floor 
surface temperature must not exceed 27 ºC. Floor probes in 
conjunction with room thermostats must be used in order to limit 
floor surface temperatures and avoid damage to wooden floors. 
Expansion gaps must be used to allow for expansion and contraction 
movement of the wooden flooring as specified by flooring suppliers. 
Birch and Maple are not suitable for use with floor heating due to 
excessive amounts of expansion. Laminates and engineered woods 
less than 25mm thick work well with floor heating. All wood flooring 
products must be acclimatised to the heating system and its 
operational temperatures by following suppliers guide lines.
Water Treatment (required to comply with product guarantee)
Specialist water treatment suppliers such as Sentinal or Fernox will be 
able to advise on all water treatment issues and dosage 
requirements. Flushing should be in accordance with BS:7593 to 
ensure awareness of the preparation of the water circuit for the wet 
heating systems prior to initial commissioning following major 
remedial work such as boiler replacement and the ongoing water 
treatment to ensure continued efficiency. The water volume in a 
16mm pipe Floor Heating system can be calculated by multiplying 
the total linear length of Floor Heating pipe by a factor of 0.113 this 
will give the volume of water in litres.
In order to minimise corrosion, treatment of the water with an 
inhibitor is essential, however, for a corrosion inhibitor to function 
effectively, the metal surfaces must be clean. The British Standard 
Code of Practice BS 7593: 1992 details the steps necessary to clean a 
domestic central heating system. The Code recognises that it is not 
possible to clean a system without the application of a cleanser. 
Different products may be used depending on the nature of the 
system involved.
The most effective corrosion inhibitors act by reacting with the 
surface of the metal to produce a protective film in the form of a 
stable complex. The effectiveness of a given corrosion inhibitor will 
depend on its concentration. 
In a multi-metal system, the product selected should contain a blend 
of inhibitors such that each metal is afforded good protection. In 
addition to the usual metals and alloys, e.g., iron, copper, steel and 
brass, special consideration must be afforded to aluminium. 
Normally this metal is protected by a film of aluminium oxide which 
prevents corrosion in water (or in air), but under acid or strongly 
alkaline conditions the oxide film dissolves exposing the metal. Some 
waters found in the UK will give rise to sufficiently alkaline conditions 
in a central heating system to promote corrosion of aluminium and 
the gassing associated. 
An increasing number of central heating systems contain aluminium 
so it is advisable that a neutral (neither acid nor alkaline) corrosion 
inhibitor product is selected in every case. 
Consideration should be given to adding antifreeze to the floor 
heating system especially during the winter months.
All information in this publication is given in good faith, and believed to 
be correct at time of going to press . No responsibility can be accepted 
for any errors, omissions or incorrect assumptions. Users should satisfy 
themselves that products are suitable for the intended purpose and 
application.
Wunda Group Plc operates a continuous product 
development programme to maintain our reputation for 
quality products and as such we do occasionally modify or 
amend the specification of our products in line with our 
strict quality control policy. Maintenance of the floor heating 
system is straightforward and the pump, manifold, gauges, 
valves and actuators are designed for continuous operation 
over many years. Wunda Group Plc recommends regular use 
of floor heating systems, this will ensure flow gauges, pumps 
and valves are kept in good working order.
Important
“When mixed floor solutions are being served from the same manifold, a 
floor probe must be used in the floor solution with the lower maximum 
supply temperature. This is to limit the temperature in these floor areas 
and prevent damage to the floor solution and/or floor finish. ”
   
9
M07
Wunda Premium Manifold
✆ 0800 5420 816       www.wundafloorheating.co.ukTHE BRAND YOU CAN TRUST
Tech support opening hours are subject to change - please visit our website for the latest information Revision date: 18/4/20187