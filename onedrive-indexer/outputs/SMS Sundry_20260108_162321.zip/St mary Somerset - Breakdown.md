# Source: St mary Somerset - Breakdown.pdf [PDF]
**Path:** `St mary Somerset - Breakdown.pdf`
---

### Page 1

St Mary SomersetSally Strachey Historic Conservation Breakdown
Item Description Cost
Elevation Location ApproachEAST Cornice Re-point with lime mortar £84.00EAST String course nosing Consider pinning repair £182.00
EAST Upper circular window
REMOVED DURING INSPECTION; REPLACE AFTER REMOVING IRON FIXING £315.00EAST Ashlar walls Re-point with lime mortar £420.00EAST 3rd window down sill Re-point with lime mortar £84.00
EAST 3rd window down sill Consider recreating profile with lime mortar £151.20EAST Lower string course Re-point with lime mortar £252.00EAST Lower circular window Re-point with lime mortar £210.00EAST Lower blind window hood Re-point with lime mortar £84.00EAST Lower circular window downwards Re-point with lime mortar £420.00WEST Cornice Re-point with lime mortar £84.00WEST String course nosing Consider pinning repair £91.00
WEST Springer height of upper window in left ashlar wall to and around corner Remove this loose repair £616.00WEST Upper window sill Re-point with lime mortar £168.00
WEST Upper circular window Not possible to pin fracture but open joints can be re-pointed £84.00WEST Upper circular window Consider removal £61.60WEST Between upper circular window and 3rd window downRe-point with lime mortar £168.00WEST 3rd window down left reveal Consider pinning repair £182.00WEST 3rd window down sill Re-point with lime mortar £336.00WEST 3rd window down reveals Re-point with lime mortar £168.00WEST Lower string course Re-point with lime mortar £168.00
WEST Lower circular window
Attempt to clean ends of ferramenta in-situ, re-point ends with lime mortar, re-paint ferramenta generallyWEST Lower circular window Attempt to pin repair £91.00WEST Lower blind window hood Re-point with lime mortar £84.00WEST Lower circular window downwards Re-point with lime mortar £420.00SOUTH Cornice Re-point with lime mortar £84.00
SOUTH Upper window right reveal Re-point & surface repairs with lime mortar £121.80SOUTH Lower string course Re-point with lime mortar £252.00SOUTH Lower string course Consider pinning repair £182.00
SOUTH Lower blind window hood Defrass and consolidate with lime mortar where possible £184.80NORTH Cornice Re-point with lime mortar £84.00NORTH Carved grotesque Pinning repair required £91.00
NORTH Upper windowsill
Re-point open joints with lime mortar - fracture will not suit pinning repair £84.00NORTH Upper circular window Remove & repair with lime mortar£106.40
£6,113.80