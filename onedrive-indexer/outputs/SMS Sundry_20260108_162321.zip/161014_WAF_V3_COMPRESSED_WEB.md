# Source: 161014_WAF_V3_COMPRESSED_WEB.pptx [PPTX]
**Path:** `161014_WAF_V3_COMPRESSED_WEB.pptx`
---

### Slide 1

A House St Mary Somerset Tower Pilbrow & Partners

---

### Slide 2

Principal Buildings By Sir Christopher Wren - Richardson William, 1841

---

### Slide 3

Principal Buildings By Sir Christopher Wren - Richardson William, 1841

---

### Slide 4

Principal Buildings By Sir Christopher Wren

---

### Slide 9

North South Section

35m

6.1m

6.1m

1.15m

14m2

3.8m

---

### Slide 10

35m

East Elevation

North South Section

---

### Slide 17

6.1m

1.45m

1.9m

0.45m

---