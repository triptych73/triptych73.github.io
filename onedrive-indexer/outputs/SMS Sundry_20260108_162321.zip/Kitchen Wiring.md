# Source: Kitchen Wiring.pdf [PDF]
**Path:** `Kitchen Wiring.pdf`
---

### Page 1

Dish 
washer fridge
Consumer 
unit
hob
extractor
oven
before

### Page 2

Dish 
washer fridge
Consumer 
unit
hob
extractor
oven
after

### Page 3

[IMAGE CONTENT - REQUIRES OCR]