# Source: St Mary Somerset - Habitable Area old.pdf [PDF]
**Path:** `St Mary Somerset - Habitable Area old.pdf`
---

### Page 1

ST MARY SOMERSET – SCOPE OF WORKS FOR BUILDING CONTROL SIGN-OFF 
 
 
Room Area 
Proportion 
of Total 
Floor Area 
Level 01 Kitchen/WC Shower 7.85 4.3% 
Level 01 Reception 20.42 15.3% 
Level 02 Entrance 7.83 19.6% 
Level 03 Plant Room 6.20 23.0% 
Level 04 Lobby 4.7 25.5% 
Level 04 Ensuite 3.13 27.2% 
Level 04 Bedroom 18.2 37.1% 
Level 05 Lobby 4.7 39.6% 
Level 05 Ensuite 3.13 41.3% 
Level 05 Bedroom 19.04 51.6% 
Level 06 Lobby 4.7 54.2% 
Level 06 WC Laundry 2.93 55.8% 
Level 06 Living Room 18.5 65.8% 
Level 07 Kitchen 18.6 75.9% 
Level 08 Dining Room 13.37 83.2% 
Level 09 Bedroom 23.00 95.7% 
Level 10 Bedroom Mezzanine 8.00 100.0% 
   
Total 184.3  
 
Table 1: Square meterage of each room and cumulative proportion of the premises 
which that represents as you work your way up the property. 
 
 
Due to the additional space that the extension provides the lower 5 floors will of themselves 
constitute 52% of the total floor area. However, because the lift goes up to the 6th floor and 
we are not able to lock off the top door of the lift, we propose to include the 6th floor 
extension into the total area for which we will be able to seek building control sign-off. 
 

### Page 2

[IMAGE CONTENT - REQUIRES OCR]

### Page 3

[IMAGE CONTENT - REQUIRES OCR]