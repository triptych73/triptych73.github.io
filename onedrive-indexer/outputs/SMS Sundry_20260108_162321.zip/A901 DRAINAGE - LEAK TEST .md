# Source: A901 DRAINAGE - LEAK TEST .pdf [PDF]
**Path:** `A901 DRAINAGE - LEAK TEST .pdf`
---

### Page 1

400
600800
Concrete Slab
Side
Retaining
Wall
Project Name
St Mary Somerset Tower
All details are indicative and not for construction
All dims TBC and may be subject to change
Keyplan
Do not scale dimensions. Dimensions govern.
All dimensions are in millimetres unless noted 
otherwise.
Pilbrow & Partners shall be notified in writing of any 
discrepancies.
t: +44 (0) 78 1584 2602
e: stmsltd@gmail.com
2 Greyfriars Passage
London EC1A 7BA
A1
Insp
By
Revision
Scale Sheet Size
Drawing Number
Status
Drawing Title
Revisions
NotesDateRev
Creation Date
Drawn
By
A901
00 GR KR
16 September 2018
As built drainage
15/09/16 Issue
01