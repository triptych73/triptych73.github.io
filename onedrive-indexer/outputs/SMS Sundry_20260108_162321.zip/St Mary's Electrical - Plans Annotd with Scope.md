# Source: St Mary's Electrical - Plans Annotd with Scope.pdf [PDF]
**Path:** `St Mary's Electrical - Plans Annotd with Scope.pdf`
---

### Page 1

R13
R 12 1)13R
WII
aepvE
661)12
Ril
St Mary Somerset Towe'
FOR APPROVAL
Plans - Proposed
Level'
Aooq
50 AJ 2021


### Page 2

DOI
W03
EELOW
ABOVE
aeovE 10 BELOW
EXT
TEC m•'
St Mary Somerset Tower
FOR APPROVAL
Plans - Proposed
Level
A3 16 September 2021


### Page 3

R32 W03
äfil
St Mary Somerset Tower
FOR APPROVAL
Plans - Proposed
Level 3
A003
ISO A3 16 septerr,ber 2021


### Page 4

R42
042 I M'03
1)41
W13
Ect*
TOC
St Mary Somerset Tower
W12
FOR APPROVAL
Plans - Proposed
Level
A002.F
180 A3 16 September 2021
01


### Page 5

RS2 1)52
W03
wo
W17
St Mary Somerset Tower
FOR APPROVAL
Plans - Proposed
Level
'6 September 2021


### Page 6

1)62 W03
1)61
iiii=
.74 g
R6J
'sea 2072
St Mary Somerset Tower
WII FOR APPROVAL
Plans - Proposed
Level
AOO$
1 so A3 16 September 2021
