# Source: St Mary's Tower - Initial Works.pdf [PDF]
**Path:** `St Mary's Tower - Initial Works.pdf`
---

### Page 1

Throughout 
• Fire doors ironmongery and fire seals 
o handle selection, solid latches - discuss with SB/SM 
• Fire separation, riser and between floors (timing of installation of this tbd) 
o Envirograf intumescent slab. Have ordered 3 for Monday. These to be cut 
to form around services in the riser at floor level similar to the hatched 
area 
 
 
 
 
 
N.B. the line of the fire separation between compartments will have to allow inspection 
of the flue joints from the proposed L5 inspection hatch and from L2 plant room. I guess 
this can be achieved by boxing in a section of the flue above/below  with fire line 
plasterboard and envirograf intumescent slab? 
 


### Page 2

 
 
 
L1 
• Cap off incoming 32mm MDPE water pipe from exterior on East elevation below 
paving level 
o remove flag stone outside, dig down cut pipe and affix a compression stop 
fitting, install lagging where needed and then make good. 


### Page 3

 
• Kitchen doors to fit - lower cabinet doors arriving early next week 
L2 
• Fire lining to ceiling 
 
L6 
• Loft board insulation to R61 floor 
o 100mm rigid polyurethane board + 22mm T&G loft board finish (both 
ordered for delivery early next week) 
• Floor finish to hall between R61 and R62 
o 75mm Portland stone slab (on site) and/or limestone tile 
• Extension Roof 
o insulation, membrane - would be good to get confirmation of the cold roof 
design incl. location and thickness of insulation and location of any 
vapour membrane. We can then install the vents to roof (or to HVAC 
system?) and proceed with fitting these elements. 


### Page 4

 
Working around flue and services... 
 
 
