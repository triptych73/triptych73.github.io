# Source: City Workplace Register - STMS LTD.pdf [PDF]
**Path:** `City Workplace Register - STMS LTD.pdf`
---

### Page 1

City Workplace Register
CITY
LOåbON
Office Manager
STMS LTD
2 Greyfriars Passage
London
ECIA 7BA
Dear City Worker
Each year, the City of London is required by law to collect details of every
workplace for electoral purposes. This lets us know more about your
organisation, the size of your workforce and the sector you're in. In order to meet
these obligations, your organisation is legally required to complete this survey
form in full and return it to the City of London. As we work to build back from the
pandemic, this information has never been more crucial.
We use the information in the City Workplace Register to calculate how
many voters your organisation is able to nominate in our local elections,
in which, uniquely, both City workers and residents can vote - as well as to
contact you about important security and safety information, especially in
an emergency, and consultations where the law requires us to ask for yourmom views. Ifyour organisation is currently working remotely due to the pandemic,
please give answers that reflect your ordinary working situation when YOU
return to the office.
Any personal information YOU provide will be held securely, processed in
accordance with our legal obligations and will not be disclosed to third parties,
except where we are legally obliged to do so. Further details can be found at the
end of this form.
Please forward this form to the appropriate person at your organisation to
complete it online - or complete it by hand and email it to workplaceregister@
cityoflondon.gov.uk or post to City Workplace Register, Town Clerk's Office,City of London, PO Box 270, Guildhall, London E2CP 2EJ.
Yours faithfully,
John Barradell
Town Clerk and Chief Executive
Complete the survey online at
www.cityoflondon.gov.uk/
workplaceregister
Or complete the survey as a pdf
and return by e-mail to:
workplaceregister@cityoflondon.gov.uk


### Page 2

City Workplace Register
SECTION 1:
Organisation details
Orgarmsauon name:
Address:
Ptease complete this form
in BLOCK CAPITALS.
Postcode:
Please tick to confirm that your organisation occupies these premises as owner or tenant.
(You should not tick this box if your organisation only has a licence to occupy the premises. For example, agreementsto use shared workspaces or serviced offices are normally licences.)
Switchboard number:
ompany email:
Website:
Description of business (e.g. Accountants)
Dev
Location of head office if not within the UK:
continued on next page...
For any queries or additional information please contact the
City Occupiers' Database Team at: workplaceregister@cityoflondon.gov.uk


### Page 3

City Workplace Register
SECTION 2:
Contact Details
A Mandatory fields
Please complete this form
in BLOCK CAPITALS.
Please give your own contact details or those of a relevant decisionnaker in your organisation
Title
First name*
Last name*
Position/Job title*
Email address*
Work telephone
Mobile telephone
078<8
continued on next page...
For any queries or additional information please contact the
City Occupiers' Database Team at: workplaceregister@cityoflondon.gov.uk


### Page 4

WI OON
City Workplace Register
Type of organisation
Please complete this form
in BLOCK CAPITALS.
Pleas tick to indicate the type of ocqanisation as recoqnisecl under Enqt•sh law.Company or other incorporated body (including LCF's)
Please state type (e.g. LIP, LTD, PLC)
O Unincorporated body (other than a partnership)
Please state type (e.g. Association, Charity)
O Partnership (excluding [LPs)
O Sole trader
O Crown body
Please state type (e.g. Government dept)
O Other
Please specify
Number of people
Number of people whose principal or only place of work is at the premises above. Those who are working fromhome due to the pandemic are still counted wtihin this figure (including part time staff and contractors). Enter thenumber of people whose principal or only place of work is at these premises. Include sub-contractors, consultantsand agency staff if they are likely to be working at the premises on an on-going basis. Discount such persons workingat the premises on a short term basis.
Total number of workers:
1
O Please tick here if you only have a registered office or virtual presence in the City.
continued on next page...
For any queries or additional information please contact the
City Occupiers' Database Team at: workplaceregister@cityoflondon.gov.uk


### Page 5

City Workplace Register
SECTION 3:
Privacy notice
The City of London, PO Box 270, Guildhall, London,
EC2P 2EJ is the registered Data Controller in respect of
processing personal data and is required under data
protection legislation to notify you of the information
contained in this privacy notice. The City of London's
Data Protection Officer is the Comptroller and City
Solicitor and can be contacted at the above address
or alternatively by email at information.officer@
cityoflondon.gov.uk.
The City of London fully respects your right to privacy,
and the information you provide here will be processed
for the purpose of fulfilling our statutory duties under
The City of London (Various Powers) Act 1957 (as
amended) and the City of London (Ward Elections)
Act 2002 (as amended) which require any person to
give information to the City of London's registration
officer to enable that officer to maintain registers of
local government electors. The City of London requires
certain information from business occupiers in the city to
enable the workforce of such occupiers to be identified
as eligible to vote in the ward elections in the City ofWIOON London in accordance with the City of London (Ward
Elections) Act 2002, therefore the processing of your
personal data is necessary for compliance with a
legal obligation.
continued on next page...
The information provided by you on this survey form will
also be used to:
• meet the City of London's obligations to maintain
the security and safety of the Square Mile, and for
thepurposes of contingency planning
• consult with and contact you, or your organisation,
where required to meet other statutory obligations
placedon the City of London, including those relating
to such matters as housing, education, community
services,cleansing and health and safety.
You have the right to request a copy of your personal
data, ask us to make changes to ensure that it is up to
date, ask that we delete your information or object to
the way we use your personal data. To do this please
email workplaceregister@cityoflondon.gov.uk.
The City of London will keep your information for four
years from the date of processing. After this time, the
information is deleted.
For independent advice about data protection, and your
rights in relation to personal data, you can contact the
Information Commissioner's Office (ICO) at Information
Commissioner's Office, Wycliffe House, Water Lane,
Wilmslow, Chesire, SK9 5AF or alternatively, visit ico.
org.Uk or email casework@ico.org.uk.
In order to meet these obligations it is necessary
that this survey form be completed in full and
returned to the City of London. For further
information about this form please email
workplaceregister@cityoflondon.gov.uk.
For any queries or additional information please contact the
City Occupiers' Database Team at: workplaceregister@cityoflondon.gov.uk


### Page 6

City Workplace Register
Your consent
The City of London may also wish to contact YOU about additional matters. If you wish to be
contacted about matters listed below, please tick your preferences via email, post or both:
Email Post
Email Only
Information Type
Non-Statutory Consultation to enable the City to improve and develop its c.erøceeo to meet
the needs of the Square Mile.
General Publications or information on the wide range of City's activities.
Invitations to appropriate events
E-Shots - the City's online information service - a quick and easy way to find out what is
going on in and around the Square Mite.
You may withdraw your consent at any time
If you wish to withdraw your consent to be contacted,
please do so by emailing workplaceregister@cityonondon.gov.uk
Signed Date
For any queries or additional information please contact the
City Occupiers' Database Team at: workplaceregister@cityoflondon.gov.uk
Complete the survey online at
www.cityoflondon.gov.uk/
workplaceregister
Or complete survey as a pdf and return by
e-mail
or by post to:
City Workplace Register
Town Clerk's Office
City of London
PO Box 270
Guildhall
London EC2P 2EJ
