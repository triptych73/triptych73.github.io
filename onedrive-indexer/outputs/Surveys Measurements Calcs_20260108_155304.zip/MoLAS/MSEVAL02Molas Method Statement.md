# Source: MSEVAL02Molas Method Statement.pdf
**Path:** `MoLAS/MSEVAL02Molas Method Statement.pdf`
---

### Page 1

Method Statement ! MoLAS 
 
 
Tower of St. Mary Somerset 
Lambeth Hill 
City of London 
EC4 
 
A Method Statement for archaeological evaluation 
 
Author Rosalind Aitken 
 
 

### Page 2

Method Statement ! MoLAS 
 
Contents  
1 Introduction 3 
1.1 Site background 4 
1.2 Planning and legislative framework 4 
1.3 Archaeological background 10 
1.4 Topography 10 
1.5 Roman masonry structures 10 
1.6 The Medieval street plan and churches 10 
1.7 Post-medieval 11 
1.8 Outline of proposed works 12 
1.9 Status of document 12 
2 Objectives of the evaluation 13 
2.1 General considerations 13 
2.2 Site specific objectives and research questions 14 
2.3 General site methodology 15 
2.4 Site-specific methodology 17 
2.5 Access, Health and Safety 18 
2.6 Recording systems 19 
2.7 Treatment of finds and samples 19 
2.8 Ownership of finds 20 
2.9 Reports and archives 20 
2.10 Evaluation method agreement 22 
3 Timetable of works and staffing 23 
3.1 Timetable and staffing 23 
3.2 Attendances 23 
3.3 Accommodation and facilities 24 

### Page 3

Method Statement ! MoLAS 
4 Funding 24 
5 Acknowledgements 24 
6 Bibliography 24 
7 Appendix 30 
 
Figures 
 
Fig 1 Site Location 26 
Fig 2 Areas of Investigation 27 
Fig 3 Location of previous works in relation to proposed works 28 
Fig 4 Survey of the Wren Tower of St Mary Somerset with proposed works shown. 29 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Author: Rosalind Aitken 
File path: p/city1000/1091/field/MSEVAL02.doc 
 3  p:\city1000\1091\na\field\mseval02.doc  

### Page 4

Method Statement ! MoLAS 
1 Introduction 
1.1 Site background  
 
This Method Statement for an archaeological evaluation on the site of St Mary 
Somerset, Lambeth Hill, London has been commissioned from the Museum of 
London Archaeology Service (MoLAS) by Boyarsky Murphy Architects. 
 
The site comprises the garden and remaining tower of St Mary Somerset Church and 
is bounded by Lambeth Hill on the north side, and Castel Baynard Street to the south 
(See Fig 1). The centre of the site lies at National Grid reference 532163 180880. 
Modern pavement level near to the site lies at c 8.56m OD. The existing ground floor 
slab within the church tower lies at approximately 7.30m OD. 
 
The proposed redevelopment involves the conversion of the St. Mary Somerset Tower 
for residential use.  The works considered in this document are the excavation of a 
trial trench to the north of the tower and an internal trial pit within the tower (see Fig 
2 for trench locations).  
 
The excavations will be monitored by a MoLAS Senior Archaeologist.  The results  of 
the trial trench and pit will inform the construction design and the mitigation strategy 
for any archaeological remains identified.  
1.2 Planning and legislative framework  
A Planning Application has been made for the proposed redevelopment (Registered 
Plan No 05/00194/FULL).  The results of the archaeological evaluation will inform 
the consideration of the planning application by the Corporation of London. 
1.2.1 Planning policy guidance (PPG16) 
 
The then Department of the Environment published its Archaeology and planning: a 
consultative document, Planning Policy Guidance Note 16 (PPG 16), in November 
1990. This set out the Secretary of State’s policy on archaeological remains on land, 
and provided recommendations many of which have been integrated into local 
development plans. The key points in PPG16 are the following: 
 Archaeological remains should be seen as a finite and non-renewable resource, and in many 
cases highly fragile and vulnerable to damage and destruction. Appropriate management is 
therefore essential to ensure that they survive in good condition. In particular, care must be 
taken to ensure that archaeological remains are not needlessly or thoughtlessly destroyed. 
They can contain irreplaceable information about our past and the potential for an increase 
in future knowledge. They are part of our sense of national identity and are valuable both for 
their own sake and for their role in education, leisure and tourism. 
 
 4  p:\city1000\1091\na\field\mseval02.doc  

### Page 5

Method Statement ! MoLAS 
 Where nationally important archaeological remains, whether scheduled or not, and their 
settings, are affected by a proposed development there should be a presumption in favour of 
their physical preservation. 
 
 The key to informed and reasonable planning decisions is for consideration to be given 
early, before formal planning applications are made, to the question of whether 
archaeological remains are known to exist on a site where development is planned and the 
implications for the development proposal. 
 
 When important remains are known to exist, or when archaeologists have good reason to 
believe that important remains exist, developers will be able to help by preparing 
sympathetic designs using, for example, foundations which avoid disturbing the remains 
altogether or minimise damage by raising ground levels under a proposed new structure, or 
by careful siting of landscaped or open areas. There are techniques available for sealing 
archaeological remains underneath buildings or landscaping, thus securing their preservation 
for the future even though they remain inaccessible for the time being. 
 
 If physical preservation in situ is not feasible, an archaeological excavation for the purposes 
of ‘preservation by record’ may be an acceptable alternative. From an archaeological point 
of view, this should be regarded as a second-best option. Agreements should also provide 
for the subsequent publication of the results of any excavation programme. 
 
 Decisions by planning authorities on whether to preserve archaeological remains in situ, in 
the face of proposed development, have to be taken on merit, taking account of development 
plan policies and all other material considerations – including the importance of the remains 
– and weighing these against the need for development. 
 
Planning authorities, when they propose to allow development which is damaging to 
archaeological remains, must ensure that the developer has satisfactorily provided for 
excavation and recording, either through voluntary agreement with the archaeologists or, in 
the absence of agreement, by imposing an appropriate condition on the planning permission. 
 
PPG16 itself forms part of an emerging European framework which recognises the 
importance of the archaeological and historic heritage in consideration of 
development proposals. This has recently been formulated in the Code of good 
practice on archaeological heritage in urban development policies established by the 
Cultural Heritage Committee of the Council of Europe, and adopted at the 15th 
plenary session in Strasbourg on 8–10 March 2000 (CC-PAT [99] 18 rev 3). As stated 
at the beginning of that document however, ‘a balance must be struck between the 
desire to conserve the past and the need to renew for the future’. 
1.2.2 Archaeology and planning in the City of London 
 
The Corporation of London's revised Unitary Development Plan (UDP) was adopted 
in April 2002. The policies set out in this document determine the position of 
archaeology as a material consideration in the planning process and incorporate 
recommendations from the Department of the Environment's Planning Policy 
Guidance 16 (PPG 16). 
 
The Corporation of London recognises that archaeology is a finite and fragile 
resource and that adequate safeguarding of ancient monuments and archaeological 
remains contribute to a better understanding of London's past. The Corporations 
planning guide-lines are given focus in its strategy (Policy Strat 11A) for 
safeguarding ancient monuments and archaeological remains in the City:  
 5  p:\city1000\1091\na\field\mseval02.doc  

### Page 6

Method Statement ! MoLAS 
 
POLICY STRAT 11A: To recognise the archaeological importance of the City as the 
historic centre of the capital and to seek the adequate safeguarding and investigation 
of ancient monuments and archaeological remains. 
 
The Corporation’s Unitary Development Plan goes on to elaborate three Policies 
which deal specifically with archaeological preservation and investigations: 
 
POLICY ARC1: To require planning applications which involve excavation or 
groundworks on sites of archaeological potential to be accompanied by an archaeological 
assessment and evaluation of the site including the impact of the proposed development.  
 
POLICY ARC2: To require development proposals to preserve in situ, protect and 
safeguard important ancient monuments and important archaeological remains and their 
settings, and where appropriate, to require permanent public display and/or interpretation 
of the monument or remains. 
 
POLICY ARC3: To ensure the proper investigation, recording of sites, and publication 
of the results, by an approved organisation as an integral part of a development 
programme where a development incorporates archaeological remains or where it is 
considered that preservation in situ is not appropriate. 
 
The principle considerations which underpin these Policies are as follows: 
 
Para 11.7: Strategic Guidance states that account should be taken of the desirability of 
preserving ancient monuments and their settings and of the Secretary of State’s guidance 
in PPG 16, Archaeology and Planning. Archaeological remains are an irreplaceable 
resource and often the only evidence of past development. These remains are a finite and 
non-renewable resource, in many cases highly fragile and vulnerable to damage and 
destruction. They contain irreplaceable information about our past and the potential for an 
increase in future knowledge. 
 
Para 11.8: Where nationally important archaeological remains, whether scheduled or not, 
and their settings are affected by proposed development there is a presumption in favour 
of their physical preservation in situ. Some monuments and archaeological remains are 
protected as scheduled ancient monuments under Part I of the Ancient Monuments and 
Archaeological Areas Act 1979. Applications for works which may affect a scheduled 
ancient monument are determined by the Secretary of State for Culture, Media and Sport, 
with advice from English Heritage. This procedure is different from any consents that 
may be necessary under Town Planning legislation. Due to the potentially complex nature 
of archaeological remains in the City, the Corporation will expect applications for 
scheduled monument consent and planning permission to be prepared and considered in 
parallel. 
 
Para 11.9: Not all important monuments and remains are scheduled, and in some cases, 
remains of more local importance will be considered worthy of preservation. PPG 16 
gives criteria for assessing the national importance of an ancient monument and 
considering whether scheduling is important. Development schemes should be designed 
to incorporate the preservation in situ of important monuments and archaeological 
remains, and respect and enhance their settings. 
 
Para 11.10: On sites where archaeological remains of lesser importance exist, and it is 
considered by the Corporation that preservation in situ is not appropriate, investigation, 
recording and publication will be required. This is to ensure preservation by record, 
placing those remains in a wider context, and adding to our understanding and 
interpretation of the historic landscape. 
 
 6  p:\city1000\1091\na\field\mseval02.doc  

### Page 7

Method Statement ! MoLAS 
Para 11.12 All of the City is considered to have archaeological potential unless it can be 
demonstrated that archaeological remains have been lost, due to basement construction or 
other groundworks. The Corporation will indicate the potential of a site, its relative 
importance, and the likely impact to a developer at an early stage so that the appropriate 
assessment and design development can be undertaken. 
 
Para 11.13 On sites of archaeological potential, which may be affected by development 
schemes or groundworks, an archaeological assessment will be required to be submitted 
with the application. This will set out the archaeological potential of the site and impact 
of the proposals. Where appropriate, this should be supplemented by evaluation, carrying 
out trial work in specific areas of the site to provide more information and inform 
consideration of the development proposals by the Corporation, prior to a decision on that 
application. 
 
Para 11.15 The interpretation and presentation of a visible or buried monument to the 
public and enhancement of its setting, should form part of the development proposals. 
Agreement will be sought to achieve reasonable public access. The Corporation will 
consider refusing schemes which do not provide an adequate assessment of a site or make 
no provision for the incorporation, safeguarding or preservation in situ of nationally or 
locally important monuments or remains, or which would adversely affect those 
monuments or remains. 
 
Para 11.16 In some cases, a development may reveal a monument or archaeological 
remains which will be displayed on the site, or reburied. Investigation and recording of 
those features will be required as part of a programme of archaeological work to be 
submitted to and approved by the Corporation. Where the significance of the remains is 
considered, by the Corporation, not sufficient to justify their physical preservation in situ 
and they will be affected by development, archaeological recording should be carried out. 
A programme of archaeological work for investigation, excavation and recording, and 
publication of the results, to a predetermined research framework, by an approved 
organisation, should be submitted to and approved by the Corporation, prior to 
development. This will be controlled through the use of conditions and will ensure the 
preservation of those remains by record. 
 7  p:\city1000\1091\na\field\mseval02.doc  

### Page 8

Method Statement ! MoLAS 
  
1.2.3 Work in redundant CofE churches or church grounds 
 
The redundancy of CofE churches and church grounds is governed by the provisions 
of the Pastoral Measure 1983 and the Pastoral (Amendment) Measure 1994.  The 
process is handled by the Church Commissioners and the Advisory Board for 
Redundant Churches (ABRC), on which there is usually at least one archaeological 
advisor. 
 
A redundant church no longer has Ecclesiastical Exemption from listed building 
control. Normal LPA planning procedures (as guided by PPG16 and PPG15) will 
usually apply.  
 
A redundant church or its grounds may pass into national guardianship if the ABRC 
so recommends for reasons of ‘historic or archaeological interest’. Such guardianship 
is normally undertaken by the Churches Conservation Trust but also sometimes by the 
local Diocese. 
 
Where a redundant church or church grounds is to be given over to an alternative use, 
there are no specific provisions under the Pastoral Measure to ensure the preservation 
or recording of archaeological evidence. The ABRC may have made 
recommendations on appropriate archaeological measures but the level of response 
will normally be determined by LPA planning procedures and their implementation of 
PPG15 & 16.  
 
1.2.4 Human remains 
 
The exhumation of human remains is regulated principally under Section 25 of the 
Burial Act 1857, with certain exceptions under the Disused Burial Grounds Act 1884 
and 1981, and the Pastoral Measure 1983. The 1857 Act requires that a Licence be 
obtained from a Secretary of State for the removal of remains which have been 
interred ‘in a place of burial’. This applies to any remains of any date or buried under 
any rite.  
 
However, note:  
 
! A Faculty will generally be required in relation to the removal and 
reinterrment of any human remains from one consecrated ground to another. 
 
! A Burial (Home Office) Licence is not normally required for the removal of 
remains from one consecrated place to another carried out under Faculty, 
except where other activities such as archaeological or scientific analysis take 
place on those remains before reburial. 
 
! A Burial (Home Office) Licence is still required, even where work is done 
under Faculty, if the bones are being removed and are not intended for reburial 
in consecrated ground. 
 8  p:\city1000\1091\na\field\mseval02.doc  

### Page 9

Method Statement ! MoLAS 
 
The removal and reinterrment of all  human remains, whether from consecrated or 
deconsecrated ground,  must be carried out in accordance with the Town and Country 
Planning (Churches, Places of Religious Worship and Burial Grounds ) Regulations 
1930.  Regulation 12 states that the removal of human remains and reinterrment 
should be in accordance with the direction of the local Environmental Health Officer. 
 
Section 3 of the Disused Burial Grounds Act 1884 states that it ‘shall not be lawful to 
erect any buildings upon disused burials ground’1 Significantly a disused burial 
ground is defined as ‘any churchyard, cemetery or other ground, whether consecrated 
or not, which has at any time been set apart for the purpose of interments’. 
 
The ADCA document Guidance Note 1  (ADCA 2004,17) recommends that in 
general, with regard to the possibility of burials in or around churches, ‘the 
archaeological approach to ground disturbance in sensitive areas should be adoped, 
with its stages of appraisal, assessment and field evaluation’ 
 
English Heritage and the Church of England have also published guidance notes on 
the treatment of human remains  (Guidance for best practice for treatment of human 
remains excavated from Christian burial grounds in England 2005). The principal 
assumptions lying behind their deliberations were  a)  that human remains should 
always be treated with dignity and respect b) burials should not be disturbed without 
good reason. However it was noted that the demands of the modern world are such 
that it may be necessary to disturb burials in advance of development c) human 
remains are an important source of scientific information d) there is a need to give 
particular weight to the feelings and views of living family members when known e) 
there is a need for decisions to be made in the public interest and in an accountable 
way.    
 
 
All MoLAS work involving human remains will be carried out in accordance with 
policies and guidelines above and with the most recent MoLAS Health & Safety 
Policy.  
1.2.4.1 Key legislation 
 
Current civil and ecclesiastical legislation and regulation affecting the excavation of 
human remains, associated structures and sites in England and Wales  
 
Key legislation and regulation is in bold 
 
 
1857 Burial Act (S.25) 
1964 Faculty Jurisdiction Measure 
1981 Disused Burial Grounds (Amendment) Act 
1983 Pastoral Measure (S.65 and schedule 6) 
1990 Planning Policy Guidance Note 16 
1994 Ecclesiastical Exemption (Listed Buildings and Conservation Areas) Order 
                                                 
1 Except for the purpose of enlarging a place of worship. 
 9  p:\city1000\1091\na\field\mseval02.doc  

### Page 10

Method Statement ! MoLAS 
1991 Care of Cathedrals Measure 
1991 Care of Churches and Ecclesiastical Jurisdiction Measure 
 
 
Earlier or other legislation 
1847 Cemeteries Clauses Act 
1854 Burial Act  
1884 Disused Burial Grounds Act 
1906 Open Spaces Act 
1955 Inspectorate of Churches Measure 
1963 Cathedrals Measure 
1968 Pastoral Measure 
1969 Redundant Churches and other Religious Buildings Act 
1972 Local Government Act (S.214 and schedule 26) 
1977 Local Authorities Cemeteries Order 
1978 Inner Urban Areas Act 
1992 Faculty Jurisdiction Measure 
 
1.3 Archaeological background  
1.3.1 Topography 
 
The estimated level of the surface of the natural gravel is c 4.5m OD to the north of St 
Mary Somerset. It falls away rapidly to the south towards the river.  
1.3.2  Roman masonry structures 
Excavations in the area immediately around the site have revealed a series of 
monumental Roman masonry structures occupying the gravel terraces leading down 
to the river.  These include the Huggin Hill Baths complex immediately to the east, 
part of which lies beneath Senator House. This was constructed in the later 1st 
century, and was extended several times prior to being demolished, possibly before 
the end of the 2nd century. To the north-west, under the site of the Salvation Army 
building, a series of Roman foundations were found.  These were probably part of a 
temple precinct constructed on earlier rammed chalk terraces. Beyond that at Peter’s 
Hill, a series of structures which may include the unfinished palace of the imperial 
pretender, Allectus, were begun and abandoned in the last decade of the 3rd century. 
Immediately south of these was the riverside wall, built in c AD 270. 
 
A watching brief conducted at the site in 2003 revealed evidence of a Roman building 
and floor layers (Soakaway B, Fig 3) at c.4.63m OD (2.6m below the current ground 
surface). The remains included a burnt timber beam/baseplate and brickearth sills. 
1.4  The Medieval street plan and churches 
 
Many of the streets in the area probably had their origins in the late-Saxon period, but 
are not recorded in any surviving documentary sources until later. The medieval street 
 10  p:\city1000\1091\na\field\mseval02.doc  

### Page 11

Method Statement ! MoLAS 
plan was retained after the 1666 Great Fire, but was lost following post-war 
redevelopment. 
 
Old Fish Street Hill (Oldefisshestretlone by 1345; Baggardeslane in 1274) formerly 
cut through the site. On the west side of Old Fish Street Hill, to the north-west of the 
site, was the church and churchyard of St Mary Mounthaw first recorded in 1150 
which may originally have been a private chapel of the Mounthaut family from 
Norfolk. A large messuage, originally owned by the Mounthauts, was adjacent to the 
church, perhaps on the north side.  
 
To the north-east of the site, and opposite St Mary Mounthaw, was the Old 
Fishmongers’ Hall. This was in use by the Fishmongers’ Company by 1398–9, but 
was abandoned in favour of the present site near London Bridge in 1503–4. Passing 
the north side of the Hall was Finimore Lane (Finamoureslane in 1316, also known as 
Five foote lane in the 16th century, present Fye Foot Lane). Thames Street to the 
south was probably in place in the late 11th or early 12th century as the main riparian 
road stretching across the City on the line of the collapsed late Roman riverside wall.  
 
The earliest references to St Mary Somerset are in the 12th century. Somerset is 
probably derived from Somershithe, a nearby wharf (Weinreb and Hibbert 1995, 765). 
The church was founded c.1153 and demolished following the 1666 Fire of London. 
It is unknown if any remains from the medieval build of the church remain on site. 
1.5  Post-medieval  
 
The buildings in the Lambeth Hill and surrounding area were destroyed during the 
Great Fire of 1666. The nearby church of St Mary Mounthaw was not rebuilt after the 
fire, instead its parish was amalgamated with St. Mary Somerset. 
  
St. Mary Somerset church was rebuilt by Wren from 1686–95 (see Fig 4). It consisted 
of an east-west aligned church with tower built at the south-eastern end, and a burial 
ground contained within the surrounding church yard. 
 
The main body of the church of St Mary Somerset was demolished as a result of the 
Union of Benefices Act in 1872 following deconsecration in 1867. The tower was 
preserved as a memento and remains, free-standing today. Remnants of the nave of 
the church lie beneath the present Lambeth Hill, with the north wall possibly under 
the pavement adjoining Walker House. Previous archaeological investigations 
(MoLAS 2003) indicate that the rubble from the demolition of the church is present to 
a depth of c. 1.60 m. Disarticulated human remains were retrieved from the rubble in 
the area of proposed trial trench excavation (Drain Run 1 Fig 3) indicating that some 
cemetery clearance occurred at this time.  
 
The church was replaced by warehouses which appear to follow its wall lines, and 
these may even have retained some of the earlier masonry from the church. The 
remains of the footings of the southern wall and where the body of the church 
connected with the tower may well remain in the northern section of the development 
 11  p:\city1000\1091\na\field\mseval02.doc  

### Page 12

Method Statement ! MoLAS 
area (see Fig 4). The Tower of St Mary Somerset was restored in 1956 following 
wartime damage. 
 
Changes to the immediate area since the Second World War such as the construction 
of the Salvation Army Headquarters, Walker House, and Dominant House (now all 
redeveloped), led to the realignment of streets to the south of Queen Victoria Street. 
Lambeth Hill was moved from further east to curve around Walker House, although 
Fye Foot Lane remained on its original site as an elevated walkway leading to a 
footbridge across Thames Street. The latter was widened on the south side with the 
addition of an extra carriageway, and now passes beneath several buildings 
constructed across the road in the 1980s, including the City of London Boys’ School.  
 
1.6 Outline of proposed works  
 
For trench locations see Fig 2. It is proposed that a trench be sunk against the northern 
retaining wall of the development area to determine its depth. This trench is also 
intended to expose the depth of the foundations of the existing tower at its east and 
west ends. The exact width of the trench will be determined on-site. A trial pit is will 
also be excavated within the existing ground floor of St. Mary Somerset Tower to 
determine the construction of the existing ground floor slab and to inform a 
contamination appraisal (See appended note on ‘plan at ground level’ Alan Baxter & 
Associates). As a consequence the level of truncation of any adjoining foundations of 
the original church building may be revealed 
 
These works will provide information on the level and nature of the present 
foundations, earlier church foundations, the extent of horizontal truncation and the 
nature and depth of any other surviving archaeological deposits.  
1.7 Status of document  
 
This document forms the written scheme of investigation for an archaeological 
evaluation on the site to support an application for planning consent. 
 
The document sets out the methodologies which will be followed during the digging 
of the trial pit and evaluation trench and during the post-excavation analysis and 
reporting stages. These will follow the Standards and Code of Practice laid down by 
the Institute of Field Archaeologists. 
 
The document refers back to a previous Archaeological watching brief report 
(MoLAS, 2003). 
 
 
 12  p:\city1000\1091\na\field\mseval02.doc  

### Page 13

Method Statement ! MoLAS 
2 Objectives of the evaluation 
2.1 General considerations  
 
The purpose of an archaeological field evaluation as defined by the Institute of Field 
Archaeologists (IFA, 2001) is to:  
 
determine, as far as is reasonably possible, the nature of the archaeological resource 
within a specified area using appropriate methods and practices. These will satisfy 
the stated aims of the project, and comply with the Code of conduct, Code of 
approved practice for the regulation of contractual arrangements in field 
archaeology, and other relevant by-laws of the IFA. 
 
The IFA Standard and Guidance goes on to define an archaeological field evaluation 
as: 
 
a limited programme of non-intrusive and/or intrusive fieldwork which determines the 
presence or absence of archaeological features, structures, deposits, artefacts or 
ecofacts within a specified area or site on land, inter-tidal zone or underwater. If such 
archaeological remains are present field evaluation defines their character, extent, 
quality and preservation, and enables an assessment of their worth in a local, 
regional, national or international context as appropriate. 
 
It also notes that: 
 
The purpose of field evaluation is to gain information about the archaeological 
resource within a given area or site (including presence or absence, character, extent, 
date, integrity, state of preservation and quality), in order to make an assessment of 
its merit in the appropriate context, leading to one or more of the following: 
  
" the formulation of a strategy to ensure the recording, preservation or 
management of the resource;  
 
" the formulation of a proposal for further archaeological investigation within a 
programme of research. 
 
A field evaluation should thus augment any previous desk-based assessment, and 
provide all parties, particularly the Local Planning Authority, with sufficient material 
information upon which to base informed decisions incorporating adequate heritage 
safeguards. 
 
A field evaluation will result in a detailed archive of information which can be used to 
answer archaeological research questions concerning the buried archaeological 
heritage of the area or site being investigated, either in support of a planning 
application or to discharge the relevant archaeological planning condition. 
 13  p:\city1000\1091\na\field\mseval02.doc  

### Page 14

Method Statement ! MoLAS 
 
A field evaluation may therefore result in the need for further action and a further 
written scheme of investigation may be required in order to comply with the planning 
condition. 
 
The evaluation will provide an assessment of damage already done to archaeological 
deposits by previous developments and actions on the site and will also provide an 
evaluation of the potential impact of the new proposals outlined in the planning 
application. The evaluation methodology will be in accordance with the advice set out 
in the Department of the Environment, Planning Policy Guidance 16, Archaeology 
and Planning (November, 1990) and will conform to the advice given in the 
Corporation of London Department of Planning and Transportation, 2004 Planning 
Advice Note 3: Archaeology in the City of London, Archaeology Guidance, London   
. 
 
2.2 Site specific objectives and research questions  
 
This statement sets out the methods used and approaches taken in dealing with the 
archaeological resource of the site. The detailed methodology is set in the context of 
the methods and approaches which are considered most appropriate for 
Archaeological Evaluations on sites in accordance with the advice contained in the 
Corporation of London Department of Planning and Transportation, 2004 Planning 
Advice Note 3: Archaeology in the City of London, Archaeology Guidance, London.   
 
 
The limited nature of the proposed works and the archaeological evaluation makes it 
unreasonable to establish many specific archaeological research objectives. The 
archaeological brief is essentially limited to establishing the levels and nature of 
surviving archaeological deposits, and to ensure that the digging of the external 
evaluation trench and the internal trial pit does not involve unnecessary destruction of 
such deposits. Nevertheless, in addition, a few broad research questions can be 
outlined: 
 
" What is the nature and level of natural topography? 
 
" What are the earliest deposits identified?  
 
" Is there any evidence of Roman structures or associated layers? 
 
" Do any Roman deposits remain on site? 
 
" Are there any remains, structural or otherwise, associated with the Medieval 
St. Mary Somerset Church (founded c.1153 and demolished during the 1666 
Fire of London)?  
 
" Are there any remains of the foundations or floor levels of the St. Mary 
Somerset Church building as rebuilt by Wren (and demolished in 1872)? 
 14  p:\city1000\1091\na\field\mseval02.doc  

### Page 15

Method Statement ! MoLAS 
 
" What is the nature and depth of the foundations of the Tower of St Mary 
Somerset? 
 
" What is the nature and depth of floor levels within the Tower of St. Mary 
Somerset? 
 
" Are there any in situ human remains present on site? If so are they a part of the 
churchyard cemetery or are they located within the Tower? 
 
" Are there any disarticulated remains present on site? If so, do they form part of 
a  cemetery soil? Or have they been re-deposited within the later deposits 
associated with either the clearance and demolition of the church and 
churchyard, or the 1960’s redevelopment of the area? 
 
" Is there any evidence of post-medieval warehouses surviving on site? If so, 
any remaining walls retain some of the earlier masonry from the church? 
 
" What are the latest deposits identified?  
 
The results of observations obtained by monitoring the geotechnical exercise outlined 
in Section 1.66 will be used to gauge the extent and importance of archaeological 
survival. This information will be used to inform the mitigation strategy for any 
archaeological remains found.    
2.3 General site methodology  
 
2.3.1 Initial location of the trenches and breaking out by the sub-contractor will be 
monitored by MoLAS staff. 
 
2.3.2 All undifferentiated material of recent origin (defined as nineteenth century 
and later) within trenches will be removed down to the first significant 
archaeological horizon. This will be done by subcontractors under 
archaeological supervision by MoLAS. The MoLAS site supervisor will 
decide when remains of archaeological significance requiring recording are 
revealed.  
 
2.3.3 Following exposure of archaeological horizons, all faces of a trench that 
require examination or recording will be cleaned by MoLAS using appropriate 
hand tools. Investigation of archaeological levels will be by hand, with 
cleaning, examination and recording both in plan and section.  
 
2.3.4 Excavation will proceed only until significant archaeological levels have been 
reached and will be sufficient to allow the nature and extent of these to be 
identified. The levels at which all excavations will cease will be determined by 
on-site consultations between the Corporation of London Senior Planning and 
Archaeology & Planning Officer, the Museum of London Archaeology 
Service Project Manager and a representative of the client or his agent. 
 15  p:\city1000\1091\na\field\mseval02.doc  

### Page 16

Method Statement ! MoLAS 
 
2.3.5 Investigation will not be at the expense of any structures, features or finds 
which might reasonably be considered to merit preservation in situ, if this is 
found to be acceptable. It is important, however, that a sufficient sample is 
studied to allow the resolution of the principal evaluation objectives as 
outlined above. 
 
2.3.6 Some features, such as pits and wells may need to be excavated to a greater 
depth, whilst it may be possible to leave modern concrete foundations in situ 
where it is clear that these will have removed all deposits of archaeological 
interest. Modern cut features will be used to provide a ‘window’ onto earlier 
levels. 
 
2.3.7 In addition to the excavation of man made deposits some assessment of 
‘naturally deposited’ levels may be necessary, especially when these are 
organically preserved and laid down within archaeological timescales; for 
example alluvial or peat deposits.  
 
2.3.8 Where archaeological remains are to be preserved in situ they will be 
adequately protected from deterioration. Normally this involves covering or 
wrapping the deposits and features in a geo-textile such as Terram and sealing 
this with a layer of sand or other suitable soft materials.  
 
2.3.9 Any finds of human remains will be left in situ, covered and protected where 
possible. If removal is essential it can only take place under appropriate 
Faculty jurisdiction, Home Office licence, environmental health regulations, 
coroner’s permission, and if appropriate, in compliance with the Disused 
Burial Grounds (Amendment) Act 1981 or other local Act. Prior written notice 
will also be given to the local planning authority. It will be necessary to ensure 
that adequate security is provided.  MoLAS will obtain a Licence from the 
Home Office to cover the accidental disturbance of human remains, before any 
site works commence. 
 
2.3.10 All finds of gold and silver will be removed to a safe place and reported to the 
local Coroner according to the procedures relating to Treasure Act 1996. 
Where removal cannot be effected on the same working day as the discovery 
suitable security measures will be taken to protect the finds from theft. 
 
2.3.11 The evaluation trench and geotechnical pit are primarily designed to provide 
the developers and other interested parties with information about the present 
building foundations and the depth and nature of surviving archaeological 
deposits.  
 
 
2.3.12 A MoLAS Senior Archaeologist will monitor the work and record any 
archaeological remains revealed in the appropriate manner (plans, sections, 
field notes and/or pro-forma ‘context sheets’). Observations will be 
transformed onto the Ordnance Survey National Grid Projection and heights 
measured in metres above Ordnance Datum, by direct measurement from 
 16  p:\city1000\1091\na\field\mseval02.doc  

### Page 17

Method Statement ! MoLAS 
verified Ordnance Survey control points. Masonry will be photographed in 
both black and white and colour media. All recording will be carried out to the 
format and standards detailed in the Museum of London Archaeological 
Recording Manual. 
 
2.3.13 The contractors will inform MoLAS at least one week in advance of the start 
of the proposed groundworks. 
 
2.3.14 On completion of the fieldwork an Evaluation report will be written. Where 
appropriate, the report will include specialist reports; eg from MoLAS 
Environmental specialists. A short summary of the results of the work will be 
submitted to the OASIS SMR [using the appropriate archaeological report 
forms] and for publication in the appropriate academic journal. It may only be 
necessary, in fact, for the excavation to be reported as a summary in an 
appropriate local journal. Such summary publication will meet the “minimum 
standards” set out in Appendix 7 of English Heritage’s document The 
Management of Archaeological Projects (1991) and derive from a “phase 2 
review” as defined therein. 
2.4 Site-specific methodology  
 
2.4.1 The evaluation involves monitoring the proposed geotechnical investigations 
outlined in section 1.6. Specific details of each trench are provided below. 
Previous works on the site (MoLAS, 2003) revealed large amounts of 
disarticulated human remains within post-medieval and modern demolition 
and construction deposits in Drainage Run 1 (see Fig 3). These remains were 
re-buried on site at the location marked with an ‘X’ on Fig 3. An ‘Accidental 
Disturbance of Human Remains’ licence will be sought from the Home Office 
before excavation commences, to cover the likely eventuality of any 
disarticulated human remains being excavated during this phase of works. 
 
2.4.1 The trench  is located to the north of the Tower against a modern retaining 
wall. This trench is being excavated by contractors to provide information 
about the depth of the retaining wall to the north of the site. It will be dug as a 
trench measuring 3m by approximately 1m. The east and western ends are to 
be extended southwards to enable an assessment of the depth of the Tower 
foundations (see appendix)2.  Structures and masonry should be recorded and 
left in situ. If archaeology is present, excavation should stop and a re-
assessment of the trench shape/location should take place. Advice should be 
sought from the Corporation of London Senior Planning and Archaeology 
Officer before such changes are decided or further excavation occurs. 
Disarticulated human remains may be excavated if an ‘Accidental disturbance 
of human remains’ licence is in place and the excavation of such human 
remains is subject to the conditions of this licence. Any articulated human 
remains found should be covered and left, unexcavated, in situ. 
 
                                                 
2 There may be in situ foundations and their associated construction trenches of either the original medieval or 
Wren’s rebuild of St. Mary Somerset Church building in this location (See Fig 4) 
 17  p:\city1000\1091\na\field\mseval02.doc  

### Page 18

Method Statement ! MoLAS 
2.4.2 The Trial Pit is located at the centre of the tower itself and is expected to be no 
more that 1m by 1m by 1m deep. This pit should reveal deposits associated 
with the construction of the Tower floors.  If significant floor deposits are 
encountered, for example,  medieval tiles, the excavation should be halted and 
the advice of the Corporation of London Senior Planning and Archaeology 
Officer sought. Disarticulated human remains may be excavated if an 
‘Accidental disturbance of human remains’ licence is in place, the excavation 
of human remains is subject to the conditions of this licence. Any articulated 
human remains found should be covered and left, unexcavated, in situ. 
2.5 Access, Health and Safety  
 
2.5.1 Reasonable access to the site will be granted to representatives/advisors of the 
Local Authority, who may wish to be satisfied, through site inspections, that 
the archaeological works are being conducted to proper professional standards 
and in accordance with the agreements made. 
 
2.5.2 All site work will be carried out in accordance with the relevant statutory 
health and safety legislation in effect at the time. Regulations and codes of 
practice will be respected. This requirement constitutes one of the non-
archaeological constraints on the evaluation methodology. 
 
2.5.3 All MoLAS staff will adhere to the Health and Safety regulations and 
procedures laid down in the current version of the MoLAS Health & Safety 
Policy (Jan 2005). Copies of this document will be made available to all other 
contractors working on the site. MoLAS will use the Health and Safety 
Executives publication HS(G)65 Successful Health and Safety Management as 
a guide to total quality management of Health and Safety. MoLAS also 
accepts the guidance contained in the H.S.E.’s publication Protection of 
workers and the General Public during the Development of Contaminated 
Land.  
 
2.5.4 No personnel are to work in deep unsupported excavations. Where the 
installation of temporary support work and other attendances are required 
these will be provided by the developer as part of the archaeological 
agreement. Trenches deeper than 1.2m will have to be stepped, battered back 
or shored (note that where mechanical or electric hoists are to be used in 
shored shafts, MoLAS H&S policy requires staff working in shafts less than 
4m x 4m to leave the shaft before hoisting of buckets takes place and not to re-
enter until the bucket is lowered back into position. Time for such evacuation 
will not form part of excavation programme). MoLAS will not generally 
excavate shafts of less than 4m by 4m to depths of greater than 5m.  
 
2.5.5 Where the excavations are to remain open for several days or even overnight, 
safety barriers must be erected around the site and individually around any 
deep excavations. 
 
 18  p:\city1000\1091\na\field\mseval02.doc  

### Page 19

Method Statement ! MoLAS 
2.5.6 Where there is reason to believe from previous uses that the ground or 
adjacent buildings may be contaminated the client must have made 
arrangements for and undertaken pollution sampling and testing before 
archaeological work on sites takes place. 
2.6 Recording systems  
 
2.6.1 A unique-number site code will be agreed with the Museum of London 
Archaeological Resource Centre 
 
2.6.2 The recording systems adopted during the investigations will be fully 
compatible with those most widely used elsewhere in London, and those 
required by the Archive Receiving Body, the Museum of London. 
 
2.6.3 The site archive will be so organised as to be compatible with other 
archaeological archives produced in the Museum of London. It will follow the 
Museum of London, General Standards for the preparation of archives 
deposited within the Museum of London, (1998). This requirement for archival 
compatibility extends to the use of computerised databases. This requirement 
for archival compatibility extends to the use of computerised databases. 
 
2.6.4 A ‘site plan’, based on the Ordnance Survey 1:1250 map (reproduced with the 
permission of the Controller of HMSO), will be prepared. 
 
2.6.5 Plans and sections will be drawn on polyester based drawing film at a scale of 
1:10 or 1:20. ‘Single context planning’ is preferred on deeply stratified sites.  
2.7 Treatment of finds and samples  
 
It is unlikely that there will be many finds or samples removed from the site. 
Treatment, analysis and subsequent handling of all finds and samples will be carried 
out by MoLAS specialists.  
 
2.7.1 Where necessary, the strategy for sampling archaeological and environmental 
deposits and structures (which can include soils, timbers, animal bone and 
human burials) will be developed by MoLAS. Subsequent on-site work and 
analysis of the processed samples and remains will be undertaken by MoLAS 
specialists. 
 
2.7.2 Any organic samples will be subject to appropriate specialist analysis. There 
may be a requirement to submit timbers to dendrochronological analysis and 
to process some samples to provide C14 dating. Other forms of specialist 
analysis may also be appropriate. 
 
2.7.3 The finds retrieval policies of the Museum of London will be adopted. All 
identified finds and artefacts will be retained, although certain classes of 
building material can sometimes be discarded after recording if an appropriate 
 19  p:\city1000\1091\na\field\mseval02.doc  

### Page 20

Method Statement ! MoLAS 
sample is retained. No finds will, however, be discarded without the prior 
approval of the appropriate curatorial departments. 
 
2.7.4 All finds and samples will be treated in a proper manner and to standards 
agreed in advance with the Museum of London. They will be exposed, lifted, 
cleaned, conserved, marked, bagged and boxed in accordance with the 
guidelines set out in the United Kingdom Institute for Conservation’s 
Conservation Guidelines No. 2 and the Museum of London, Standards in the 
Museum Care of Archaeological collections (1992) 2 and the Museum of 
London, General Standards for the preparation of archaeological archives 
deposited with the Museum of London, (1998). Metal objects will be x-rayed 
and appropriate objects then selected for conservation.  
 
2.7.5 The programme of ceramic dating and analysis will be undertaken by MoLAS 
specialists. 
 
2.8 Ownership of finds 
 
2.8.1 Whereas ownership of any finds on the site lies with the landowner, it is 
necessary that the landowner gives the necessary approvals, licences and 
permissions to donate the finds to the Museum of London, to enable that body 
to carry out its obligations to curate the finds, in perpetuity, as part of the 
archaeological Archive from this site.  
 
2.8.2 These approvals, licences and permissions shall be either confirmed in the 
Agreement and Contract regulating the archaeological works and/or 
confirmed by the completion of a relevant Deed of Transfer. 
 
2.8.3   The client (or their agent) will make arrangements for the signing of the Deed 
of Transfer Form by the client or, if the landowner is different to the client, by 
the landowner.  
 
2.8.4   Notwithstanding the above, subsequent arrangements may be made if required 
between the landowner and/or the client and the Museum of London for the 
conservation, display, provision of access to or loan of selected finds in or near 
their original location. 
2.9 Reports and archives  
 
 
2.9.1 The integrity of the site archive will be maintained. All finds and records will 
properly be curated by a single organisation, and be available for public 
consultation. The finds from excavations provide an immensely valuable 
research archive, but the bulk of the material is of little or no financial worth. 
 
 20  p:\city1000\1091\na\field\mseval02.doc  

### Page 21

Method Statement ! MoLAS 
2.9.2 Appropriate guidance set out in the Museums and Galleries Commission’s 
Standards in the Museum Care of Archaeological Collections (1992), and the 
Society of Museum Archaeologists’ draft Selection, Retention and Dispersal 
of Archaeological Collections (1992), will be followed in all circumstances. 
 
2.9.2 The minimum acceptable standard for the site archive is defined in the 
Management of Archaeological Projects (1991) Section 5.4 and Appendix 3, 
and discussed in detail in Museum of London, General Standards for the 
preparation of archaeological archives deposited with the Museum of London, 
(1998). The archive will include all materials recovered (or the comprehensive 
record of such materials as referred to above) and all written, drawn and 
photographic records relating directly to the investigations undertaken. It will 
be quantified, ordered, indexed and internally consistent before transfer to the 
Museum of London. It will also contain a site matrix (if generated), a site 
summary and brief written observations on the artefactual and environmental 
data. Copyright of the written archive will be vested in the Museum of 
London.  
 
2.9.3   The Museum of London’s guidance on the needs of digital storage and archival 
compatibility will be sought and followed. 
 
2.9.4   Pursuant to these agreements the archive will be presented to the archive 
officer or relevant curator of the Museum within 6 months of the completion 
of fieldwork (unless alternative arrangements have been agreed in writing with 
the local planning authority). If there is further field work the archive for the 
evaluation will be presented with the archive for that field work. 
 
2.9.5   A short summary of the results of the work, even if negative, will be submitted 
to the Greater London SMR and NAR (using the appropriate archaeological 
report forms), and for publication in the appropriate local academic 
journals(including the annual ‘Excavation Round-up’ in the London 
Archaeologist). 
 
2.9.6   Such publication will meet the ‘minimum requirements’ set out in Appendix 7 
of the Management of Archaeological Projects (1991), and derive from a 
‘phase 2 review’ as defined in the same document. 
 
2.9.7  Where the above mentioned ‘phase 2 review’ indicates the need for further 
assessment and analysis the recommendations set out in the Management of 
Archaeological Projects (1991) will be followed. 
 
2.9.8   The review process may, as a result of a ‘phase 3 assessment’ (as defined in the 
Management of Archaeological Projects), decide that significant 
archaeological remains uncovered in the course of an evaluation require full 
academic publication in an appropriate monograph or journal. Such review 
may conclude that publication must include descriptions and interpretations of 
the remains uncovered as well as specialist reports on the finds and samples 
recovered. Publication would normally take place after, and be integrated with 
the results of, any further field work, such as a watching brief or full 
 21  p:\city1000\1091\na\field\mseval02.doc  

### Page 22

Method Statement ! MoLAS 
excavation. Contingency arrangements (such as an agreed percentage of the 
field costs) to provide for this possible element of the work will be made 
before field-work commences. Site works will not commence until the Local 
Planning Authority has expressed itself satisfied that suitable arrangements 
have been made. 
 
2.9.9   The above notwithstanding, an Evaluation report, or at least an Interim report 
setting out the results of the evaluation, will be made available to the client 
and the Local Planning Authority within 2 weeks of the completion of 
fieldwork. 
2.10 Evaluation method agreement  
 
2.10.1 An adequate archaeological methodology and trench layout for the evaluation 
must be approved by the Local Planning Authority. There must also be a 
written archaeological agreement that satisfactorily implements the approved 
format and demonstrates sufficient financial support for all aspects of the work 
including finds processing, conservation, specialist analysis, archiving, 
cataloguing, report work and long-term storage and curation.  
 
2.10.2 This recommended format attempts to define best practice but cannot fully 
anticipate conditions encountered as the evaluation progresses. Material 
changes to the approved evaluation format are however only to be made with 
the prior written approval of the Local Planning Authority (Corporation of 
London). 
 22  p:\city1000\1091\na\field\mseval02.doc  

### Page 23

Method Statement ! MoLAS 
 
3 Timetable of works and staffing  
3.1 Timetable and staffing  
 
The timing and duration of the programme of archaeological evaluation will be 
determined by the contractor’s overall programme and the nature and extent of any 
surviving remains. It is envisaged that one Senior Archaeologist will monitor the 
archaeological works though other specialists may be called in if necessary.  
3.2 Attendances  
For evaluations and geotechnical pits the degree of subcontractor attendance required 
by the Museum of London Archaeology Service tends to be minimal as archaeologists 
are in fact attending the on-site works. However, some provision for welfare and 
working conditions will need to be anticipated. Some or all of the following 
attendances may be required. 
 
" Shoring in all excavations which exceed 1.20 metres in depth, installed 
in accordance with Safety Regulations and maintained throughout the 
occupancy of the area in question. Note that where mechanical or 
electric hoists are to be used in shored shafts, MoLAS H&S policy 
requires staff working in shafts less than 4m x 4m to leave the shaft 
before hoisting of buckets takes place and not to re-enter until the 
bucket is lowered back into position. Time for such evacuation will not 
form part of excavation programme. Beyond a depth of 3m within such 
shafts gas monitoring equipment will be required to ensure appropriate 
air quality for those working there. 
 
" Safety guard-rails and suitable access points into the site and areas of 
excavation, away from any site traffic and machinery.  
 
" Ladders into all areas of excavation when the excavated depth requires 
such access.  
 
" If ground-water is encountered in the trenches, adequate pumps will be 
required to remove it in order to complete the excavations. 
 
" If necessary, up to 2 tungsten halogen lamps (500W minimum) with 
110-volt transformer, adequate cabling, and power supply. 
 
" A suitable security system to operate overnight, weekends and 
holidays.  
 
 23  p:\city1000\1091\na\field\mseval02.doc  

### Page 24

Method Statement ! MoLAS 
" Labourers to assist in the removal of spoil from deeper areas of 
excavation.  
3.3 Accommodation and facilities  
As the excavations may extend, intermittently, over several days, the MoLAS 
archaeologist(s) will require access to a lockable facility for storage of tools and 
equipment. Although the site visits are likely to be intermittent the archaeologist 
should also have access to toilets with hot and cold water. 
 
4 Funding  
Agreement on funding for the archaeological field evaluation is being sought via a 
separate document.  
 
 
5 Acknowledgements  
MoLAS wishes to thank Nicholas Boyarsky of Boyarsky Murphy Architects and Alan 
Baxter & Associates.  
6 Bibliography 
 
ACAO, 1993 Model briefs and specifications for archaeological assessments and 
field evaluations, Association of County Archaeological Officers 
 
BADLG, 1986 Code of Practice, British Archaeologists and Developers Liaison 
Group 
 
Corporation of London 2002, Unitary Development Plan: City of London  
 
Corporation of London Department of Planning and Transportation, 2004 Planning 
Advice Note 3: Archaeology in the City of London, Archaeology Guidance, London   
 
Department of the Environment, 1990 Planning Policy Guidance 16, Archaeology 
and Planning 
 
English Heritage, 1991 Exploring our Past. Strategies for the Archaeology of 
England, English Heritage 
 
English Heritage, 1991 Management of Archaeological Projects (MAP2) 
 
English Heritage, 1997 Sustaining the historic environment: new perspectives on the 
future 
 24  p:\city1000\1091\na\field\mseval02.doc  

### Page 25

Method Statement ! MoLAS 
 
English Heritage Greater London Archaeological Advisory Service, 1998, 
Archaeological Guidance papers 1–5 
 
Institute of Field Archaeologists (IFA), rev. 2001 By-Laws, Standards and Policy 
Statements of the Institute of Field Archaeologists: Standards and guidance # Field 
Evaluation 
 
Institute of Field Archaeologists (IFA), supplement 2001, By-Laws, Standards and 
Policy Statements of the Institute of Field Archaeologists: Standards and guidance $ 
the collection, documentation conservation and research of archaeological materials 
 
MoLAS St Mary Somerset Garden, Lambeth Hill, City of London, An archaeological 
watching brief report, 2003 
 
Museum of London, 1994 Archaeological Site Manual 3rd edition 
 
Museum of London, (1998) General Standards for the preparation of archives 
deposited within the Museum of London  
 
Standing Conference of Archaeological Unit Managers, 1991 revised 1997 Health 
and Safety in Field Archaeology, Manual 
 25  p:\city1000\1091\na\field\mseval02.doc  

### Page 26

cYCDCC
DWfCCC
cCC fCC WCC ACC
DWfDCC
cYCDCC
ICC
HCC
YCC
'CC
cYcCCC
DWfDCC
ACCWCCfCCcCC
DWfCCC
cYcCCC
'CC
YCC
HCC
ICC
cYcCCC
DWfCCC
cCC fCC WCC ACC
DWfDCC
cYcCCC
cCC
fCC
WCC
ACC
cYcDCC
DWfDCC
ACCWCCfCCcCC
DWfCCC
cYcDCC
ACC
WCC
fCC
cCC
LandingrStage NavigationrLight
G\ixedrRedw
&ollards
Mud
AUIDm
AUfm
MudrandrShingle
WU'm
Jetty
’roynes
cfUIm
MudrandrShingle
’royne
Mud
Southwark
&ridge
cfUCm
’royne MudrandrShingle
&ollard
HUfm
cCUDm
Southwarkr&ridge
Stairs
MudrandrShingle
Mud
’royne
MudrandrShingle
TrigrLane
Stairs
’royne
Slopingrmasonry
cCUDm
L&
ccUIm
cfU'm
&P
PTP
cAUcm
UndergroundrRailway
&P
&P
cAUCm
Subway
&P
cCUYm
T:&
&MrHU'Am
HUWm
\n
L&
&ollards
'UHm
\&
Posts
P
\&
\&
Tunnel
Tunnel
Twr
:hurch
Gsiterofw
cWUIm
ccUHm
L&
&M
Posts
Posts
ccUCm
&anksiderJetty
Whittingtonr’arden
:arrPark
G&eloww
StrMary
Somerset
’arden
’ardens
:leary
T:&s
Posts
\&
cHUIm
:ath
edra
lrPlace
:athedral
Place Panyerr,lleyrSteps
Pa
ny
err
,ll
ey
&MrcHUAHm
Mi
tre
r:o
urt
cAUDm
PrudentrPassage
&MrcDUAcmcDUcm
L&
&udger
Row
Subway
T:&
Wellr:ourt
:ro
wnr
:t
cIUWm
&MrcHUCYm
jef
je
f
&ow
r:hu
rchy
ard
’rovelandr:t
W
,TLI
N’
cAU'm
\ountain
\ountain
L&
cHUAm
cHUWm
cHUDm
Gsiterofw
\&
:hapterrHouse
:ourt
&MrcHUfDm
cHUcm
&MrcYUffm
jr\n
cHUfm PTP
cDUIm
:oachrPark
cDU'm
cWUHm
&MrcIUffm
cAUYm
T:&s
ThreerNunr:ourt
\ountain
&M
rcAUHc
m
jr\n
’uildhallYard
PTP
&MrcIUCfm
L&
cDUAm
cIUfm
cDUDm
&MrcIUcfm
StrMary
Staining
Publicr’ardens
cIUIm
jr\n
\nSj
Postmanys
Park
:hristr:hurch
Passage
cHUWm
Statue
cHUfm T:&
\&
Priestys
:OURT
&MrcIUYfm
cI
UCm
ROM,Nr\ORT
Gsiterofw
Wardr&dy
Tompter
The
ROM
,Nr
W,
LL
©leanorr:ross GSiterofw
:hurchyard
T:&s
T:&s
T:&s
T:&s
T:&s
T:&s
&ow
r:
hu
rc
hy
ar
d
cIUWm
cDUDm
Northr’ate
&M
rc
HUA
Hm
T:Ps
L&
T:Ps
:arterrLaner’ardens
T:&s
\estival
’ardens
Memorial
Df
Dc
A'
fa
W
albro
okrW
harf
Hall
I'
IYUD
&ullrW
harf
&rookysrWharf
fc
cCc
WalkerrHouse
&ank
ccf
ccC
Y
Paintersy
Hall
'
fD
fY
fH
Af
AC
PHfY
fH
cD
DW
a
Dca
ff
ID
PH
IW
Ic
I'rtorHW
HD
IY
rto
rH
C
Templer:ourt
ff
fC
c'
A
fC
Wfc
c'
ID
II
IA
'
A
c
StrJamesys
:hurch
StrMichaelGPaternosterwRoyalr:hurch
The
ofrStrNicholas:oler,bbey
TherSalvationr,rmy
SunlightrWharf
Sir
JohnrLyon
House
Thames
Street
QueenysrQuay
Qu
ee
ns
bri
dg
e
Ho
us
e
Str&enetrMetropolitan
Welshr:hurch
cH
YArtor'A
DC
InternationalrHeadquarters
Hca
Hc&ank
&ank
:o
urt
WI
:ityrofrLondon
School
&ank
fcrtorf
I
jo
by
c
Thamesr©xchange
LittlerShipr:lub
WW
YD
AC
fW
cW
IW
crt
orf
MansionrHouse
Station
c
c
&rackenrHouse
&uilding
IY
cC
IC
If
DY
fCcrtorffc WCcrtorWc'
ACcrtorAc' DCcrtorDc' ICcrtorIcc
HCc
Ther’lobe
Theatre
Inigo
Jones
Theatre
RiversiderHouse
fH
&ear
Wharf
Vintnersy
\i
ve
rK
ing
srH
ou
se
YHrtor'D
cC
rto
rcf
IfrtorI
W
Ic
'rto
rcC
&lock
NorfolkrHouse
VintnersrPlace
cCcrtorccY
Hf
Tha
me
srH
ous
e
Middle
&lock
Riverr&lock
&roken
Wharf
House
crtorcc
c
SenatorrHouse
PH
AArtorAI
’uildr:hurch
:ollegerofr,rms
IA
Nikko
House
Kn
igh
t
Rid
er
Ho
use
cfY IC
IH
crtorcWI
’loberView
cC
W'rtorDW
Hc
IY
HC
Hf
HArtorYf
W'
c' fC
fArtorfI
WY
f' Ic
IHrtorI'
HC
Hc
Hf
HW
HAHDHIHH
'
Y
H I
D
cfWA
A
cf
cc
'
W
f
ca
cC
DI
Df
Dfa
DC
A'
AY
cc
cf
Drtor'
AH
AA
AW
AC
Af
a
Af
cC
rto
rc
D
'C
'f
cr
to
rH
fA fD
'r
to
rc
f
cA
cD
cI
cH
AAfI
fY
f' WC
Wc Wf
WW
WA
WD
WI WH
W'
f
cCcrtorccI
cfCrtorcff
A
cfH
cD
IcrtorIH
c
I'HC
cf cc cC
Y H I D A W c
ADAWAfAc
fDW'
WIWDWA
fC
cIf
cDcrrrrcDC
WD
D
A
cc
cC
Ar
to
r'
fCrto
rfY
f'rtorWf
c
I
cC
D I A W
fW
ff
fc
WC
fW
fc
WH
cArtorcY
frtorcf
DrtorI
WA
WW
cI
fr
to
rc
A
H
D
Wc
D'
IC
Ic
c'rtorf'
c
IC
Ic
If
IW
c
IA
ID
II
IHrtorI'
crt
orD
H
I
Y
PH
St
Paulys
Sta
&ank
StrVedastys
:hurch
&ank
PH
&anks
PH
&lossomys
Inn
&ank
&ank
&ank
PO
&ank
&ank
PH
PH
&ank
HoneyrLane
PH
Statue
&ank
StrM
aryPleP&ow
:hurch
WilliamsonysrTavernGPHw
&o
wr&
ellsrH
ou
se
&ank
&ank
&ank
&ank
&ankrof&oston
House
:hapter
House
Statue
StrP
au
lys
r:
at
he
dr
al
:ho
irr
Sc
ho
ol
&ank
Tower
Information
Ther:harteredInsurance
Institute
Memorial
’uildhallrL
ibrary
&ank
&ank
PostrOffice
©ngineeringrj
epartm
ent
Tower
PolicerStation
Pewterers
Hall
Wax
:handlersyHall
&ank
Hall
PH
’enera
lrPostrOffice
Hospital
Af
PH
A
I
cI
c
cf
W
cf
A
cWArtorcAH
WW
fY
rto
rW
C
fC
cW
Dc
AI
:entre
G:ityrofrLondonw
DA
GLTw
Saddlers
&ank
cC
c
&ritishrTelecom
:entre
’oldsmithsy
Hall
StrPaulysr:athedral
:hurch
JewryPnextP’uildhall
:hurch
StrLawrence
AArrrrrrrA
C
P:s
YcrtorYH
cfD
&ank
c
’uildhall
&uildings
A'rtorDH
cC
c
c
fC
&ank
Str,nne
andrStr,gnes:hurch
Str&otolphrwithout
,ldersgater:hurch
cC
NomurarHouse
W
ff
PH
GN
at
iona
lrP
os
trM
us
eu
m
w
cf'rcfY
cWWrrcWC
'HrtorcCC
fC
AIrtorDf
cW
C
HY
'C
Y
cc
&ank
frtorI
WC
cYrtorfC
StrMaryr,ldermary
cD
IW
WC
fY
cfrtorc
A
&owr&ellsrHouse
WrenrHouse
&ank
cc
crtorA
HD
c
HCrtorYC
cr
to
rD
YD
YC
crtorD
H
D
cW
cc
W
Yc
c
WD
WatlingrHouse
WW
f'rtorWc
&ank
Irtorcf
cHrtorfW
ACrtorAD
WfrtorWI
D'rtorIH
IC
YD
cC
C
,lderr:astle
&,NKSIj©
N©W
r’LO&©rW
,LK
&©,Rr’,Rj©NS
&©LLrW
H,R\rL
,N©
QU©©NrS
TR©©TrP
L,:©
QU©©NHITH©
ST©W
rL,N©
HI’HrTIM&©RrSTR©©T
&©NN©TyS
rH
IL
L
’OjLIM
,NrS
TR©©T
L,M&©THrHILL
QU©©NrVI:TORI,rSTR©©T
jIST,\\rL,N©
OLjr\ISH
STR©©TrH
ILL
\RIj
,YrS
TR©©T
&R©,jrS
TR©©T
HU’’INr:OURTHU’’INrHILL
LIT
TL©rTRIN
IT
YrL,N©
’,RLI:
KrH
IL
L
’R©,TrSTrTHOM,S
,POSTL©
:,NNONrSTR©©
T
TOW
©R
ROY,L
QU©©N
STR©©T
:LO,KrL,N©
:OLL©’©rSTR©©T
SKINN©RS L,N©
’R©,Tr
TRINITYr
L,N©
Newcastle:ourt
’,RjN©RSrL
,N©
UPP©RrTH,M©SrSTR©©T
Miniver
Place
:,STL©r&,YN,RjrSTR©©TrGbeloww
&OOTHrL,N©
:OLL
©’©rH
IL
L
:ardinal
’ap
,lley
PeterysrH
ill
PaulsrWalk
\Y©r\OOTrL,N©
Vintn
ers
y
Threer:ranesrW
alk
K©NN©TTrW
H,R\rL
,N©
&ROK©NrW
H,R\
LITTL©rTRINITYrL,N©
TRI’rL,N©
:ourt
:T
RIj©R
KNI’HT
:ourt
Oldr:hange
N©W’,T©r
STR©©T
\OST©RrL
,N©
Roserandr:rown
W
OOjrS
TR©©T
’OLjSMITHrSTR©©T
MI
LK
rS
TR
©©
T
Russia
:ourt
RUSSI,rROW
TRUMPrSTR©©T
MUM\ORjr:OURT
L,W
R©N:©rL
,N©
IR
ONM
ON’©RrL
,N©
STR©©T
QU©©NrS
TR©©T
&R©,jrSTR©©T
W,TLIN’rSTR©©T
:H©,PSIj©
P,T©RNOST©R
ROW
StrPaulysr:hurchyard
N©W
r:
H,N’©
:,NNONrSTR©©T
\RIj,Y
STR©©T
jIST,\\rL,N©
Serm
onrL
ane
’OjLIM
,NrS
TR©©T
:,RT©RrL,N©
STrP,ULySr:HUR:HY,Rj
,L
j©
RM
,N
&U
RY
,Lj©RM
,N&URY
’R©SH,MrST
R©©T
W
OOjrS
TR©©T
LOV©rL,N©
O,TrL,N©
ST,IN
IN
’rL
,N©
’UTT©RrL
,N©
:,R©YrL,N©
STrM
,RTIN
yS
rL
©r’
R,Nj
LITTL©r&RIT,IN
,N’©LrSTR©©T
:ourt
KIN
’rS
TR©©T
&ow
rLan
e
:T
RIj©R
KNI’HTKNI’HTRIj©RrST
:ourt
NO&L©rS
TR©©T,Lj
©RS’,T©
STR
©©T
KI
N’
©jW
,RjrS
TR©©T
QU©©NrV
I:TORI,
&owrL
aneOldr:hange
:ourt
MeanrHighrWater
RiverrThames
KingysrReach
MeanrHighrW
ater
MeanrHighrWater
Pond
Und
::LW
Und
W
ardr&dy
jef
Und
jef
jef
Und
Wardr&dy
jef
Und
:R
je
f
:ityrandr:ountyrofrther:ityrofrLondon
©uror:onstpr&oror:onstrJrL&r&dy
QU©©NHITH©rW,Rj
:R
jef
jef
&Ps
jef
jef
jef
:W
&Ps
Un
d
Und
:RUnd
:R
&Ps
jef
:W
\W
jef
\W
:W
:W
:R
jef
jef
Und
Und
Und
jef
Und
jef
&Ps
jef
&Ps
W
ardr&dy
\W
\W
jef
Und
&S&P\W
Und
jef
\W
jef
\W jef
jef
Und
:R
Wardr&dy
Und
\W
9
Fig 1  Site location
C cCCm
NN
ReproducedrfromrtherffUAU''rOrdnancerSurveyrcOcfDCrmaprwithrtherpermissionr
ofrther:ontrollerrofrHerrMajestyysrStationeryrOfficepr©r:rownr:opyrightU
:orporationrofrLondonrlicencernumberrOrL,rCYHfDA
:ityrofrLondon
thersite
NN
CrrrrrrrrrrrrrrrrrrrrrrrrrcCkm
R:\Project\city\668\fig01
SYO03LWatchingLbriefLreportLLL L©MoLASL2003
thersite
DWffCC\
cYcCCC
DWfcCC\
cYCYCC
9
Fig 1  Site location
ThisrmaprisrreproducedrfromrOrdnancerSurveyrmaterialrwithrtherpermissionrofrOrdnancer
SurveyronrbehalfrofrthercontrollerrofrHerrMajesty’srStationeryrOfficer©r:rownrcopyrightrfCCAUr
,llrrightsrreservedUrUnauthorisedrreproductionrinfringesr:rownrcopyrightrandrmayrleadrtor
prosecutionrorrcivilrproceedingsUr:orporationrofrLondonrcCCCfWfAWrfCCAU
R:\Project\city\1091\fig1
MethodLstatementLL©MoLASL

### Page 27

9
Fig 2  Areas of investigation
’ ©5m
NN
R:\Project\city\1091\fig03
Method statement  ©MoLAS
LambethGHill
UpperGThamesGStreet
CastleGBaynardGStreetGWbelowk
StGMary
SomersetG
Garden
StGMary
SomersetG
Tower
5.g©A’\
©8’86’
5.g©9’\
©8’9’’
WalkerGHouse
ThisGmapGisGreproducedGfromGOrdnanceGSurveyGmaterialGwithGtheGpermissionGofGOrdnanceG
SurveyGonGbehalfGofGtheGcontrollerGofGHerGMajesty’sGStationeryGOfficeG©GCrownGcopyrightGg’’AvG
AllGrightsGreservedvGUnauthorisedGreproductionGinfringesGCrownGcopyrightGandGmayGleadGtoG
prosecutionGorGcivilGproceedingsvGCorporationGofGLondonG©’’’g.gA.Gg’’Av
trench
trialGpit

### Page 28

9
Fig 3  Locations of previous works in relation to proposed works
j ’5m
NN
R:\Project\city\1091\fig03
Method statement  ©MoLAS
LambethGHill
UpperGThamesGStreet
CastleGBaynardGStreetG8below6
StGMary
SomersetG
Garden
StGMary
SomersetG
Tower
drainGrunG©
soakaway
GB
soakaway
GA
drainGrunGg
drainGrunG’
siteGboundary
5g©’.j\
’8j86j
5g©’9j\
’8j9jj
WalkerGHouse
X
LocationGofGreburial
GofGhumanGbone
ThisGmapGisGreproducedGfromGOrdnanceGSurveyGmaterialGwithGtheGpermissionGofGOrdnanceG
SurveyGonGbehalfGofGtheGcontrollerGofGHerGMajesty’sGStationeryGOfficeG©GCrownGcopyrightG©jj.OG
AllGrightsGreservedOGUnauthorisedGreproductionGinfringesGCrownGcopyrightGandGmayGleadGtoG
prosecutionGorGcivilGproceedingsOGCorporationGofGLondonG’jjj©g©.gG©jj.O
trialGpit
trench

### Page 29

9
Fig 4  The Wren tower of St Mary Somerset with proposed works shown
R:\Project\city\1091\fig4
Method statement  ©MoLAS 
trench
trial pit

### Page 30

Method Statement ! MoLAS 
7 Appendix 
Alan Baxter & Associates Engineer Drawings 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Supplied by  
Boyarsky Murphy architects 
 30  p:\city1000\1091\na\field\mseval02.doc  

### Page 31

td or$$Bqqele@EqE :TYt^t?
az{n'osat oao xvJ sSsI 0sz{, oz0 i{Nol{dirt![
t:'r9 wr_)t N(xlNo.t J,lxlus ssou,)dtol t,
!^lti{:,tN IC Ni,t a)NtJ,.tr)SNOJ
SAJVIJOSSV 8 dAIXVg NV'IV
4W
wffiffi
l -  -  - - _ l
r i
v l
l l
t l
I ffil-
i _ffiTV
\
I
I
, l
i.aoilv/ltrldqt,( \,rt, rl}t zol ffaH"?v{h?Uy'V lrnl|N|}tvlto
.4U lfir{t oL 1}fK ;iil
ii.rt|irjt ^ddrrvg 3(qo€ at ]
1FS ?qJ ovOP :ou.tSrxt
J MllSYElSNol tM'.Dlli0
oJ i.lodYlv)xl l0 iild,\',!|tql. gt{l-Lstvl
3rtj. 4 SNoIIVaMOI O{Y
tnrrrus ny^.t DN,MvJsdgvuslY3 ,fir Jo rrdrQ i|Fibrd.l(l'i0t 3r{! -rv t6l-. .--. - qr tbrdd-r v 1!v v l
J
al ,ru :lt ai- ijd tYtdl- - -j

### Page 32

Tos/or/leet
O O I : I
{€Y - t3ulttro) rit6Js
jailDr,alg .l.tvpl )Nt ts(.trr?t
)Nuslx:l irLL 01 rri\i_if,ld SftiOM ^ta&rd$dr:ja|ltI..J(J
J:|€n[tt{€ AWH -rs $ UtftQl
:r{or
tal:rCdrio !hr' Sxir)t{ .]li-L
.'tEij$o AL oNYgr aV
SJ)i^ds SNlistxl ft t
'sl.hLro}.lrnr RNrLsiNS
3ttr rNtr€E0Nn Jl
Tlts ,otr\rz[x)) :trl
+t3 -lril. 9NBno se){l3 I nV r! i.bl! fq I
',(aYsss):N I ZmNAgtrdoft AtyAH3r iW I flr. JN .aiJS rc lifid9v, l$IrrrvsNl I rslsc I rB aL ldv ()vqlrod
,lu -al' tdrrr{odga I -rd. klo frvltrro&ty9I Nq[y9Ljst^r{ I gv sNcu.ygtLcr{t{
.4u. 5 )tlli! Irt! :tt5{
ai- Sl ?olfYdINO t&-
3tT, Hri M <FFJ@J
qL f6H grw alnrs
-nY _.t| ctNYrNM{ si
ntis ?aiJYX jllrl 3{l- II f .rannrrur 'rruu.Crra
@o6sv .Jo nivl.3d lol I
lsfht stirirvrjra Nl $ti!!9bl /.'rVniiVC Otl-v( '91,{nFA o]$n'?riluftb ,rN 1 .fldr9 V o! lNnff.dvV 0r lNl)(&Jr
j o ' \ a  \ 2
sasn }}{o)tf|{
r9Nrodro&rfs i{l qL
l)twlfduslQ lfi NrH iijlt,l
, sizi}1 3ftL .r-m Atwl
? N6ti01 J0 r\ioirwodtg]
-3ttl. HiJ t{ 9fioft
NdLV)if€d arL
p stNlt{Y{ g&[lr{rrt{l
!{VA:IE, 4 r.0 Tly .t H
l.oulhn-oNol M oY4
il ol st 9y11..ry66 9161
l - - * - r
l l
, v lr l
-'iltri ii1.iahfi
Stdn.tlRrls qit.lsxa lo I o?qo+y'Efl .t{ ,Mi{rto QLArnFvA 3{I lltr itrBr€t I EAd Sbr/,rES @tr)B
l.iotlYltJrEA-?Jtt li.l'rl,t blotJu-$qtTf: *dxvt
@ 'r'*ar€ iiil t rqflo tfl JAtIVl.l.lSElN.ll 5J.lr{}t1lsl1 HfitNrH iulN
=j Fffi ATn:Jun .r-tp @rrrrvl jllt
's3tI
lv -rv rcu- | lev
tdtY zu dErn c1rcqs 4l
tJW dn z\Ero 0L !l
Zor,\arlf(D JtI 9Dq\4
-nttl. l0 l{o[5ldl{o Nhdl .

### Page 33

td.or.rrrcquqsosqe .uvl u
zzof 0J:{. oz0 xvJ t59l {Ez! oz0 gNoHd.d.Iu'tsg huJit NoqNo.l llaxu]s ssoutr{to) s!
suxsNlcNS tlNIJ,InsNo:)
SSIVIJOSSY T USIXVfl NV'IV
.LHSIH^doc o
[- _ - --l
- 
****dt{-li)A o!
}{nsv
t{!rt{G
^ll}J .6, :ErO!
,133t rs onvN^!€ tuscJ
Jsrq ZEf)rlrrl
-nv +NlfvLft
rioi<il:lia dslbd*.---- -.---
I
l-i
l
J0 iNlzi-lol sll{! lJt.KfiV ar laa n!?'\
9Nri{Ylsd aNU9DG 3{-L o!
s:rvo (r ro.t !s9) :rtt a.r
|.rJtrvelLNt 1lDtdoJslH :ru_
ffir
I Y
l-r
/)
.slv-ts
blrlvd ot$ GqB)a
$nbn SNusi{] - -
r}rt J SSYNlvdC
rlNfr^v3 CBrlr6y

### Page 34

V o?re/oir/rs€1.,,,-arutrl?l'Ls ..llvf't St,rlNtvlSd aNllsDel GlrnseY:.|m'3Jrt
ffi,0,',",ut so, fi"trH
:rrE(I
Nrois sv
({'y - IeurElro) :etBrS !FUA# Atttut ls JO A3HQ.jL.q.fTdd ,,"",a
9o't"\tlz
-t
-DNthrYLg .1t?rl
9X reNrlslrg C3r*
lrwu fr€rl
ttrql -rtr^{ r€h-s/g \
CllJ'J nsDl,6dd iDtHfi -7
tl,ctftlat -rvNDado @Hy
TIJ s, o9U
sn{ft 9t{iNlvlJl 1a
daxn
a3f€L !r{rx
|oaHl)c or$dldd s :Nf
to I 1! s'oN
Sthurfrc Ai@nH i1!tr,(afi. M
tBa Hol5}i?b6 GlroJdli :.fiJ
J l-sijjrxr .rii Ni Sbi^im
orrDd! liod * .lrixfl
,didti gii- .{ 4,{rc}rvls@{l
srvrmv | >utxvt
tffv 9r0rs rrNrHfdc $lt!
't u Adlnllv!,q31ft
rrt/ t'r/tO -on
+Mrry& rN3xllvdro
rNaEuNrSt€ r.Lb Io0 al
J0 |o|-L\/rqno) t€
olsw sr 9Nl url clHl-
ft^t
r.r@
rdY
, s l
l Y 4
rgg|/ -..- -
s s Y _ * . . - _ . ' ) 5
,/\
rxa -
r
II
^Dnd)
ji|r i0 Alrl9sr€/sa
lfirlr{g rft{6 (EDYH!o
I sdv& SD,UA .bNlll
ltt i\€tq -l'tt S3@ N l
i r^ri})roN I )rilNfro 1
I
] Ydar.{ ,N]l€h
iest *^ds {ru$a
I lo $EI!:l I rqJrlm
I ot tv ,*,t tnnl ^r,
I ar9 t€rulo i
f""""t,
I:.
|.'."
T
t .
$r,av
o o l r l
re dtrar 5N!
r 
.._ sN$MNrrlt (
r i--t-r r--_r
l r l i v i-l- - -r''- - |':1_:;4-_a i i i ;
d " i  I  /  \  i-l iA"i ,r ,. il r w i i i
. :  ,  l i
zrL -_4.+li I [, 7---_-l" o ' + 1 t r  I  r r u  t  IT , / ,  i  l x l  I
i  I  t / " 1'  l / ' \ l  v l
. l " lr l
l i l , l|  '  - L
*,i '\---''_-----.-------------'
.4ii
OL
h€
Ir€
[ ]
 d)
yfv
AS
{L er
i 5iU9N