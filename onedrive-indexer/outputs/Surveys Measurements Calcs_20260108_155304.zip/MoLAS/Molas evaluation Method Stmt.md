# Source: Molas evaluation Method Stmt.pdf
**Path:** `MoLAS/Molas evaluation Method Stmt.pdf`
---

### Page 1

ArchaeologyrrrService
TOWERrOFrSTrMARYrSOMERSET
LambethrHill
EC4
CityTofTLondon
AnTarchaeologicalTevaluationTreport
NovemberTpnnt


### Page 2

TOWERTOFTSTTMARYTSOMERSET
LambethTHill
ECs
CityTofTLondon
AnTarchaeologicalTevaluationTreport
SiteTCodey SYOnr T
NationalTGridTReferenceyTtrpourTownwwn
ProjectTManager
Author
Graphics
SophieTJackson
EmilyTBurton
KennethTLymer
MuseumrofrLondonrArchaeologyrService
©rMuseumrofrLondonr2005
MortimerTWheelerTHousejTsuTEagleTWharfTRoadjTLondonTNoTvED
telTnpnTTvsonTppnnTTfaxTnpnTvsonTppnoTT
emailTmolas@molaslorgluk
webTwwwlmolaslorglukT 

### Page 3

 [SYO03]Evaluation report ! MoLAS  
Summary (non-technical) 
 
 
This report presents the results of an archaeological evaluation carried out by the 
Museum of London Archaeology Service on the site of the tower of St Mary Somerset, 
Lambeth Hill, London, EC4. The report was commissioned from MoLAS by Boyarsky 
Murphy Architects on behalf of their client.  
 
The evaluation was required as a condition of planning consent for conversion of the 
church tower to residential accommodation (ref:  05/00194/FULL, dated 12 May 
2005).  Evaluation pits were excavated to the north of and within the tower. A further 
test pit which was excavated for a borehole was monitored to the east of the church.  
 
The results of the field evaluation have helped to refine the initial assessment of the 
archaeological potential of the site. Foundations of the south wall for the 17th 
century church as rebuilt by Wren were observed to the east of the church at 0.25m 
below ground level. The structure continued below the limit of excavation at 1.40m 
below ground level. Foundations of the tower itself were observed to a depth of 3.95m 
and extended c1.00m to the north of the tower’s plinth. 
 
Within the tower remains of what has been interpreted as a disturbed east-west 
aligned foundation were recorded at 0.75m below floor level. The feature was 
constructed of large blocks of chalk, ragstone and flint, and may represent remains of 
the foundation for the original 12th century church. 
 
Evaluation pits to the north of the tower revealed truncation of archaeological 
deposits to between 1.90m and 2.00m below ground level by 19th century 
warehouses. A chalk and ragstone feature was observed in pit 1 at the limit of 
excavation. 
 
 
 
 
i 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 4

[SYO03] Evaluation Report ! MoLAS  
 
 
Contents 
 
1 Introduction 1 
1.1 Site background 1 
1.2 Planning and legislative framework 3 
1.3 Planning background 3 
1.4 Origin and scope of the report 3 
1.5 Aims and objectives 3 
2 Topographical and historical background 5 
2.1 Topography 5 
2.1.1 Roman masonry structures 5 
2.2 The Medieval street plan and churches 5 
2.3 Post-medieval 6 
3 The evaluation 9 
3.1 Methodology 9 
3.2 Results of the evaluation 10 
3.2.1 Evaluation pit 1 10 
3.2.2 Evaluation pit 2 11 
3.2.3 Evaluation pit 3 12 
3.2.4 Evaluation pit 4 13 
3.2.5 Borehole 1 13 
3.3 Assessment of the evaluation 16 
3.3.1 Period 1: Natural ground 16 
3.3.2 Period 2: Undated 16 
3.3.3 Period 3: St Mary Somerset Church, 17th century 17 
4 Archaeological potential 18 
ii 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 5

[SYO03] Evaluation Report ! MoLAS  
4.1 Realisation of original research aims 18 
4.2 General discussion of potential 20 
4.3 Significance 20 
5 Assessment by EH criteria 21 
6 Proposed development impact and recommendations 23 
7 Acknowledgements 24 
8 Bibliography 24 
9 NMR OASIS archaeological report form 26 
9.1 OASIS ID: molas1-10921 26 
 
 
iii 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 6

[SYO03] Evaluation Report ! MoLAS  
 
List Of Illustrations 
 
Front cover: The Wren Tower of St Mary Somerset  
Fig 1 Site location 2 
Fig 2 Areas of evaluation and archaeological features 7 
Fig 3 The Wren tower of St Mary Somerset 8 
Fig 4 Foundation in test pit 3 looking south-east 15 
  
 
 
iv 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 7

 [SYO03]Evaluation report ! MoLAS  
1 Introduction 
1.1 Site background 
The evaluation took place on the site of the tower of St Mary Somerset, Lambeth Hill, 
London, EC4, hereafter called ‘the site’. The site comprises the garden and remaining 
tower of St Mary Somerset Church and is bounded by Lambeth Hill on the north side, 
and Castle Baynard Street to the south (See Fig 1). The centre of the site lies at 
National Grid reference 532163 180880. Modern pavement level near to the site lies 
at c 8.56m OD. The existing ground floor slab within the church tower lies at 
approximately 7.30m OD. The site code is SYO03. 
 
The church tower is a Grade 1 Listed Building.   
 
A method statement was previously prepared, (Aitken, 2005). The document should 
be referred to for information on the natural geology, archaeological and historical 
background of the site, and the initial interpretation of its archaeological potential.  
 
An archaeological field evaluation was subsequently carried out by means of a series 
of test-pits around the outside of the tower and one within the tower. 
 
A previous watching brief was carried out on the site by MoLAS in 2003 and 
involved monitoring of excavation of new drain runs and soakaways around the 
gardens.
1 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 8

cgcppp
u'cupp
Qpp ypp gpp Vpp
u'sppp
cgcppp
cpp
spp
'pp
bpp
cgcupp
u'sppp
VppgppyppQpp
u'cupp
cgcupp
bpp
'pp
spp
cpp
'pto'b
cc
cb
s
sQ
sy
'p
's
'u
'b
bc
sb
ub
bp
yp
gltolcg
g'
lto
lg
Q
gy
gg
s
c'
cc
u
'
b
'
s
c
ccc cpg cpy
QltolV
Vg cpp cpc
g
y
u
b
c
sl
to
l'
b
u
Q
y
cQcy
'buss
s'
y
s'a
sb
VV
VyVQVuVpltolVbgVgggugs
bl
to
ly
g
c
s
gl
to
lc
s
c'
cu
bs
V
cs
HUTTONlSTR’’T
RIS
’
jO
RS
’T
The
&ridewell
Theatre
jORS’Tl&UILjINGS
&R
Ij
’W
’L
LlPL
,/
’
PH
&ank
je
f
N’W
l&
RIj
G’lS
TR’’T
/R&M
ly
Kp
pm
PO jef
,POTH’/,RY
&L,
/Kl©
RI,R
SlL,
N’
,pothecariesn
Hall
PL,YHOUS’lY,Rjb
cpltolcg
cu
cy
sp
y gc yV
yu
y' yc
c
u y
u
u
b
s
'
Q'ltolQy
Qc
uVa
c
s
'
b
u
Q
y
'Q
'y
'g
'V
bpltolbc
uV
c
s
'
b
u
Q
cp
'Q
u
Q
ss sp
ultolcb
c
b
cVs'
Q
y
g
V
g
'gbp
bs
bb
bQ
bg
up
us
ub
ybltolQg
yQ
V
cc
y
'u
'V
Und
LU
jG
,T
’l&
RO
,j
W,
Y
/o
bb
nsl
/o
ur
t
/a
rte
r/o
urt
NestorlHouse
/,RT’RlL,N’
LUjG
,T’
SQU
,R’
&Ps
/R
&P
c'K
bm
PH
PH
jef L&
STl
,NjR’W
nS
HIL
L
W
ar
dr
ob
el
Pl
ac
e
,j
jL
’l
HI
LL
©aradayl&uilding
cbKQm
T/&s
L&
/,RT’RlL,N’
c'KQm
YouthlHostel
jeanery
j’
,N
nS
l/
OU
RT
STlP,ULnS
/HUR/HlY,Rj
Statue
StlP
auln
s
/hurchlYard
Un
d
/h
ap
ter
Ho
us
e
Stl
Pa
ulns
l,l
ley
,V
’l
M
,R
I,
lL,N
’
cQltolsg
cuKpm
L,
N’
/R’
’j
'p's'Q
'bbp
'g
bs
PH
©W
Th
e
Gu
ildl
/h
urc
hl
of
Stl
Ma
rtin
Y
wit
hin
YLu
dga
te
&MlcbKpum
&P
LUjG,T’
ksiteloff
/W
LUjG,T’lHILL
csKcm
'uupltolQs
GovernmentlOffices
VKpm
PH
LUjG,T’
/IR/US
yKcm
PH
yKVm©L’’TlSTR’’T
PH
PH
&M
lccK
cy
m
S,
LI
S&
UR
Yl
/O
UR
T
cpKym VKgm
STl
&RIj’l
STR’’T
Harpl,lley
QK'm
&ank
PO
PP
IN
Sl
/O
UR
T
yKQm
OLjlS’,/O,LlL,N’
P/s
Turntable
Hall
Thel©leetlPrison
ksiteloff
LIM’&U
RN’Rl
L,N’ SeacoallHouse
kLondonl’lectricity&oardfV
cl
to
lg
Hillg
at
el
Hou
se
sy
lto
l'b
csKgm
PH
sQ OL
jl
&,
IL
’Y
Q
Un
d
W
ar
dl&
dy
W,RWI/K
SQU,R’
cyltolsc
gl
to
lc
s
gbgag
V
b
' c
u
cltolcs
,men
Lodge
,M’Nl/ORN’R
StationersnlHall
,M’Nl/OURT
,M’Nl/OURT
Sj
&MlcQKubm
cQKcm
W
ar
dl
&dy
jef
cQK'm
W
,R
W
I/
Kl
L,
N’
Und
N’WG,T’lSTR’’T
b
csQ
PH
&Ps
NewlGate
ksiteloff
je
f
/utlersn
Hall
/en
tral
/rim
inall/
ou
rt
cbKpm
STlG’ORG’SnSl/OURT
cQ
&ISHOPnSl/OURT
y c
s
'
u
Q
yg
cp
cbltolsc
TURN,G,INlL,N’
’l
SublSta
N’W/,STL’l/LOS’
QK'm
&earl,lley
TurnY
table
OLjl©L’’TlL,N’
©,
RRIN
GjONlS
TR
’’
T
STON’/UTT’RlSTR’’T
©leetl&uilding
cpKcm
/ity
Temple
PLUMTR’’l/OURT
yKVm
&M
lgK
bs
m
T/& &MlcyK'ym
usltolQp
'yltolbc
QcltolQu
cQKum
HOL&ORNlVI,jU/T
cQKcm
SNOW
lHILL
Pol
Sta
b
'
s
c
cs
Q
y
g
V
PH
&MlcyKgQm
/hurchloflthe
HolylSepulchre
withoutlNewgate
cQKpm
L&
jl©n
cQKbm
GIL
TS
PU
RlS
TR
’’
T Stl&artholomewnslHospital
Und
Und
jef
Und
/hristnslHospital
ksiteloff
Ve
str
y
Ho
us
e
/hr
istl/
hu
rc
h
Gre
yfria
rs
Stl&ridensl/hurch
&R
Ij
’l
L,
N’
SH
O’
lL,
N’
cs
yl
to
lcc
S,
LIS
&U
RY
SQ
U,
R’
Statue
c
s
Kildare
House
Stl&ridenslPassage
cQ
lto
lc
g
'u
lto
l'
y
/h
urc
hl’
ntr
y
&lackfriarslPriory
ksiteloff
IrelandlYard
©r
iar
lS
tre
et
&ur
gon
lStr
eet
'
/re
edl
/o
urt c
cp
/athedral
StlPaulns
Sta
tion
ers
Ha
lll/
our
t
P,
G’
,N
TM
,S
T’
R
u
T/&s
Stl&ridensl,ve
Stl&ridensl,venue
LudgatelHouse
clt
olQ
/ar
Park
b
Gr
ey
fri
ar
slP
as
sa
ge
/hristchurch
Passage
cQKVm
cQKbm
sp
kR
uin
f
Gate
House
&ride /ourt
g
T/&s
©&
L&
sp
g
&ank
u
cg
lto
ls
p
y
su
T/&s
STR’’T
su
''
s
QV
Vp
lto
lcp
c
P/
/itylThameslink
Station
cp
Pr
ior
yl/
ou
rt
Tun
ne
l
PILGRIMlSTR’’T
WarwicklPassage
cpp
Old
lSe
aco
allL
an
e
cp
©l
ee
tlP
lace
/itylThameslink
Station
c
PilgrimlStreet
cs
PH
/ondorlHouse
PH
PH
yy
c
Stonecutterl/ourt
Stl&ridenslHouse
cu
cQ
Qu
g
bcltolby
c
s
' b
/O
UR
T
s
c
b
gc
PH
PricelWaterhouselandl/oopers
HarplHouse
&ritannialHouse
W
,IT
HM
,NlS
TR’’T
ThelOld
StlPaulnslHouse
V
s
cs
Q
Q
cs
c
/hristchurchl/ourt
cpltolcu
y
Riverl/ourt
csp
ccp
ProcessionlHouse
uV
uu
'
su
'
sp
cpp
jef
’vangalist
House
cc
c
c to ss
'c
''
c to cQ
GR’’Nl,R&OUR
/OURT
'
s
©leetlPlace
House
c
'p
MinervalWalk
Que
en
lIs
ab
ellalW
ay
/athedral
/ourt
cltolcQ
'
b
u'ltoluu
c'p
Post
Monument
Posts
Warwickl/ourt
JuxonlHouse
P/s
PaternosterlSquare
Ro
se
lS
tre
et
WhitelHartlStreet
PaternosterlLane
s
Paternoster
Lodge
London
Stockl’xchange
cp
gb
s
u
cgcppp
u'sppp
cpp spp 'pp bpp
u'supp
cgcppp
cpp
spp
'pp
bpp
cgcupp
u'supp
bpp'ppsppcpp
u'sppp
cgcupp
bpp
'pp
spp
cpp
'Vltolu'
yc
Qg
yp
ys
ybltolgs
'V
cV sp
sbltolsQ
'g
sV Qc
QyltolQV
yp
yc
ys
y'
ybyuyQyy
V
g
y Q
u
cs'b
b
cs
cc
V
'
s
ca
cp
uQltolug
us
usa
up
bV
bg
cc
cs
ultolV
by
bb
b'
bp
bs
a
bs
cp
lto
lcu
Vp
Vs
cl
to
ly
sb su
Vl
to
lc
s
cb
cu
cQ
cy
bb
sg
sV 'p
'c 's
''
'b
'u
'Q 'y
'V
s
cpcltolccQ
cspltolcss
b
csy
cu
cQs
cuclcup
'u
u
b
cc
cp
bl
to
lV
spltols
g
sVltol's
s'
sc
'y
cbltolcg
ultolQ
'b
''
cQ
sl
to
lc
b
y
u
'c
uV
Qp
Qc
Qp
Qc
Qs
Q'
c
Qb
Qu
QQ
QyltolQV
clt
olu
y
Q
g
cyKQm
N’WG,T’lSTR’’T
Pa
ny
erl
,ll
ey
St
Paulns
Sta
/R
&ank
je
f
©O
ST’
RlL
,N’
Roselandl/rown
je
f
&Ps
je
f
&MlcyKbym
StlVedastns
/hurch
&a
nk
W
OOjlS
TR
’’T
GOLjSMITHlSTR’’T
je
f
PH
Mitrel/ourt
MILKlSTR’’T
RUSSI,lROW
PH
Und TRUMPlSTR’’T
Und
L,
WR
’N
/’
lL,
N’
&ank
&ank
&ank
PO
cbKum
PrudentlPassage
&ank
&ank IRO
NM
ON
G’
RlL
,N
’
&MlcuKbcmcuKcm
L&
/R
&udgelRow
STR’’T
Subway
PH
T/&
QU’
’N
lS
TR
’’
T
Und
/R
&Ps
je
f
PH
/WWelll/ourt
/ro
wnl
/t
&ank
©W
jef
©W
/W
Hone
ylLa
ne
PH
cQK'm
&MlcyKpgm
jef
je
f
Statue
&ank
Stl
Ma
ryY
leY&
ow
/h
urc
h
&owl
/hur
chya
rd
Grovelandl/t
/W
WilliamsonnslTavernkPHf
&o
wl
&e
lls
lH
ou
se
&ank
/R
W,
TLI
NG
jef
cbKVm
&ank
&R
’,
jlS
TR
’’
T
W,TLINGlSTR’’T
©ountain
©ountain
jef
&ank
L& Und
cyKbm
/H’,PSIj’&ank
cyK'm
cyKum
ksiteloff
PaternosterlRow
/hapter
House
&MlcyKsum
cyKcm
StlPaulnsl/hurchyard
&MlcgKssm
jl©n
cyKsm
Und
Statue
St
lP
au
lns
l/
at
he
dr
al
/ho
irl
Sc
ho
ol
Un
d
N’
W
l/
H,
NG
’
cuKQm
/,NNONlSTR’’T
©R
Ij
,Y
ST
R’
’T
jI
ST
,©
©l
L,
N’
&ank
je
f
Tower
/oachlPark
cuKVm
Se
rm
on
lLa
ne
c'Kym
GOjL
IM
,N
lS
TR
’’
T
/,RT’RlL,N’
&MlcQKssm
STlP,ULnSl/HUR/HY,RjcbKgm
T/&s
Information
Thel/harteredInsurance
Institute
Und
ThreelNunl/ourt
©ountain
,Lj’RM,
N&URY
&MlcbKycm
Memorial
jl©n
,Lj
’RM
,N&URY
Guild
halllLibra
ry
je
f
&Ps
jef
&Ps
GuildhallYard
W
ar
dl
&d
y
©W
P/P
&MlcQKpsm
Pond
L&
&ank
cuKbm
&ank
GR’SH,MlSTR’’T
cQKsm
WO
Oj
lST
R’
’T
LOV’lL,N’
cuKum
Tower
&M
lcQ
Kcs
m
PolicelStation
Pewterers
Hall
O,TlL,N’
StlMary
Staining
ST
,IN
ING
lL,
N’
jefPubliclGardens
Wax
/handlersnHall
Un
d
GUTT
’R
lL
,N
’
/,R’YlL,N’
cQKQm
&ank
STl
M
,RTI
NnS
lL
’lG
R,Nj
Hall
PH
jl©n
©nSj
LITTL’l&RIT,IN
Postmanns
Park
&S&P©W
,NG’LlSTR’’T
/hristl/hurch
Passage
cyK'm
Statue
Und
cyKsm T/&
©&
Hospital
bs
Guildhall
jef
/ourt
b
Q
Priestns
©W
cQc
cs'csb
c'bltolcby
''
sg
lto
l'p
c'
KI
NG
lS
TR
’’
T
uc
bQ
&ow
lLan
e
/O
UR
T
&MlcQKgsm
cQK
pm
/entre
k/ityloflLondonf
ub
ROM,Nl©ORT
ksiteloff
je
f
©W jef
jef
UndkLTf
/R
Wardl&dy
Saddlers
Tompter
The
cp
ROM
,NlW
,LL
’leanorl/ross kSiteloff
c
/TRIj
’R
KN
IGH
TKNIGHTRIj’RlST
&ritishlTelecom
/entre
Goldsmithsn
Hall
StlPaulnsl/athedral
/hurch
JewryYnextYGuildhall
/hurch
StlLawrence
/hurchyard
T/&s
T/&s
bb
lb
p
T/&s
P/s
gcltolgy
cs
u
&ank
c
T/&s
T/&s
T/&s
Guildhall
&uildings
/ourt
&ow
l/h
urc
hya
rd
bVltoluy
cp
c
c
sp
&ank
cQK'm
NO
&L’
lST
R’
’T
Stl,nne
andlStl,gnes/hurch
Wa
rdl
&d
y
Und
©W
cuKum
Stl&otolphlwithout
,ldersgatel/hurch
cp
NorthlGate
,Lj
’RSG,T’
STR
’’T
KIN
Gl’
jW
,RjlS
TR’’T
&M
lc
yK
by
m
NomuralHouse
T/Ps
L&
T/Ps
'
ss
PH
csVlcsg
c''lc'p
Vyltolcpp
bQltolus
c'
p
yg
Vp
g
cc
&ank
sltolQ
'p
QU’’NlVI/TORI,
/arterlLanelGardens
cgltolsp
StlMaryl,ldermary
T/&s
cu
Q'
'p
sg
cs
lto
lcb &o
wl
La
ne
&owl&ellslHouse
©estival
Gardens
WrenlHouse
&ank
Memorial
cc
cltolb
yu
Oldl/hange
c
/ourt
ypltolgp
cl
to
lu
gu
gp
cltolu
y
u
c'
cc
'
gc
c
'u
WatlinglHouse
''
sVltol'c
&ank
Qltolcs
cyltols'
bpltolbu
'sltol'Q
Qp
gu
cpp
,lderl/astle
Qu
cp
s
su
c
cp
s
je
f
Un
d
su
cp
c
cV
PickfordlHouse
cg
s
c
Paternoster
Square PaternosterlHouse
StlMartinnsl/ourt
T/&s
Qu
ee
nns
lH
ea
dl
Pa
ss
ag
e
/a
no
nl,lle
y
'p
slt
olb PH
Q
g
cp
cp
London
Stockl’xchange
cgpupp
u'cupp
Qpp ypp gpp Vpp
u'sppp
cgpupp
Qpp
ypp
gpp
Vpp
cgcppp
u'sppp
VppgppyppQpp
u'cupp
cgcppp
Vpp
gpp
ypp
Qpp
UPP’RlGROUNj
Riverl/ourt
&L
,/
K©
RI,
RS
RO,j
HOPTONlSTR’’T
©alconlPoint
RiverlThames
KingnslReach
&lack
friars
l&
ridge
ScantlinlPier
JO
HNl/
,RP’NT’RlS
TR’’T
TUjORlSTR’’T
KI
NG
S/
OT
’l
ST
R’
’T
W,T’RG,T’
&L,/
K©RI
,RSl
/T
&L
,/
Kl
©R
I,
RSl
L,
N’
&L,/K©RI,RSlP,SS,G’
&L,/K©RI,RS
UNj’RP,SS
&L,/
K©R
I,RS P,
SS
,G
’
PU
jj
L’
lj
O/
K
ST
l,N
jR
’W
nSl
HI
LL
WardrobelTerr
KNIGHTRIj’R
STR’’T
©aradayl&uilding
QU’’NlVI/TORI,lSTR’’T
/,S
TL
’l
&,
YN
,R
jlS
TR
’’
T
Me
rm
aid
lTh
ea
tre
PUjjL
’
jO
/K
UPP’RlTH,M’SlSTR’’T
/,STL’l&,YN,RjlSTR’’T
&aynard House
&’NN’TnSlHILL
MeanlHighlWater
Mud
Shingle
&MlVKgVm
PH
MHW
Shingle
ccKcm
©W
MudlandlShingle
PH
//LW&orol/onstmlGLl,slyl/onstlClL&l&dy
Sl
Gan
try
&MlcsKVVm
©W
//LW
csKpm
Un
d
ShingleMud
MeanlHighlWater
ksiteloff
Subway
VKum
/arlPark
Statue
gKbm
T/&
©&
©&
PH
jef
yKbm
UndergroundlRailway
Ward
l&dy
&ank
jl©n
,irlVent
jef
Sub
way
Subway
gKbm
T/&
&MlVKypm
VKbm
Statue
W
ar
dl&
dy
Un
d
je
f
MHWMud
Mud
PumplHouse
jolphin
©&
gK'm
MeanlHighlClMeanlLowlWater
QKsm
PO
cltolgy
Qb
ugltolQs
c to 'p
uQ
'ctobs
ub
b'touQ
uytoys
up
bg
ccp
to gu
us
c'u
cbQ
'c
's
cb
ga
cbg
cQu
cg
c
cyb
'p
lto
l'
b
cV
c
SM
c
UnileverlHouse
yKsm
PH
yKQm
PU
jj
L’
/hurchlof
Stl,ndrewY
byYtheYWardrobe
withlStl,nn
&lackfriars
,j
jL
’l
HI
LL
N’W&RIj
G’
VI/TORI,
jl©n
&lackfriarslStation
jO/K
SLSL
/itylandl/ountyloflthel/ityloflLondon
’M&
,NK
M’N
T
Subway
Stl
&e
ne
t
Me
tlW
els
h
/h
urc
h
MHW
WHIT’ LION
STR
’’T
HILL
PaulslWalk
sb
u
&lackfriars
Station
PH
cyV
cQylcQVlcyc
©& /ityloflLondon
School
&aynardnsl/astle
Playground
Tunnel
Tunnel
Tunnel
sp
kLTf
T/&s
Qp
u
PaulslWalk
©&
&anksidelGallery
SL
cbu
T/P
'
MermaidlHouse
s
y'togb
Hotel
Posts
Und
cQp
cgpupp
u'sppp
cpp spp 'pp bpp
u'supp
cgpupp
Qpp
ypp
gpp
Vpp
cgcppp
u'supp
bpp'ppsppcpp
u'sppp
cgcppp
Vpp
gpp
ypp
Qpp
bKQum
us
uc
bV
bKsm
&,NKSIj’
MeanlHighlWater
MudlandlShingle
'KVm
N’
W
lGLO
&’
lW
,L
K
&’,
Rl
G,Rj
’NS
sa
Groynes
csKQm
MudlandlShingle
Groyne
Mud
Southwark
&ridge
csKpm
Un
d
RiverlThames//LW
KingnslReach
Und
Wa
rdl&
dy
Groyne
MudlandlShingle
MeanlHighlWater je
f
Un
d
&’
LL
lW
H,
R©
lL,
N’
W
alb
roo
klW
ha
rf
je
f
yKsm
QU’
’N
lS
TR
’’
Tl
PL
,/
’
cpKum
Southwarkl&ridge
Stairs
Hall
QV
QgKu
je
f
&u
lllW
ha
rf
MudlandlShingle
Mud
MeanlHighlWater
QU
’’
NH
ITH
’
ST’
WlL
,N
’
HIGHlTIM&’RlSTR’’T
&rooknslWharf
Groyne
MudlandlShingle
TriglLane
Stairs
Groyne
Un
d
Slopinglmasonry
&’
NN
’T
nSl
HI
LL
cpKum
GOjL
IM
,N
lS
TR
’’
T
sc
L&
ccKQm
L,M&’THlHILL
QU’’NlVI/TORI,lSTR’’T
csKVm
jIST,©©lL,N’
&P
OL
jl©
ISH
ST
R’
’T
lHI
LL
ccs
ccp P/P
©R
Ij
,YlS
TR
’’T
cbKcm
UndergroundlRailway
&R’
,jl
STR
’’T
Wardl&dy
jef
g
Paintersn
Hall
HUGGINl/OURTHU
GG
INl
HIL
L
V
LIT
TL
’l
TRIN
ITY
lL,
N’
su
Und
G,
RL
I/
Kl
HI
LL
&P
&P
cbKpm
Subway
&P
GR’,TlSTlTHOM,S
,POSTL’
sg
sy
bs
bp
PHsg
sy
cu
u'
a
uca
ss
Qu
PH
Q'
Qc
/,NNONlSTR’’T
QVltoly'
yu
Qg
lto
ly
p
Templel/ourt
TO
W’
R
ROY
,L
cpKgm
/R
QU
’’
N
ST
R’
’T
T/&
/LO,KlL,N’
ss
sp
cV
&MlyKVbm
yK'm/OLL’G’lSTR’’T
jef©n
L&
SKINN’RS L,N’
b
sp
/itylandl/ountyloflthel/ityloflLondon
GR’,TlTRINITYlL,N’
cV
Qu
QQ
Qb
V
b
c
VKym
©&
StlJamesns
/hurch
StlMichaelkPaternosterfRoyall/hurch
Newcastle/ourt
The
oflStlNicholas
/olel,bbey
&orol/onstmGLl,slyl/onstlClL&l&dy
SunlightlWharf
G,
Rj
N’
RS
lL,
N’
Sir
JohnlLyon
House
Thames
Street
QueennslQuay
Qu
ee
ns
bri
dg
e
Ho
us
e
©&
UPP’RlTH,M’SlSTR’’T
©&
Stl&enetlMetropolitan
Welshl/hurch
cy
Tunnel
Tunnel
Twr
/hurch
ksiteloff
gbltolVb
c'KQm
Miniver
Place
ccKym
up
yy
yc&ank
&ank
/o
urt
'Q
/ityloflLondon
School
L&
/,STL’l&,YN,RjlSTR’’Tlkbelowf
&ank
QU’’NHITH’lW,Rj
sc
lto
ls
Q
&M
Posts
jo
by
c
Posts
Thamesl’xchange
LittlelShipl/lub
''
gu
&OOTHlL,N’
bp
s'
/O
LL’
G’
lHIL
L
c'
Q'
clt
ols
MansionlHouse
Station
c
c
&rackenlHouse
&uilding
Qg
/a
rd
inal
Gap
,l
ley
Pet
er
nslH
ill
PaulslWalk
©Y
’l
©O
OTl
L,
N’
Vin
tne
rsn
cp
Threel/raneslWalk
K’
NN
’T
TlW
H,
R©
lL,
N’
Qp
Qs
ug
spcltolssc 'pcltol'cV
bpcltolbcV upcltolucV QpcltolQcc
ypc
ThelGlobe
Theatre
Inigo
Jones
Theatre
RiversidelHouse ccKpm
&anksidelPier
Vintnersn
©iv
elK
ing
slH
ou
se
&R
OK
’N
lWH
,R
©
cp
lto
lcs
LITTL’lTRINITYlL,N’
WhittingtonlGarden
Qs
lto
lQ
'
Qc
Vlto
lcp
&lock
NorfolklHouse
VintnerslPlace
cpcltolccg
ys
/arlPark
k&elowf
Tha
mes
lHo
use
Middle
&lock
Riverl&lock
&roken
Wharf
House
cltolcc
TRIGlL,N’
StlMary
Somerset
Garden
SenatorlHouse
Gardens
PH
bbltolbQ
Guildl/hurch
/ollegelofl,rms
/leary
Qb
T/&s
Nikko
House
Kn
igh
t
Rid
er
Ho
use
/o
urt
csg
Posts
/T
RI
j’
R
KN
IG
HT
/ourt
Oldl/hange
Qp
Qy
©&
cltolc'Q
GlobelView
cp
PH
MudlandlShingle
jolphin
jolphin
Millenniuml&ridgelk©&f
Travellingl/rane
Posts
&enbowlHouse
sb
s
Wa
rdl&
dy
Ward&dy
Posts PsPs
Ps Posts Ps
Vu 'p
clt
olV
Q
b
ThelSite
u'scppFcgpgpp
u'scppFcgcppp
2
Fig 1  Site location
p cppm
ThislmaplislreproducedlfromlOrdnancelSurveylmateriallwithlthelpermissionloflOrdnancel
SurveylonlbehalfloflthelcontrollerloflHerlMajesty’slStationerylOfficel©l/rownlcopyrightlsppuKl
,lllrightslreservedKlUnauthorisedlreproductionlinfringesl/rownlcopyrightlandlmaylleadltol
prosecutionlorlcivillproceedingsKl/orporationloflLondonlcppps'sb'lsppuK
NN
/ityloflLondon
thelsite
NN
pllllllllllllllllllllllllllcpkm
R:\Project\city\1091\fig01
[SYO03]©Evaluation©Report©©MoLAS©2005©

### Page 9

[SYO03] Evaluation Report ! MoLAS  
 
1.2 Planning and legislative framework 
The legislative and planning framework in which the archaeological exercise took 
place was summarised in the Method Statement which formed the project design for 
the evaluation (see Section 1.2, Aitken, 2005).  
1.3 Planning background 
The work was carried out pursuant to a condition of planning consent. The proposed 
redevelopment involves the conversion of the St. Mary Somerset Tower for 
residential use, and extension of the tower to the north.  The works described in this 
document include the excavation of two trial pits to the north of the tower. A borehole 
to the east of the tower and an internal trial pit within the tower were also monitored 
(see Fig 2 for trench locations).  
 
These works provided information on the level and nature of the present foundations, 
earlier church foundations, the extent of horizontal truncation and the nature and 
depth of surviving archaeological deposits.  
1.4 Origin and scope of the report 
This report was commissioned by Boyarsky Murphy Architects and produced by the 
Museum of London Archaeology Service (MoLAS). The report has been prepared 
within the terms of the relevant Standard specified by the Institute of Field 
Archaeologists (IFA, 2001). 
 
Field evaluation, and the Evaluation report which comments on the results of that 
exercise, are defined in the most recent English Heritage guidelines (English Heritage, 
1998) as intended to provide information about the archaeological resource in order to 
contribute to the: 
 
" formulation of a strategy for the preservation or management of those remains; 
and/or 
" formulation of an appropriate response or mitigation strategy to planning 
applications or other proposals which may adversely affect such archaeological 
remains, or enhance them; and/or 
" formulation of a proposal for further archaeological investigations within a 
programme of research 
1.5 Aims and objectives 
All research is undertaken within the priorities established in the Museum of 
London’s A research framework for London Archaeology, 2002 
 
The following research aims and objectives were established in the Method Statement 
for the evaluation (Section 2.2):  
 
3 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 10

[SYO03] Evaluation Report ! MoLAS  
 
" What is the nature and level of natural topography? 
 
" What are the earliest deposits identified?  
 
" Is there any evidence of Roman structures or associated layers? 
 
" Do any Roman deposits remain on site? 
 
" Are there any remains, structural or otherwise, associated with the Medieval 
St. Mary Somerset Church (founded c.1153 and demolished during the 1666 
Fire of London)?  
 
" Are there any remains of the foundations or floor levels of the St. Mary 
Somerset Church building as rebuilt by Wren (and demolished in 1872)? 
 
" What is the nature and depth of the foundations of the Tower of St Mary 
Somerset? 
 
" What is the nature and depth of floor levels within the Tower of St. Mary 
Somerset? 
 
" Are there any in situ human remains present on site? If so are they a part of the 
churchyard cemetery or are they located within the Tower? 
 
" Are there any disarticulated remains present on site? If so, do they form part of 
a cemetery soil? Or have they been re-deposited within the later deposits 
associated with either the clearance and demolition of the church and 
churchyard, or the 1960’s redevelopment of the area? 
 
" Is there any evidence of post-medieval warehouses surviving on site? If so, 
any remaining walls retain some of the earlier masonry from the church? 
 
" What are the latest deposits identified?  
 
4 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 11

[SYO03] Evaluation Report ! MoLAS  
 
2 Topographical and historical background 
Information on the natural geology, archaeological and historical background of the 
site has been set out in the Method Statement (Aitken, 2005). A brief summary of this 
information is detailed below. 
2.1 Topography 
The estimated level of the surface of the natural gravel is c 4.5m OD to the north of St 
Mary Somerset. It falls away rapidly to the south towards the river.  
2.1.1  Roman masonry structures 
Excavations in the area immediately around the site have revealed a series of 
monumental Roman masonry structures occupying the gravel terraces leading down 
to the river.  These include the Huggin Hill Baths complex immediately to the east, 
part of which lies beneath Senator House. This was constructed in the later 1st 
century, and was extended several times prior to being demolished, possibly before 
the end of the 2nd century. To the north-west, under the site of the Salvation Army 
building, a series of Roman foundations were found.  These were probably part of a 
temple precinct constructed on earlier rammed chalk terraces. Beyond that at Peter’s 
Hill, a series of structures which may include the unfinished palace of the imperial 
pretender, Allectus, were begun and abandoned in the last decade of the 3rd century. 
Immediately south of these was the riverside wall, built in c AD 270. 
 
A watching brief conducted at the site in 2003 revealed evidence of a Roman building 
and floor layers (Soakaway B, Fig 2) at c.4.63m OD (2.6m below the current ground 
surface). The remains included a burnt timber beam/baseplate and brickearth sills. 
2.2  The Medieval street plan and churches 
 
Many of the streets in the area probably had their origins in the late-Saxon period, but 
are not recorded in any surviving documentary sources until later. The medieval street 
plan was retained after the 1666 Great Fire, but was lost following post-war 
redevelopment. 
 
Old Fish Street Hill (Oldefisshestretlone by 1345; Baggardeslane in 1274) formerly 
cut through the site. On the west side of Old Fish Street Hill, to the north-west of the 
site, was the church and churchyard of St Mary Mounthaw first recorded in 1150 
which may originally have been a private chapel of the Mounthaut family from 
Norfolk. A large messuage, originally owned by the Mounthauts, was adjacent to the 
church, perhaps on the north side.  
 
To the north-east of the site, and opposite St Mary Mounthaw, was the Old 
Fishmongers’ Hall. This was in use by the Fishmongers’ Company by 1398–9, but 
was abandoned in favour of the present site near London Bridge in 1503–4. Passing 
5 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 12

[SYO03] Evaluation Report ! MoLAS  
the north side of the Hall was Finimore Lane (Finamoureslane in 1316, also known as 
Five foote lane in the 16th century, present Fye Foot Lane). Thames Street to the 
south was probably in place in the late 11th or early 12th century as the main riparian 
road stretching across the City on the line of the collapsed late Roman riverside wall.  
 
The earliest references to St Mary Somerset are in the 12th century. Somerset is 
probably derived from Somershithe, a nearby wharf (Weinreb and Hibbert 1995, 765). 
The church was founded c.1153 and demolished following the 1666 Fire of London. 
It is unknown if any remains from the medieval build of the church remain on site. 
2.3  Post-medieval  
 
The buildings in the Lambeth Hill and surrounding area were destroyed during the 
Great Fire of 1666. The nearby church of St Mary Mounthaw was not rebuilt after the 
fire, instead its parish was amalgamated with St. Mary Somerset. 
  
St. Mary Somerset church was rebuilt by Wren from 1686–95 (see Fig 3). It consisted 
of an east-west aligned church with tower built at the south-eastern end, and a burial 
ground contained within the surrounding church yard. 
 
The main body of the church of St Mary Somerset was demolished as a result of the 
Union of Benefices Act in 1872 following deconsecration in 1867. The tower was 
preserved as a memento and remains, free-standing today. Remnants of the nave of 
the church lie beneath the present Lambeth Hill, with the north wall possibly under 
the pavement adjoining Walker House. Previous archaeological investigations 
(MoLAS 2003) indicate that the rubble from the demolition of the church is present to 
a depth of c. 1.60 m. Disarticulated human remains were retrieved from the rubble in 
the area of proposed trial trench excavation (Drain Run 1 Fig 2) indicating that some 
cemetery clearance occurred at this time.  
 
The church was replaced by warehouses which appear to follow its wall lines, and 
these may even have retained some of the earlier masonry from the church. The 
remains of the footings of the southern wall and where the body of the church 
connected with the tower may were proven to remain in the northern section of the 
development area (see Fig 3). The Tower of St Mary Somerset was restored in 1956 
following wartime damage. 
 
Changes to the immediate area since the Second World War such as the construction 
of the Salvation Army Headquarters, Walker House, and Dominant House (now all 
redeveloped), led to the realignment of streets to the south of Queen Victoria Street. 
Lambeth Hill was moved from further east to curve around Walker House, although 
Fye Foot Lane remained on its original site as an elevated walkway leading to a 
footbridge across Thames Street. The latter was widened on the south side with the 
addition of an extra carriageway, and now passes beneath several buildings 
constructed across the road in the 1980s, including the City of London Boys’ School. 
6 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 13

TP2TP1
TP3
extent of
tower
foundation
foundation
BH1
Victorian
wall
extent of disturbed
foundation
TP4
7
Fig 2  Areas of evaluation and archaeological features
0 5m
NN
R:\Project\city\1091\fig02
[SYO03]pEvaluationpReportp©MoLASp2005p

### Page 14

N
8
Fig 3  The Wren tower of St Mary Somerset
R:\Project\city\1091\fig03
[SYO03]©Evaluation©Report©©M
oLAS©2005

### Page 15

[SYO03] Evaluation Report ! MoLAS  
 
3 The evaluation 
3.1 Methodology 
All archaeological excavation and monitoring during the evaluation was carried out in 
accordance with the preceding Method Statement (Aitken, 2005), and the MoLAS 
Archaeological Site Manual (MoLAS, 1994). 
 
Four evaluation pits were excavated on the site. Two along the northern perimeter of 
the site to establish the depth of a retaining wall and foundations of the tower. One 
within the tower to establish floor depth and truncation levels and a further test pit 
was excavated to the east of the tower to check for services before a borehole and to 
establish the depth of foundations for the tower. 
 
The slab/ground was broken out and cleared by contractors under MoLAS 
supervision. Pits were excavated by hand by the contractors, and monitored by a 
member of staff from MoLAS. 
 
The locations of evaluation trial pits were recorded by offsetting from adjacent 
standing walls and plotted on the OS grid.  
 
A written and drawn record of all archaeological deposits encountered was made in 
accordance with the principles set out in the MoLAS site recording manual (MoLAS, 
1994). Levels were calculated by hand measuring down from ground level. 
 
The site has produced: 1 trench location plan; 4 trench sheets; 1 section drawing and 2 
photographs.  
 
The site records can be found under the site code SYO03 in the Museum of London 
archive. 
9 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 16

[SYO03] Evaluation Report ! MoLAS  
 
3.2 Results of the evaluation 
For pit locations see Fig 2.  
 
3.2.1 Evaluation pit 1 
Location  North of the tower (west end) 
Dimensions 1.53m (extension to 2.13m along northern 
edge) x 1.55m (extension measuring 
0.58m) x 1.90-2.00m depth   
Modern ground level/top of slab c7.30m OD 
Base of modern fill/slab c6.60m OD 
Depth of archaeological deposits seen 1.20m 
Level of base of deposits observed c5.40m OD 
Natural observed N/A 
 
A test pit was excavated at the western extent of the northern frontage of the tower 
measuring 1.53m x 1.55m x 1.90m. At 0.30m below pavement level an east–west 
aligned drain was revealed hindering deeper excavation over the majority of the area. 
Excavation continued in the northern area of the trial pit where a concrete foundation 
was observed in the north-east area. Further excavation continued in the north-west in 
an area measuring 0.56m x 0.42m. The foundation for the modern retaining wall on 
the northern limit of the pit continued to a depth of 1.5m and consisted of loose 
concrete and mortar rubble. A dark greyish brown clay silt backfill containing 
frequent CBM, occasional pottery, occasional chalk fragments, occasional charcoal, 
occasional building material and moderate amounts of disarticulated human bone was 
recorded to a depth of 1.90m below ground level. The building material appeared to 
be of mainly 19th century date. The bones had presumably been gathered from graves 
destroyed during construction of the warehouses, and then dumped rather than 
reburied in new graves. The bones were collected and bagged for reburial within the 
site limits. 
 
Below this deposit chalk blocks were revealed set into a sandy silt, orangey yellow 
mortar, containing charcoal flecks and chalk flecks. The size of the area being 
excavated hindered more detailed examination and it was decided to halt at this point. 
The feature appeared to be structural and is interpreted as the possible remains of a 
truncated foundation of unknown date.  
 
The trial pit was later extended eastwards in order to establish the extent of the 
concrete found in the north-eastern part of the pit. The concrete was recorded as 
measuring 0.35m x 0.58m x 2.00m and appeared to be on a north-south alignment, 
continuing beyond the limits of excavation in both these directions. East of the 
concrete, a similar backfill material to that found to the west was recorded to a depth 
of 2.00m at which point a chalk foundation set into a similar material as that found to 
the west was revealed. To the east end of the extended pit the chalk and ragstone 
feature was set into a mid brown clay silt and contained ragstone blocks, one of which 
measured 0.27m x 0.24m x 0.10m. East of the ragstone block the feature had been 
10 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 17

[SYO03] Evaluation Report ! MoLAS  
truncated by an east-west aligned yellow stock brick wall which continued to a depth 
of at least 2.20m. The wall is of late-Victorian date and is probably part of  a 
basement, associated with a warehouse. The earlier foundation appeared to continue 
beneath this brick wall.  Excavation in this part of the pit was halted at this point. 
Ground slabs were removed to the east revealing that the brick wall continued in an 
easterly direction for 1.98m, east of which lay modern concrete rubble. 
 
3.2.2 Evaluation pit 2 
Location  North of the tower (east end) 
Dimensions 1.00m x 1.20m x 1m depth   
Modern ground level/top of slab c7.30m OD 
Base of modern fill/slab c7.025m OD 
Depth of archaeological deposits seen  2.80m 
Level of base of deposits observed  c4.50m OD 
Natural observed  N/A 
 
A test pit was excavated at the eastern end of the north frontage of the tower in order 
to establish the depth of foundations for the tower. Demolition material was revealed 
beneath the modern slab and make up at 0.25m below pavement level. The sandy silt 
contained frequent CBM, including yellow stock brick, occasional clay pipe, 
occasional pottery, occasional metal, frequent disarticulated human bone and 
occasional animal bone. The deposit continued to a depth of 1.60m below pavement 
level and is interpreted as material associated with the 19th century demolition of the 
church.  
 
At 1.60m below ground level a dark grey clay silt contained frequent disarticulated 
human bone, occasional animal bone, occasional CBM, occasional pottery and 
occasional clay pipe. This is thought to represent backfill of the foundation trench for 
the tower during the 17th century. 
 
The foundation for the tower was revealed in the southern section of the trial pit and 
seen to step out to the north at intervals. Excavation of the pit was temporarily halted 
at 2.80m in order to extend the pit in order to establish the most northern extent of the 
foundation. 
 
Due to the confined nature of the area to the north of the church and the extent to 
which the foundation stepped out northwards, the base of the foundation was located 
using a torch and pole pointed down a narrow part of the pit.  
 
At its greatest extent the foundation of the tower stepped out 1.00m north of the plinth 
at the base of tower and 3.95m below pavement level. 
11 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 18

[SYO03] Evaluation Report ! MoLAS  
 
3.2.3 Evaluation pit 3 
Location  Within the tower 
Dimensions 1.00m x 1.20m x 1m depth   
Modern ground level/top of slab c7.30m OD 
Base of modern fill/slab c7.025m OD 
Depth of archaeological deposits seen  0.725m 
Level of base of deposits observed  c6.30m OD 
Natural observed  N/A 
 
A test pit was excavated inside the tower in order to establish the depth of floor slabs 
and any associated material. Removal of the floorboards measuring 0.025m in depth 
revealed concrete slabs measuring 0.42m in width divided by wooden joists 
measuring 0.05m in width. These slabs were broken out by jackhammer and a 0.15m 
void was recorded below.  
 
An early modern manhole lay on the western extent of the test pit and associated 
truncation was revealed below the floor slabs in the southern and western part of the 
test pit. Associated concrete was broken out and all associated material removed to 
reveal the depth of truncation.  
 
Layers truncated by this material to the north consisted of a loose dump material 
containing frequent CBM and moderate amounts of clay pipe, suggesting the dump 
was associated with the 17th century rebuild of the church.  
 
Below the cut for a drain (0.75m below floor level) a ragstone, chalk and flint 
foundation was revealed (Fig 4). Dump material to the north was subsequently 
removed in order to establish the nature and extent of this foundation material. 
Excavation revealed the feature lay on a roughly east-west alignment. The largest 
blocks were of unfaced chalk, measuring c 0.30 x 0.30 x 0.15m and smaller ragstone 
blocks of 0.20m x 0.15m x 0.10m were mainly unfaced, although two were noted as 
being faced on at least two sides. There were also occasional flint nodules within the 
structure. 
 
The foundation appeared to have been heavily disturbed and was in a fragile state, 
probably due to construction of the 19th century drain above and possibly also to the 
earlier activity associated with dumps to the north. The feature was not dated and no 
excavation of the material took place. No cut was evident and the observed remains 
may represent a partially or completely collapsed, or redeposited feature. However the 
extent of any disturbance could only be confirmed by further excavation of the 
surrounding deposits. The alignment of the feature suggests it may represent remains 
of the original 12th century church. 
12 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 19

[SYO03] Evaluation Report ! MoLAS  
 
3.2.4 Evaluation pit 4 
Location  East of tower 
Dimensions 0.40m x 0.50m x 1.40m depth  (services 
pit) 
Modern ground level/top of slab c7.30m OD 
Base of modern fill/slab c7.05m OD 
Depth of archaeological deposits seen 1.15m 
Level of base of deposits observed c5.90m OD 
Natural observed  N/A 
 
A test pit was excavated to the east of the tower in order to check for services before 
drilling for a borehole. 
 
Removal of the modern slab and associated make up of 0.25m depth revealed 
demolition material in a greyish brown sandy silt matrix containing frequent CBM 
and occasional disarticulated human bone. The deposit continued to the limit of 
excavation at 1.40m. The material was dumped against an east–west aligned stone 
foundation which ran across the northern part of the pit. The foundation consisted of 
large ragstone and chalk blocks of c 0.25m width and height and occasional flint 
nodules. The feature was observed to a depth of 1.40m and continued beyond the limit 
of excavation. 
 
The foundation aligns with earlier drawings of the south wall of the church (see Fig 3) 
and confirms that masonry survives just below the modern made ground. 
 
 
3.2.5 Borehole 1 
Location  East of tower, within test pit A 
Dimensions 0.15m diameter 
Modern ground level/top of slab c7.30m OD 
Base of modern fill/slab c7.05m OD 
Depth of archaeological deposits seen 4.75m 
Level of base of deposits observed c2.30m OD 
Natural observed  c2.30m OD 
  
A borehole was drilled within test pit 4 to the east of the tower. The position of the 
borehole was moved to the south east corner of test pit 4 in order to avoid the east-
west foundation observed in the test pit and any potential foundation stepping out 
eastwards from the tower. 
 
Between 1.40m and 2.50m a dark greyish brown sandy silt deposit containing 
moderate CBM, moderate morter, occasional chalk flecks and very occasional bone 
was recorded. Between 2.50m and 3.70m a brownish grey, sandy silt contained 
moderate CBM, occasional bone and occasional chalk chips. At 3.75m chips of 
ragstone and chalk were recorded to 4.00m. A grey clay silt containing moderate 
13 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 20

[SYO03] Evaluation Report ! MoLAS  
CBM flecks continued below to a depth of c5.00m at which point lay a deposit of silty 
gravel c 0.30m deep. Natural London clay was revealed below.  
 
3.2.6 Reburial of disarticulated human bone 
The disarticulated human bone recovered from the excavation of the drain runs and 
soakways has been labelled and reburied on site, in accordance with the Home Office 
Burial Licence. The location of the reburial was within testpit 3.   
14 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 21

14
Fig 4  Foundation in test pit 3 looking south-east
R:\Project\city\1091\fig04
[SYO03]pEvaluationpReportp©M
oLASp2005

### Page 22

[SYO03] Evaluation Report ! MoLAS  
 
3.3 Assessment of the evaluation  
GLAAS guidelines (English Heritage, 1998) require an assessment of the success of 
the evaluation ‘in order to illustrate what level of confidence can be placed on the 
information which will provide the basis of the mitigation strategy’.  
 
It is suggested here that the evaluation pits were of sufficient quantity to provide a 
representative sample of the expected archaeological survival on site in respect of the 
planning consent. 
 
The evaluation demonstrated the presence of archaeological deposits/features in all 
areas of the site. The following represents an archaeological summary of the 
archaeological deposition encountered.  
 
 
3.3.1 Period 1: Natural ground 
Natural ground was encountered in Borehole 1 at approximately 5.00m below ground 
level (c 2.30m OD) in the form of a silty gravel deposit. The gravel was no more than 
0.30m deep and lay over natural London clay. During excavations by the Guildhall 
Museum in 1961 the base of gravel was recorded at a similar height of 2.44m OD to 
the east of Lambeth Hill. 
3.3.2 Period 2: Undated 
A chalk and ragstone feature was revealed at the base of pit 1 at depths of between 
1.90m and 2.00m. The masonry was set into a creamy yellow sandy mortar or cement 
throughout the feature, apart from the most easterly area revealed. Here, a ragstone 
block was set into a brown clay silt, however the feature was truncated at this point by 
a yellow stock brick wall and the change in material may represent disturbance 
relating to this truncation. 
 
No dating evidence was recovered as excavation halted at the top level of the feature. 
As only a narrow east-west area of the feature was uncovered it is not possible to say 
with any certainty whether this feature was part of a foundation or other deposit. It is 
possible that it relates to earlier construction of the church. There is a further 
possibility that this relates to structures of the Roman period found to the west of the 
site at the Salvation Army Headquarters (GM91) and Sunlight Wharf (SUN86). 
 
During excavation of a pit within the tower a disturbed ragstone, chalk and flint 
foundation was revealed (Fig 4). The foundation lay on a roughly east-west 
alignment. The largest blocks were of unfaced chalk, measuring c 0.30 x 0.30 x 0.15m 
and smaller ragstone blocks of 0.20m x 0.15m x 0.10m were mainly unfaced, 
although two were noted as being faced on at least two sides. There were also 
occasional flint nodules within the structure. 
 
16 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 23

[SYO03] Evaluation Report ! MoLAS  
The foundation appeared to have been heavily disturbed and was in a fragile state, 
probably due to construction of the 19th century drain above and possibly also to the 
earlier activity associated with dumps to the north. The feature was not dated and no 
excavation of the material took place. No cut was evident and the observed remains 
may represent a partially or completely collapsed, or redeposited feature. However the 
extent of any disturbance could only be confirmed by further excavation of the 
surrounding deposits. The alignment of the feature suggests it may represent remains 
of the original 12th century church which is known to have existed on this site. 
 
3.3.3 Period 3: St Mary Somerset Church, 17th century 
During excavation of test pit 4, an east–west aligned stone foundation which ran 
across the northern part of the pit was observed. The foundation consisted of large 
ragstone and chalk blocks of c 0.25m width and height and occasional flint nodules. 
The feature was observed to a depth of 1.40m and continued beneath the limit of 
excavation. 
 
The foundation aligns with earlier drawings of the south wall of the church (see Fig 3) 
and confirms that masonry survives just below the modern ground. 
 
The foundation for the tower was revealed in the southern section of pit 2 and steps 
out to the north at intervals. The structure consisted of large ragstone blocks with 
occasional layers of tile between the courses. At its greatest extent the foundation of 
the tower stepped out 1.05m north of the plinth at the base of tower and 3.95m below 
pavement level. 
 
17 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 24

[SYO03] Evaluation Report ! MoLAS  
 
4 Archaeological potential 
4.1 Realisation of original research aims 
  
" What is the nature and level of natural topography? 
Truncated natural sandy gravels were recorded in the borehole to the east of 
the tower at c 5.00m below ground level (c 2.30m OD) 
 
" What are the earliest deposits identified?  
The earliest deposits identified were a chalk and ragstone feature revealed at 
the base of pit 1 at depths of between 1.90m and 2.00m. The masonry was set 
into a creamy yellow sandy mortar or cement throughout the feature, apart 
from the most easterly area revealed. Here, a ragstone block was set into a 
brown clay silt, however the feature was truncated at this point by a yellow 
stock brick wall and the change in material may represent disturbance 
relating to this truncation. 
 
No dating evidence was recovered as excavation halted at the top level of the 
feature. As only a narrow east-west area of the feature was uncovered it is not 
possible to say with any certainty whether this feature was part of a 
foundation or other deposit. It is possible that it relates to earlier construction 
of the church. There is a further possibility that this relates to structures of the 
Roman period found to the west of the site at the Salvation Army 
Headquarters (GM91) and Sunlight Wharf (SUN86). 
 
During excavation of a pit within the tower a disturbed ragstone, chalk and 
flint foundation was revealed (Fig 4). The foundation lay on a roughly east-
west alignment. The largest blocks were of unfaced chalk, measuring c 0.30 x 
0.30 x 0.15m and smaller ragstone blocks of 0.20m x 0.15m x 0.10m were 
mainly unfaced, although two were noted as being faced on at least two sides. 
There were also occasional flint nodules within the structure. 
 
The foundation appeared to have been heavily disturbed and was in a fragile 
state, probably due to activity related to the 19th century drain above and 
possibly also to the earlier activity associated with dumps to the north. The 
feature was not dated and no excavation of the material took place. No cut 
was evident and the observed remains may represent a partially or completely 
collapsed, or redeposited feature. The alignment of the feature suggests it may 
represent remains of the original 12th century church which is known to have 
existed on this site. 
 
" Is there any evidence of Roman structures or associated layers? 
There was no evidence dated to the Roman period, however it is possible that 
the chalk and ragstone feature revealed at the base of pit 1 could date to the 
Roman period. 
18 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 25

[SYO03] Evaluation Report ! MoLAS  
 
" Do any Roman deposits remain on site? 
No deposits observed were dated to the Roman period. 
 
" Are there any remains, structural or otherwise, associated with the Medieval 
St. Mary Somerset Church (founded c.1153 and demolished during the 1666 
Fire of London)?  
A ragstone, chalk and flint foundation was recorded in the southern part of 
TP3 within the tower. The foundation lay on a roughly east-west alignment. 
The largest blocks were of unfaced chalk measuring 0.30 x 0.30 x 0.15m and 
smaller ragstone blocks of 0.20m  x 0.15m x 0.10m and were mainly unfaced, 
although two were noted as being faced on at least two sides. There were also 
occasional flint nodules within the structure. 
 
The foundation appeared to have been heavily disturbed and was in a fragile 
state, probably due to activity related to the 19th century drain above and 
possibly also to the earlier activity associated with dumps to the north. The 
feature was not dated and no excavation of the material took place. No cut 
was evident and the observed remains may represent a partially or completely 
collapsed, or redeposited feature. However the extent of any disturbance can 
only be confirmed by further excavation of the surrounding deposits. The 
alignment of the feature suggests it may represent remains, possibly the 
foundation of the south wall, of the original 12th century church which is 
known to have existed on this site. 
 
" Are there any remains of the foundations or floor levels of the St. Mary 
Somerset Church building as rebuilt by Wren (and demolished in 1872)? 
During excavation of a service test pit for borehole 1, at 0.25m below ground 
level, a substantial ragstone foundation was recorded in the north section 
aligned east-west. The foundation continued down beyond the limit of 
excavation at 1.40m below ground level and its nature and position suggests 
that it is the foundation for the south wall of St Mary Somerset Church 
building as built by Wren. 
 
" What is the nature and depth of the foundations of the Tower of St Mary 
Somerset? 
The foundation for the tower was revealed in the southern section of pit 2 and 
seen to step out to the north at intervals. The structure consisted of large 
ragstone blocks with occasional layers of tile between the courses. At its 
greatest extent the foundation of the tower stepped out 1.05m north of the 
plinth at the base of tower and 3.95m below pavement level. 
 
" What is the nature and depth of floor levels within the Tower of St. Mary 
Somerset? 
Floorboards measuring 0.025m in depth revealed concrete slabs measuring  
0.42m in width divided by wooden joists measuring 0.05m in width. These 
slabs were broken out by jackhammer and a 0.15m void was recorded below.  
 
19 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 26

[SYO03] Evaluation Report ! MoLAS  
" Are there any in situ human remains present on site? If so are they a part of the 
churchyard cemetery or are they located within the Tower? 
No in situ human remains were observed during the evaluation. 
 
" Are there any disarticulated remains present on site? If so, do they form part of 
a cemetery soil? Or have they been re-deposited within the later deposits 
associated with either the clearance and demolition of the church and 
churchyard, or the 1960’s redevelopment of the area? 
Disarticulated human remains were found within pit 1 and during excavation 
of the service test pit for BH1. In both instances the remains were found within 
deposits associated with the clearance and demolition of the churchyard. 
 
Further disarticulated human remains were recorded in two deposits in pit 2. 
The latest represented 19th century disturbance relating to the clearance of 
the demolition of the church. The earlier deposit may have represented 
material disturbed during the 17th century and used as backfill for the 
foundation trench of the tower. 
 
" Is there any evidence of post-medieval warehouses surviving on site? If so, 
any remaining walls retain some of the earlier masonry from the church? 
A yellow stock brick wall was observed in pit 1 aligned east-west, 0.30m 
below ground level and is interpreted as a basement wall of the post medieval 
warehouses which housed the site.  The wall continued 2.00m below ground 
level and truncated an earlier east-west aligned feature which appeared to 
continue beneath the brick wall. 
 
" What are the latest deposits identified?  
The latest deposits identified were 19th century demolition dumps relating to 
the demolition and clearance of the church during this period. The deposits 
varied in depth from 1.6m to 2.00m below ground level. 
4.2 General discussion of potential  
The evaluation has shown that the potential for survival of ancient ground surfaces 
(horizontal archaeological stratification) on the site is low. There is a higher potential 
for survival of cut features. However such survival is likely to be extremely limited in 
certain areas because of truncation by 19th century warehouses. The average depth of 
archaeological deposits where they do survive is likely to be 1.50m below ground 
level.  
4.3 Significance 
Whilst the archaeological remains are undoubtedly of local significance there is 
nothing to suggest that they are of regional or national importance. 
20 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 27

[SYO03] Evaluation Report ! MoLAS  
 
5 Assessment by EH criteria  
 
The recommendations of the GLAAS 1998 guidelines on Evaluation reports suggest 
that there should be: 
 
‘Assessment of results against original expectations (using criteria for assessing 
national importance of period, relative completeness, condition, rarity and group 
value) ......’  (Guidance Paper V, 4 7) 
 
A set of guide lines was published by the Department of the Environment with criteria 
by which to measure the importance of individual monuments for possible 
Scheduling. These criteria are as follows: Period; Rarity; Documentation; 
Survival/Condition; Fragility/Vulnerability; Diversity; and Potential. The guide lines 
stresses that ‘these criteria should not...be regarded as definitive; rather they are 
indicators which contribute to a wider judgement based on the individual 
circumstances of a case’.1
 
In the following passages the potential archaeological survival described in the initial 
Assessment document and Section 3.2 above will be assessed against these criteria.  
 
Criterion 1: period 
The archaeological deposits  appear to span the medieval and post-medieval periods. 
 
Criterion 2: rarity 
There is nothing to suggest that any of the likely archaeological deposits are rare 
either in a national or regional context. 
 
Criterion 3: documentation 
There are no surviving documentary records for remains in the area from the Roman 
period. Whilst there may be considerable contemporary documentation for the later 
medieval period from c 1300 on, the truncated and fragmentary nature of 
archaeological remains from this period will render most of this information unusable/ 
it is unlikely that any of this will be specific enough to relate to individual features. 
Documentation for the post medieval period is more conclusive and evidence 
recording the layout and position of the 17th century church as built by Wren has 
helped to identify foundations recorded during the evaluation.  
 
Criterion 4: group value  
The stone foundations appear to relate to either the medieval or post-medieval church. 
 
Criterion 5: survival/condition 
Results above have demonstrated that archaeological remains will be horizontally 
truncated to fairly consistent levels along the northern frontage of the tower. 19th 
                                                 
1 Annex 4, DOE, Planning and Policy Guidance 16, (1990). For detailed definition of the criteria see that 
document. Reference has also been made to Darvill, Saunders & Startin, (1987); and McGill, (1995) 
21 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 28

[SYO03] Evaluation Report ! MoLAS  
century activity has removed archaeological deposits to between 1.65m and 2.00m in 
this area.  
 
Archaeological remains appear to survive to a higher level within the tower where 
less disturbance has occurred. 17th century deposits may survive beneath the current 
floor level with isolated areas of 19th century truncation.  
 
Criterion 6: fragility 
Experience from other sites has shown that isolated and exposed blocks of 
stratigraphy can be vulnerable to damage during construction work. The foundation 
recorded in test pit 3 was in a disturbed and fragile state and further work in the 
surrounding area may cause more damage. 
 
Criterion 7: diversity 
Clearly, taken as a whole, the archaeological deposits which are likely to be found in 
the site represent a group of archaeological remains of all types and periods of 
medieval and post medieval. There is no reason to suggest that the diversity per se has 
any particular value which ought to be protected.  
 
Criterion 8: potential 
The evaluation has shown that there is the potential for remains of the original 12th 
century church to remain in a truncated form. The position of this church is not 
currently known with any certainty and further works may confirm the location, 
alignment and date of the former church. 
 
 
22 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 29

[SYO03] Evaluation Report ! MoLAS  
 
6 Proposed development impact and recommendations 
The proposed redevelopment involves conversion of the St Mary Somerset Tower for 
residential use, including extension of the tower to the north. The impact of this on the 
surviving archaeological deposits will be to remove all such remains to the new 
formation levels. Mini piles are also proposed along the northern frontage of the 
tower which will remove all archaeological deposits in these localised areas. 
 
The assessment above (Section 5) does not suggest that preservation in situ would be 
the only appropriate mitigation strategy. MoLAS considers that the remaining 
archaeological deposits should be recorded and excavated in advance of any further 
ground reduction (ie preservation by record).  
 
The decision on the appropriate archaeological response to the deposits revealed 
within rests with the Local Planning Authority and their designated archaeological 
advisor. 
 
23 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 30

[SYO03] Evaluation Report ! MoLAS  
 
7 Acknowledgements 
The author would like to thank Graham Ling, Borsky and Murphy Architects and 
Gerard Huguenin for their assistance in the production of this report. 
 
8 Bibliography  
 
ACAO, 1993 Model briefs and specifications for archaeological assessments and 
field evaluations, Association of County Archaeological Officers 
 
BADLG, 1986 Code of Practice, British Archaeologists and Developers Liaison 
Group 
 
Corporation of London 2002, Unitary Development Plan: City of London  
 
Corporation of London Department of Planning and Transportation, 2004 Planning 
Advice Note 3: Archaeology in the City of London, Archaeology Guidance, London   
 
Cultural Heritage Committee of the Council of Europe, 2000 Code of Good Practice 
On Archaeological Heritage in Urban Development Policies; adopted at the 15th 
plenary session in Strasbourg on 8-10 March 2000 (CC-PAT [99] 18 rev 3) 
 
Department of the Environment, 1990 Planning Policy Guidance 16, Archaeology 
and Planning 
 
English Heritage, 1991 Exploring Our Past, Strategies for the Archaeology of 
England 
 
English Heritage, May 1998 Capital Archaeology. Strategies for sustaining the 
historic legacy of a world city 
 
English Heritage, 1991 Management of Archaeological Projects (MAP2) 
 
Institute of Field Archaeologists, (IFA), 2001 By-Laws, Standards and Policy 
Statements of the Institute of Field Archaeologists, (rev. 2001), Standard and 
guidance: field evaluation 
 
Institute of Field Archaeologists (IFA), supplement 2001, By-Laws, Standards and 
Policy Statements of the Institute of Field Archaeologists: Standards and guidance # 
the collection, documentation conservation and research of archaeological materials 
 
MoLAS: Aitken, R, 2005 Tower of St Mary Somerset, Lambeth Hill, City of London 
EC4: A method statement for archaeological evaluation, unpub MoL rep 
 
24 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 31

[SYO03] Evaluation Report ! MoLAS  
 
 
 
Museum of London, 1994 Archaeological Site Manual 3rd edition 
 
Museum of London, 2002  A research framework for London archaeology 2002 
 
Schofield, J, with Maloney, C, (eds), 1998 Archaeology in the City of London 1907-
1991: a guide to records of excavations by the Museum of London and its 
predecessors, Archaeol Gazetteer Ser Vol 1, London 
 
Taylor, J, 2003 St Mary Somerset Garden, Lambeth Hill, City of London, An 
archaeological watching brief report, unpub Mol rep 
25 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 32

 [SYO03]Evaluation report ! MoLAS  
 
9 NMR OASIS archaeological report form 
9.1 OASIS ID: molas1-10921 
 
Project details   
Project name Tower of St Mary Somerset  
  
Short description of 
the project 
Foundations for the south wall of the 17th century church as 
rebuilt by Wren were observed to the east of the church at 0.25m 
below ground level. The structure continued below the limit of 
excavation at 1.40m below ground level. Within the tower 
remains of what has been interpreted as a disturbed east-west 
aligned foundation were recorded at 0.75m below floor level. The 
feature was constructed of large blocks of chalk, ragstone and 
flint, and may represent remains of the foundation for the original 
12th century church. Evaluation pits to the north of the tower 
revealed truncation of archaeological deposits to between 1.90m 
and 2.00m below ground level by 19th century activity. A chalk 
and ragstone feature was observed in pit 1 at the limit of 
excavation.  
  
Project dates Start: 12-10-2005 End: 24-10-2005  
  
Previous/future work Yes / Not known  
  
Any associated 
project reference 
codes 
SYO03 - Sitecode  
  
Type of project Field evaluation  
  
Site status Listed Building  
  
Current Land use Other 5 - Garden  
  
Monument type CHURCH Post Medieval  
  
Monument type FOUNDATION Uncertain  
  
Methods & 
techniques 'Test Pits'  
  
Development type Large/ medium scale extensions to existing structures (e.g. 
church, school, hospitals, law courts, etc.)  
  
Prompt Planning condition  
  
26 
P:\CITY1000\1091\na\Field\EVA.DOC 

### Page 33

[SYO03] Evaluation Report ! MoLAS  
Position in the 
planning process Not known / Not recorded  
  
 
Project location   
Country England 
Site location GREATER LONDON CITY OF LONDON CITY OF LONDON St 
Mary Somerset  
  
Postcode EC4  
  
Study area 50.00 Kilometres  
  
National grid 
reference TQ 32163 80880 Point  
  
Height OD Min: 2.30m Max: 2.30m  
  
 
Project creators   
Name of 
Organisation MoLAS  
  
Project brief 
originator MoLAS project manager  
  
Project design 
originator MoLAS  
  
Project 
director/manager Sophie Jackson  
  
Project supervisor Emily Burton  
  
Sponsor or funding 
body Boyarsky Murphy  
  
 
Project archives   
Physical Archive 
Exists? No  
  
Digital Archive 
recipient LAARC  
  
Digital Archive ID SYO03  
  
Paper Archive 
recipient LAARC  
  
Paper Archive ID SYO03  
  p:\city1000\1091\na\field\eva.doc 27

### Page 34

[SYO03] Evaluation Report ! MoLAS  
  
 
Project 
bibliography 1  
 
Publication type Grey literature (unpublished document/manuscript) 
Title Tower of St Mary Somerset Archaeological Evaluation  
  
Author(s)/Editor(s) Burton, E  
  
Date 2005  
  
Issuer or publisher MoLAS  
  
Place of issue or 
publication MoLAS  
  
Description A4 bound report  
 
  p:\city1000\1091\na\field\eva.doc 28