# Source: archaeological discharge of conds.pdf
**Path:** `MoLAS/archaeological discharge of conds.pdf`
---

### Page 1

[IMAGE CONTENT - REQUIRES OCR]