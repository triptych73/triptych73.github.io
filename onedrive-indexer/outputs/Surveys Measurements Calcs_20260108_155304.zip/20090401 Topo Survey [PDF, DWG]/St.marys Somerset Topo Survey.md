# Source: St.marys Somerset Topo Survey.pdf
**Path:** `20090401 Topo Survey [PDF, DWG]/St.marys Somerset Topo Survey.pdf`
---

### Page 1

B
AA
B B
A
B
A A
B
A
B
A
B
A
B
A A
B
B
135mm
120mm
180mm
355mm 245mm
205mm 1400mm
105mm
255mm
1210mm
1210mm
1175mm 405mm
490mm
450mm
405mm
40mm
1060mm
60mm
SECTION A SECTION B
Gulley
138
127
128 129
130
131
132
133
134
135136
137
ROOF PLAN
5958
57
1655
52
51
50
49
48
47
56
55
54
53
svp
72
73
74
75
76
77
7879
84
83
82
81
80
svp
4965
apex
apex
49654965
apex
10
9
8
7
6
5
4
3
2
1
7580
44 33
34
35
36
37
38
43
42
41
40
39
NORTH ELEVATION
WEST ELEVATION SOUTH ELEVATION EAST ELEVATION
390
4120
9590
THIRD FLOOR PLAN SECOND FLOOR PLAN FIRST FLOOR PLAN GROUND FLOOR PLAN
405
4120
4810
4120
390
hatch over
1625
1815
225
1570
1765
apex
apex
1765
3100
svp
svp
225
1570
225
1570
trap door
hatch over
W/Sill : 18.906
W/Head : 22.865
W/Sill : 25.269
W/Head : 26.804
W/Sill : 27.636
W/Head : 31.387
W/Head : 16.408
W/Sill : 14.873
2F Level : 17.527
3F Level : 22.575
4F Level : 27.530
Roof Level : 32.474
1F Level : 14.197
GF Level : 6.540 GF Level : 6.540
W/Head : 16.408
W/Head : 31.387
W/Sill : 27.636
W/Head : 26.804
W/Sill : 25.269
W/Head : 22.865
W/Sill : 18.906
W/Sill : 14.873
Roof Level : 32.474
4F Level : 27.530
3F Level : 22.575
2F Level : 17.527
1F Level : 14.197
GF Level : 6.540
W/Head : 16.408
W/Head : 31.387
W/Sill : 27.636
W/Head : 26.804
W/Sill : 25.269
W/Head : 22.865
W/Sill : 18.906
W/Sill : 14.873
Roof Level : 32.474
4F Level : 27.530
3F Level : 22.575
2F Level : 17.527
1F Level : 14.197
GF Level : 6.540
1F Level : 14.197
Excavation
3F Level : 22.575
4F Level : 27.530
Roof Level : 32.474
W/Sill : 18.906
W/Head : 22.865
W/Sill : 25.269
W/Head : 26.804
W/Sill : 27.636
W/Head : 31.387
W/Sill : 14.873
W/Head : 16.408
2F Level : 17.527