# Source: St Mary Somerset - Topo Elevation Increments LR.pdf
**Path:** `20090401 Topo Survey [PDF, DWG]/St Mary Somerset - Topo Elevation Increments LR.pdf`
---

### Page 1

EAST  ELEVATIONSOUTH  ELEVATIONWEST  ELEVATIONNORTH  ELEVATION
Excavation
98mm  drift94mm  drift 0mm  drift0mm  drift 94mm  drift 92mm  drift22mm  drift 22mm  drift