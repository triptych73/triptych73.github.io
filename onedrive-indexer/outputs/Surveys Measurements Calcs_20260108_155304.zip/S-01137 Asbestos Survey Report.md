# Source: S-01137 Asbestos Survey Report.pdf
**Path:** `S-01137 Asbestos Survey Report.pdf`
---

### Page 1

 
 
 
 
 
 
Asbestos Refurbishment Survey 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
Saint Mary Somerset Tower, 5 Lambeth Hill, London, EC4V 4AG

### Page 2

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
 
 
Client: Saint Mary Somerset Tower 
Job Reference: S-01137 
Report Date: 01/04/2015 
Property Address: 
Saint Mary Somerset Tower 
5 Lambeth Hill 
London 
EC4V 4AG 
Date of Survey: 27/03/2015 
Survey Type: Asbestos Refurbishment Survey 
Surveyor Name:  Mohammed Waheed 
Surveyor Signature: 
 
Report Prepared By: Saffron North 
Signature: 
 
Report Proof Read By: Ian Cook 
Signature: 
 
 

### Page 3

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
   
TABLE OF CONTENTS 
 
 
Table of Contents         
 
Types of Survey           
 
Duty Holders Use of Survey        
 
1. Introduction          
2. Recommendations         
3. Material Assessment Algorithm       
4. References          
  
 
          
Appendix A -  Executive Summary 
 Register of Asbestos Containing Material 
 Non-Asbestos Register  
            
 
Appendix B -  Site Floor Plans        
 
Appendix C -  Laboratory Sample Reports      
 
 
 
 

### Page 4

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
Types of survey 
 
There are two different types of survey: Management Surveys and Refurbishment and Demolition Surveys. 
 
The type of survey will vary during the lifespan of the premises and several may be needed over time. A 
management survey will be required during the normal occupation and use of the building to ensure continued 
management of the ACMs in situ. A refurbishment or demolition survey will be necessary when the building (or part 
of it) is to be upgraded, refurbished or demolished. It is probable that at larger premises a mixture of survey types 
will be appropriate, e.g. a boiler ho use due for demolition will require a refurbishment/demolition survey, while 
offices at the same site would have a management survey. In later years refurbishment surveys may be required in 
rooms or floors which are being upgraded. In sectors where there a re large numbers of properties ( e.g. domestic 
houses) or internal units (e.g. hotels), only particular rooms may be specified for upgrading, e.g. kitchens, bathrooms 
and bedrooms. Refurbishment surveys would only be necessary in these locations. 
 
It is important that the client and the surveyor know exactly what type of survey is to be carried out and where, and 
what the specification will be. So there should be a clear statement and record of the type of survey that is to be 
carried out, including the reasons for selecting that type of survey, and where it is to be carried out. 
 
Management Survey 
 
A management survey is the standard survey. Its purpose is to locate, as far as reasonably practicable, the presence 
and extent of any suspect ACMs in the buildin g which could be damaged or disturbed during normal occupancy, 
including foreseeable maintenance and installation, and to assess their condition. 
Management surveys will often involve minor intrusive work and some disturbance. The extent of intrusion will vary 
between premises and depend on what is reasonably practicable for individual properties, i.e. it will depend on 
factors such as the type of building, the nature of construction, accessibility etc. A management survey should 
include an assessment of th e condition of the various ACMs and their ability to release fibres into the air if they are 
disturbed in some way. This ‘material assessment’ will give a good initial guide to the priority for managing ACMs as 
it will identify the materials which will mos t readily release airborne fibres if they are disturbed. The survey will 
usually involve sampling and analysis to confirm the presence or absence of ACMs. However a management survey 
can also involve presuming the presence or absence of asbestos. A managem ent survey can be completed using a 
combination of sampling ACMs and presuming ACMs or, indeed, just presuming. Any materials presumed to contain 
asbestos must also have their condition assessed (i.e. a material assessment). 
Management surveys can involve a combination of sampling to confirm asbestos is present or presuming asbestos 
to be present. 
 
 
Refurbishment and Demolition survey 
 
A refurbishment and demolition survey is needed before any refurbishment or demolition work is carried out. This 
type of su rvey is used to locate and describe, as far as reasonably practicable, all ACMs in the area where the 
refurbishment work will take place or in the whole building if demolition is planned. The survey will be fully intrusive 
and involve destructive inspectio n, as necessary, to gain access to all areas, including those that may be difficult to 
reach. A refurbishment and demolition survey may also be required in other circumstances, e.g. when more 
intrusive maintenance and repair work will be carried out or for plant removal or dismantling. 
There is a specific requirement in CAR 2012 (regulation 7) for all ACMs to be removed as far as reasonably 
practicable before major refurbishment or final demolition. Removing ACMs is also appropriate in other smaller 
refurbishment situations which involve structural or layout changes to buildings ( e.g. removal of partitions, walls, 
units etc.). Under CDM, the survey information should be used to help in the tendering process for removal of ACMs 
from the building before work starts.  
The survey report should be supplied by the client to designers and contractors who may be bidding for the work, so 
that the asbestos risks can be addressed. In this type of survey, where the asbestos is identified so that it can be 

### Page 5

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
removed (rather than to ‘manage’ it), the survey does not normally assess the condition of the asbestos, other than 
to indicate areas of damage or where additional asbestos debris may be present. However, where the asbestos 
removal may not take place for some time, the A CMs’ condition will need to be assessed and the materials 
managed. 
 
Refurbishment and demolition surveys  are intended to locate all the asbestos in the building (or the relevant part), 
as far as reasonably practicable. It is a disruptive and fully intrusiv e survey which may need to penetrate all parts of 
the building structure. Aggressive inspection techniques will be needed to lift carpets and tiles, break through walls, 
ceilings, cladding and partitions, and open up floors. In these situations, controls s hould be put in place to prevent 
the spread of debris, which may include asbestos. Refurbishment and demolition surveys should only be conducted 
in unoccupied areas to minimise risks to the public or employees on the premises. Ideally, the building should not be 
in service and all furnishings removed. For minor refurbishment, this would only apply to the room involved or even 
part of the room where the work is small and the room large. In these situations, there should effective isolation of 
the survey area (e.g. full floor to ceiling partition), and furnishings should be removed as far as possible or protected 
using sheeting. The ‘surveyed’ area must be shown to be fit for reoccupation before people move back in. This will 
require a thorough visual inspecti on and, if appropriate ( e.g. where there has been significant destruction), 
reassurance air sampling with disturbance. Under no circumstances should staff remain in rooms or areas of 
buildings when intrusive sampling is performed. 
 
Duty holder’s use of survey information 
The survey report needs to meet the requirements of the client and comply with the tender/contractual obligations. 
The report should be fit for purpose and the client should check that this is the case. Therefore the client should 
examine the report and carry out a number of checks to make sure that the survey has been adequate and that the 
report is suitable and accurate. 
 
The client/duty holder should do to check the accuracy of the survey report 
 Check the report against the original tender.  
 Check for un agreed caveats or disclaimers.  
 Check that the survey is as requested: Management or refurbishment/demolition (or a combination).  
 Check diagrams and plans are clear and accurate.  
 Check all rooms and areas have been accessed.  
 Check suffi cient samples have been taken (usually 1 -2 per area/room)  and that sample numbers are not  
disproportionate (e.g. dominated by one ACM type).  
 Check sample numbers reflect variations in the same ACMs, e.g. different ceiling tiles in the same room.  
 Check for any obvious discrepancies and inconsistencies.  
 
 

### Page 6

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
 
1. Introduction 
 
1.1 An Asbestos Refurbishment Survey  of the premises was carried out on behalf of Saint Mary Somerset Tower . 
The survey and all sampling was carried out in accordance with the requirements of  the HSE document 
‘Surveying, sampling and assessment of asbestos containing material’ HSG 264. It was the intention to survey all 
areas of the premises were surveyed on at the time of survey for materials suspected of containing asbestos. 
 
1.2 Scope of Works: 
 
The scope of works was to carry out an Asbestos Refurbishment Survey to a detached tower over six floors. 
 
The scope of the Asbestos Refurbishment Survey was agreed and discussed between Salvum Limited and Saint 
Mary Somerset Tower prior to the survey being undertaken. 
 
The content of this survey report i s intended to provide the client  with the information necessary to manage 
the risks arising from ACM’s present within the area. 
 
However, there remains a possibility that further ACM’s may be present and exposed and possibly disturbed 
during any alterations, refurbishment or demolition works. 
It is now recognised that even with ‘complete’ access demolition surveys, all ACMs may not be identified and 
this only becomes apparent during demolition itself. 
 
1.3 The areas described in the scope of works were surveyed at the time of the survey. Please refer to the specific 
exclusions/non-accessed table below for areas not included in this survey. 
 
1.4 Site Description 
 
The property consists of a detached tower over six fl oors. The approximate age of the property is  1600s and is 
constructed of masonry stonework and brickwork, metal rainwater goods, lead lined flat roof. 
 
1.5 Specific Exclusions/Non-Accessed: 
 
Floor Room Description Reason Photo 
Saint Mary Somerset 
Tower / 2nd Floor 006 W/C (Water heater) 
The water heater 
unit was sealed 
with rusted screws 
and could not be 
fully accessed. 
  
 
1.6  Specific exclusions relating to surveying; 
 
1.6.1 Samples have not been taken where the act of sampling would endanger the Surveyor or affect the 
functional integrity of the item concerned e.g. fuses within electrical boxes, fire doors, gaskets, glazing and 
power plant. 
 
1.6.2 No inspection of live electrical or mechanical plant or similar requiring the attendance of a specialist 
engineer was carried out. 
 
1.6.3 No inspection of any area requiring specialist access equipment other than stepladders was carried out. 

### Page 7

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
1.6.4 No report has been made on any concealed spaces which may exist within the fabric of the building where 
the extent and presence of these is not evident due to inaccessibility or insufficient knowledge of the structure 
of the building at the time of the survey.  Unless specifically agreed by Salvum Limited and the client. Please 
refer to Appendix A for further details. 
 
1.6.5 Any area not accessed (and where no other information exists) must be presumed to contain asbestos and 
be managed on that basis. 
1.6.6 No inspection of any area deemed unsafe (e.g. fire damaged premises) or where access was physically 
impractical was carried out. 
 
 
 
1.7 Specific exclusions relating to sampling; 
 
1.7.1 Samples have not been taken where the act of sampling would endanger the Surveyor or affect the 
functional integrity of the item concerned e.g. fuses within electrical boxes, fire doors, gaske ts, glazing and 
power plant. 
 
1.7.2 Samples have not been taken where prohibited by the client. 
 
1.7.3 Samples have been taken from all materials which, upon initial visual inspection, appeared to contain 
asbestos with the exception of some items of mastic , resin or rubber, which contain  asbestos where the 
quantity of those materials and the content of asbestos within the material is insignificant in terms of risk to 
health and safety. 
 
1.7.4 Materials have been referred to as Asbestos Insulation Board or Asbestos Cement based on their asbestos 
content and visual appearance alone. Density checks have not been carried out unless otherwise stated. 
 
1.8 Caveat 
 
Every effort has been made to identify all asbestos materials so far as was reasonably practical to do so  within 
the scope of the survey and attached report. Methods used to carry out the survey were agreed with the client 
prior to any works being commenced. 
 
Survey techniques used involves trained and experienced surveyors using the combined approach with re gard 
to visual examination and necessary bulk sampling. It is always possible after a survey that asbestos based 
materials of one sort or another may remain in the property or area covered by the survey, this could be due to 
various reasons: 
 
● Asbestos materials existing within areas not specifically covered by this report are therefore outside the scope 
of the survey. 
● Materials may be hidden or obscured by other items or cover finishes, i.e. paint, over boarding, disguising 
etc., where this is the case then its detection will be impaired. 
● Asbestos may well be hidden as part of the structure to a building and not visible until the structure is 
dismantled at a later date. 
● Debris from previous asbestos removal projects may well be present i n some areas; general asbestos debris 
does not form part of this survey however all good intentions are made for its discovery. 
● Where an area has been previously stripped of asbestos, i.e. plant rooms, ducts, etc., and new coverings 
added, it must be pointed out that asbestos removal techniques have improved steadily over the years since its 
introduction. Most notably would be the Control of Asbestos Regulations (2012) or other similar subsequent 
regulations laying down certain enforceable guidelines. Asb estos removal prior to this regulation would not 
have been of today’s standard and therefore debris may be present below new coverings. 

### Page 8

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
● This survey will detail all areas accessed and all samples taken, where an area is not covered by this survey it 
will be due to No Access for one reason or another, i.e. working operatives, sensitive location or just simply no 
access. It may have been necessary for the limits of the surveyor’s authority to be confirmed prior to the survey. 
● Access for the survey may be restricted for many reasons beyond our control such as height, inconvenience to 
others, immovable obstacles or confined space. Where electrical equipment is present and presumed in the 
way of the survey no access will be attempted until proof of its safe state is given. Our operatives have a duty of 
care under the Health and Safety at Work Act (1974) for both themselves and others. 
● In the building where asbestos has been located and it is clear that not all areas have been investigated, any 
material that is found to be suspicious and not detailed as part of the survey should be treated with caution and 
sampled accordingly. 
● Certain materials contain asbestos to varying degrees and some may be less densely contaminated at certain 
locations (Artex for example). Where this is the case the sample taken may not be representative of the whole 
product throughout. 
● Where a survey is carried out under the guidance of the owner of the property, or his representative, then 
the survey will be as per his/her instructions and guidance at that time. 
● Salvum Ltd cannot accept any liability for loss, injury, damage or penalty issues due to error or omissions 
within this report. 
● Salvum Ltd cannot be held responsible for any damage caused as part of this survey carried out  on your 
behalf. Due to the nature and necessity of sampling for asbestos some damage is unavoidable and will be 
limited to just that necessary for the taking of the sample. 
 

### Page 9

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
 
2 Recommendations 
 
2.1 The recommendations detailed in the register in Appendix A are based on each item’s potential for releasing 
fibres as described in the Health and Safety Executive guideline HSG 264. 
  
2.2 A quantifiable assessment of the risk of fibre release has been made by using an algorithm which takes into 
account all facto rs relevant to the item and the normal activities of the building occupants. Recommendation 
will then normally involve removal, encapsulation or management as described below; 
 
●  Removal of items vulnerable to damage or in such poor condition that removal is the only practical 
option, or where refurbishment or demolition work is planned whereby the work will affect the 
asbestos materials present and render removal necessary. 
●  Enclosure or encapsulation where the material is in poor condition or is vulnerable to damage. 
●  Management of the asbestos material present by labelling, registering and periodic inspection as 
necessary. 
 
2.2.1 Definition of terms; 
 
 Enclosure - Provision of a physical barrier to provide mechanical protection of the material to 
prevent it being disturbed or damaged. 
 Encapsulation - Provision of paint type coating to create a continuous seal to the surface of the 
material and thereby prevent fibre release. 
 Labelling - Fixing of labels to the surface of the material to warn of the hazard 
 Registering - Entering the details, including type, location and extent in a register which is bought to 
the attention of all persons who might plan or undertake works in the building. 
 Periodic - Inspection of the material at defined intervals to check that its condition hasn’t 
deteriorated to require enclosure, encapsulation or removal. 
 Repair - Addition of a seal to the material to prevent the further deterioration of the material . 
Carried out in conjunction with labelling. 
 Removal - Complete removal of a material in compliance with CAWR 1998. 
 Manage in situ  - a policy of regular inspections to ensure that the ACM is maintained in good 
condition. 
 

### Page 10

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
 
3. Material Assessment Algorithm 
 
In the material assessment process, the main factors influencing fibre release are given a score which can then 
be added together to obtain a material assessment rating. The four main parameters which determine the 
amount of fibre released from an ACM when subject to disturbance are: 
 
 Product type; 
 
 Extent of damage or deterioration; 
 
 Surface treatment; and 
 
 Asbestos type. 
 
Each parameter is scored between 1 and 3. A score of 1 is equivalent to a low potential for fibre release, 2 =  
Medium and 3 = high. Two parameters can also be given a nil score (equivalent to a very low potential for fibre 
release). The value assigned to each of the four parameters is added together to give a total score of between 2 
and 12. Presumed or strongly presumed ACMs are scored as crocidolite (i.e. score = 3) unless there is strong 
evidence to show otherwise. Examples of scoring for each parameter are given in below. 
 
Materials with assessment scores  
 
 
Scores of 4 or less have a very 
low potential to release fibres <4 Very Low 
Scores of 5 and 6 a low 
potential 5-6 Low 
Scores of between 7 and 9 are 
regarded as having a medium 
potential 
7-9 Medium 
Scores of 10 or more are rated 
as having a high potential to 
release fibres 
10+ High 
Non--asbestos materials are 
not scored 0 Not Recorded 
 

### Page 11

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
 
 
Material Assessment Algorithm Table 
 
Sample Variable 
 
Score Examples of scores(see notes for more details) 
Product type  
(or debris from 
product) 
1 
Asbestos-reinforced composites (plastics, resins, mastics, 
roofing felts, vinyl floor tiles, semi--rigid paints or 
decorative finishes, asbestos cement etc.). 
2 
AIB, millboards, other low--density insulation boards, 
asbestos textiles, gaskets, ropes and woven textiles, 
asbestos paper and felt. 
3 
Thermal insulation (e.g. pipe and boiler lagging), sprayed 
asbestos, loose asbestos, asbestos mattresses and 
packing. 
Extent of  
damage/deterioration 
0 Good condition: no visible damage 
1 Low damage: a few scratches or surface marks, broken 
edges on boards, tiles etc. 
2 
Medium damage: significant breakage of materials or 
several small areas where material has been damaged 
revealing loose asbestos fibres. 
3 High damage or delamination of materials, sprays and 
thermal insulation. Visible asbestos debris. 
Surface treatment 
0 Composite materials containing asbestos: reinforced 
plastics, resins, vinyl tiles. 
1 Enclosed sprays and lagging, AIB (with exposed face 
painted or encapsulated) asbestos cement sheets etc. 
2 Unsealed AIB, or encapsulated lagging and sprays. 
3 Unsealed lagging and sprays. 
Asbestos type 
1 Chrysotile. 
2 Amphibole asbestos excluding crocidolite. 
3 Crocidolite. 
 
 

### Page 12

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
4. References 
 
 Work with materials containing asbestos. Control of Asbestos Regulations 2012. Approved Code of Practice 
and guidance L143 HSE Books 2006  
 Managing health and safety in construction. Construction (Design and Management) Regulations 2007. 
Approved Code of Practice L144 HSE Books  
 A comprehensive guide to managing asbestos in premises HSG227 HSE Books 2002 ISBN 978 0 7176 2381 5  
 A short guide to managing asbestos in premises Leaflet INDG223(rev4) HSE Books 2009 (single copy free or 
priced packs of 10 ISBN 978 0 7176 6375 0)  
 Asbestos: The Survey Guide HSG264 HSE Books 2012 ISBN 978 0 7176 6502 0 
 Asbestos: The licensed contractors’ guide HSG247 HSE Books 2006 ISBN 978 0 7176 2874 2  
 The management of asbestos in non--domestic premises. Regulation 4 of the Control of Asbestos 
Regulations 2006. Approved Code of Practice and guidance L127 (Second edition) HSE Books 2006 ISBN 978 
0 7176 6209 8  
 Health and Safety at Work etc. Act 1974 (c.37) The Stationery Office 1974 ISBN 978 0 10 543774 1  
 Management of health and safety at work. Management of Health and Safety at Work Regulations 1999. 
Approved Code of Practice and guidance L21 (Second edition) HSE Books 2000 ISBN 978 0 7176 2488 1  
 BS EN ISO/IEC 17020:2004 General criteria for the operation of various types of bodies performing 
inspection British Standards Institution  
 BS EN ISO/IEC 17024:2003 Conformity Assessment. General requirements for bodies operating certification 
of persons British Standards Institution  
 BS EN ISO 9001:2008 Quality management systems. Requirements British Standards Institution  
 BS 6002--4:2006 ISO 3951--5:2006 Sampling procedures for inspection by variables. Sequential sampling 
plans indexed by acceptance quality limit (AQL) for inspection by variables (known standard deviation) 
British Standards Institution  
 BS EN ISO/IEC 17025:2005 General requirements for the competence of testing and calibration laboratories 
British Standards Institution  
 Asbestos in system buildings: Control of Asbestos Regulations 2012. Guidance for duty holders HSE 2008 
www.hse.gov.uk/services/education/claspguidance.pdf  
 Asbestos: The analysts’ guide for sampling, analysis and clearance procedures HSG248 HSE Books 2005 ISBN 
978 0 7176 2875 9  
 BS EN 60335 Specification for safety of household and similar electrical appliances British Standards 
Institution  
 Asbestos essentials: A task manual for building, maintenance and allied trades on non--licensed asbestos 
work HSG210 (Second edition) HSE Books 2008 ISBN 978 0 7176 6263 0  
 Accreditation of bodies surveying for asbestos in premises Edition 2 RG8 8/8 UKAS 2008 (for the application 
of ISO/IEC 17020) 

### Page 13

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
Appendix A 
 
Executive Summary 
Register of Asbestos Containing Material 
Non-Asbestos Register

### Page 14

Asbestos Refurbishment Survey - Saint Mary Somerset Tower         
  
 
 
 
Executive Summary 
 
 
No asbestos containing materials were detected 

### Page 15

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
Asbestos Register 
 
 

### Page 16

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
Non-Asbestos Register 
 
Item Level Location/Room 
Number Survey Type Sample Description Sample Reference Photo Material Assessment 
1.  
Saint Mary 
Somerset 
Tower / 1st 
Floor 
Stairwell (001) 
Asbestos 
Refurbishment 
Survey 
Seal to roof door - Putty S1 
 
No Asbestos Detected 
2.  
Saint Mary 
Somerset 
Tower / 1st 
Floor 
Vestibule  (005) 
Asbestos 
Refurbishment 
Survey 
Seal to fuse box lid - Rope S6 
 
No Asbestos Detected 
3.  
Saint Mary 
Somerset 
Tower / 1st 
Floor 
Vestibule  (005) 
Asbestos 
Refurbishment 
Survey 
Lining to rear of flashes -  S7 
 
No Asbestos Detected 
4.  
Saint Mary 
Somerset 
Tower / 2nd 
Floor 
Reading Room 
(004) 
Asbestos 
Refurbishment 
Survey 
Flooring - Vinyl Products S4 
 
No Asbestos Detected 
5.  
Saint Mary 
Somerset 
Tower / 2nd 
Floor 
Store (005) 
Asbestos 
Refurbishment 
Survey 
   No suspect material found 
6.  
Saint Mary 
Somerset 
Tower / 2nd 
Floor 
W/C (006) 
Asbestos 
Refurbishment 
Survey 
Toilet seat  - Reinforced Plastics S5 
 
No Asbestos Detected 
7.  
Saint Mary 
Somerset 
Tower / 3rd 
Floor 
Tank room (003) 
Asbestos 
Refurbishment 
Survey 
Lining to water tank - Roof Felt S2 
 
No Asbestos Detected 
8.  
Saint Mary 
Somerset 
Tower / 3rd 
Floor 
Tank room (003) 
Asbestos 
Refurbishment 
Survey 
Water Tank lining - Loose Fill Insulation S3 
 
No Asbestos Detected 
9.  
Saint Mary 
Somerset 
Tower / 4th 
Floor 
Belfry (002) 
Asbestos 
Refurbishment 
Survey 
   No suspect material found 
 
 

### Page 17

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
 
Appendix B 
 
Site Floor Plans 
 
 
 
 
 

### Page 18

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
SITE 
PLAN 
THIS SITE PLAN SHOULD 
BE READ IN 
CONJUNCTION WITH THE 
FULL ASBESTOS SURVEY 
REPORT 
KEY Sample Numbers 
 
Unit 28, 
Essex Technology & Innovation 
Centre, 
The Gables, 
Fyfield Road, 
Ongar, CM5 0GA 
NOT TO SCALE 
Limitations of reported information 
The information contained within this report which identifies the locations of asbestos containing 
materials (ACMs) should not be treated as either exhaustive or definitive. It should always be 
assumed that there may be other ACMs present, hidden or undetected within the fabric of the 
building. Further investigations may be necessary when carrying out works likely to disturb the 
fabric of the building. 
 
Negative Sample 
Number 
 
Positive Sample 
Number 
 
 
 

### Page 19

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
 
Appendix C 
 
Laboratory Sample Certificates 

### Page 20

Asbestos Refurbishment Survey - Saint Mary Somerset Tower  
  
 
 
 
 
 