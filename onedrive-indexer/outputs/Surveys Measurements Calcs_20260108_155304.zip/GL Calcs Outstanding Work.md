# Source: GL Calcs Outstanding Work.pdf
**Path:** `GL Calcs Outstanding Work.pdf`
---

### Page 1

[IMAGE CONTENT - REQUIRES OCR]

### Page 2

[IMAGE CONTENT - REQUIRES OCR]