# Source: image78.jpeg [IMAGE]
**Path:** `image78.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']