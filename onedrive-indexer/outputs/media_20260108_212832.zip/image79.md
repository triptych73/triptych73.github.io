# Source: image79.png [IMAGE]
**Path:** `image79.png`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']