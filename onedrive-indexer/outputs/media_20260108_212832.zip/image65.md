# Source: image65.png [IMAGE]
**Path:** `image65.png`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']