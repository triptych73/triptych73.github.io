# Source: image20.jpeg [IMAGE]
**Path:** `image20.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']