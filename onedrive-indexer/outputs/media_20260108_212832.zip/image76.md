# Source: image76.jpeg [IMAGE]
**Path:** `image76.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']