# Source: image14.jpeg [IMAGE]
**Path:** `image14.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']