# Source: image75.jpeg [IMAGE]
**Path:** `image75.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']