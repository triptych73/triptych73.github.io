# Source: image29.jpeg [IMAGE]
**Path:** `image29.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']