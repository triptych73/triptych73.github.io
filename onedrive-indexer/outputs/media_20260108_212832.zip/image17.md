# Source: image17.png [IMAGE]
**Path:** `image17.png`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']