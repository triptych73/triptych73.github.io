# Source: image64.jpeg [IMAGE]
**Path:** `image64.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']