# Source: image47.jpeg [IMAGE]
**Path:** `image47.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']