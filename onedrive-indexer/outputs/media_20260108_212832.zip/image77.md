# Source: image77.jpeg [IMAGE]
**Path:** `image77.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']