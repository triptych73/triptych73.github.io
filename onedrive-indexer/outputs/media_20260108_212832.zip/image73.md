# Source: image73.jpeg [IMAGE]
**Path:** `image73.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']