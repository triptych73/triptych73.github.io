# Source: image8.jpeg [IMAGE]
**Path:** `image8.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']