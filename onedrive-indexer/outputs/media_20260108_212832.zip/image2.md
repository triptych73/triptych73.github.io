# Source: image2.jpeg [IMAGE]
**Path:** `image2.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']