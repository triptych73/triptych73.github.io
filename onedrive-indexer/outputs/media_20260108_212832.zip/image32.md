# Source: image32.png [IMAGE]
**Path:** `image32.png`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']