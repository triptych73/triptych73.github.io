# Source: image6.jpeg [IMAGE]
**Path:** `image6.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']