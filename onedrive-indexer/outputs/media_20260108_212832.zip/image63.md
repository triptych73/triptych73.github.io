# Source: image63.jpeg [IMAGE]
**Path:** `image63.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']