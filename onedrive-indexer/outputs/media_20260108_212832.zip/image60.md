# Source: image60.jpeg [IMAGE]
**Path:** `image60.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']