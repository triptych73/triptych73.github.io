# Source: image80.jpeg [IMAGE]
**Path:** `image80.jpeg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']