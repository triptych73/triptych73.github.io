# Source: image36.jpg [IMAGE]
**Path:** `image36.jpg`
---

[Error: 'google-generativeai' library not installed. Run 'pip install google-generativeai']