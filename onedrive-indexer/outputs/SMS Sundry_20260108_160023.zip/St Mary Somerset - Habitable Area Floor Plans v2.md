# Source: St Mary Somerset - Habitable Area Floor Plans v2.pdf
**Path:** `St Mary Somerset - Habitable Area Floor Plans v2.pdf`
---

### Page 1

[IMAGE CONTENT - REQUIRES OCR]

### Page 2

[IMAGE CONTENT - REQUIRES OCR]