# Source: STMS Ltd Employment Contract for Director.docx
**Path:** `STMS Ltd Employment Contract for Director.docx`
---

STMS Ltd Employment Contract for Director

1. Parties

This Employment Contract is made between Gregory Renwick ("Employee") and STMS Ltd ("Employer"), effective from 06/04/2024].

2. Position

The Employee shall serve as Director of STMS Ltd, performing duties as required by the board of directors and in line with the company’s objectives.

3. Salary and Compensation

Base Salary: The Employee’s gross annual salary will be £18,500.

Salary Sacrifice Arrangement: The Employee agrees to participate in a salary sacrifice arrangement whereby £21,499 of the initial £39,999 salary will be sacrificed in exchange for equivalent employer pension contributions to a Self-Invested Personal Pension (SIPP) or other qualifying pension scheme.

Note: This salary sacrifice agreement reduces the Employee’s taxable income and National Insurance (NI) contributions while maintaining a salary above the NMW.

4. Employer Pension Contributions

As part of the salary sacrifice arrangement, the Employer will contribute £21,499 annually into the Employee’s SIPP.

These contributions are part of the Employee’s remuneration and are not subject to income tax or NI deductions.

5. Working Hours

The Employee is expected to work [Hours per Week] at the company’s primary office or other locations as required. Flexibility in hours may apply due to the senior nature of the role.

6. Dividends

As a shareholder, the Employee may be eligible for dividend payments based on company performance and profit distribution as approved by the board.

Dividends are not considered part of the Employee’s salary and are subject to separate tax treatment, providing tax efficiency on company distributions.

7. Tax Compliance and Reporting

The Employer and Employee agree to comply with HMRC requirements for salary sacrifice and report all earnings, including salary and dividends, in line with legal obligations.

Any adjustments to the salary or pension contributions must be agreed upon in writing and documented as an amendment to this contract.

8. Benefits and Expenses

The Employee is eligible for [specific benefits, such as healthcare, life insurance, etc.], subject to the company’s benefits policy.

Reasonable business expenses incurred by the Employee in the performance of their duties will be reimbursed according to the company’s expense policy.

9. Termination of Employment

Notice: Either party may terminate this contract with [Notice Period, e.g., 1 month] notice in writing.

Salary Sacrifice Agreement Termination: Should this employment be terminated, the salary sacrifice arrangement will also terminate, and the base salary of £39,999 will revert unless otherwise agreed upon.

10. Amendments and Legal Compliance

This contract constitutes the entire agreement between the parties. Any amendments must be in writing and signed by both parties.

Signed for and on behalf of STMS Ltd

Authorized Signature Date: 06/04/2024

Printed Name and Position

Gregory Renwick, Director

Signed by the Employee

Date: 06/04/2024

Employee’s Printed Name

Gregory Renwick