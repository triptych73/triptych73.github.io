# Source: St Mary Somerset - Update & Outstanding Tasks.docx
**Path:** `St Mary Somerset - Update & Outstanding Tasks.docx`
---

Completed tasks - Heritage

Level 01

- defrassing, cleaning and repointing of stone to dome and walls particularly in areas that had suffered from water damage and efluorescence and the reapplication of a light lime wash to help visually pull the stone work together;

- exterior stone door surrounds defrassed and 1880s paint removed.

Level 04

- repointing of brickwork in the interior space, together with defrassing, cleaning and repointing of Portland and Reigate to the window surrounds and alcoves;

- creation and dressing of the new opening between the new extension and main space, including installation of 2 new Portland stone profiled door jambs to support the existing arch;

- cleaning of limewashed brickwork with VorTech bringing back to red brick.

Level 05

- wooden louvres altered, repaired and repainted;

- installation of new windows in main room interior to the wooden louvres;

- new cedar louvres 80% complete for arched extension window;

- extension window fabricated and ready on site ready for installation following instal. of new cedar louvres;

- cleaning of carbon sulfation to Portland stone masonry with VorTech. Selective cleaning of brickwork where this will not be rendered.

Level 06

- wooden louvres altered, repaired and repainted;

- new windows to the three alcoves in the main space are on site and ready for installation;

- mortar raked from brickwork ready for repointing and bricks to be cleaned next week with VorTech;

- new cedar louvres 80% complete for arched extension window;

- extension window fabricated and ready on site ready for install following installation of new cedar louvres;

- cleaning of carbon sulfation to Portland stone masonry with VorTech. Selective cleaning of brickwork where this will not be rendered.

Level 07/08

- all brickwork raked and defrassing ready for repointing;

- cleaning of carbon sulfation to Portland stone ashlar and window surrounds with VorTech. Selective cleaning of brickwork.

Level 09

- louvres pinned and repaired where damaged;

- louvres to be cleaned next week with VorTech prior to installation in front of the Crittal windows to the four alcoves which are all also ready on site ready for installation;

- cleaning of carbon sulfation to all brickwork and Portland stone ashlar, louvres and window surrounds with VorTech.

Level 10 Roof terrace

- all visible rusted dog cramps removed from the Portland finials and the stone work repaired and repointed.

Completed tasks - Other

BT line connected

Openings between extension and main building made good, including on L04 the installation of new Portland stone jambs to form an arched opening

Garden irrigation system reconnected and now fully functional

Street railings and upstands reinstated

All accessible external stonework repointed; finials repaired.

All bar one extension window installed

False floor installed to Level 01

Outstanding Tasks

Further repair of stone louvres following cleaning (HE) [3 weeks, July 2018]

New Crittal windows to be installed to existing tower on levels 5-6 and level 9 (HE) [7 weeks, Jun-Aug 2018]

New door to be installed (DA) [1 week, June 2018]

Gas connection to be completed (DA) [unclear]

Garden paving to be reinstated & cleaned (DA) [4 weeks, by Oct- Nov 2018 (dependant on gas connection)]

Repair and repointing of external stonework as detailed by SSHC rope access report (HE) [8 weeks, Aug Oct 2018]