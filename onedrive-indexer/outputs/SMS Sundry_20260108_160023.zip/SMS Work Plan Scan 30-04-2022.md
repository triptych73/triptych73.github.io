# Source: SMS Work Plan Scan 30-04-2022.pdf
**Path:** `SMS Work Plan Scan 30-04-2022.pdf`
---

### Page 1

main
kitchen
ensuite
sccortd fix heat alatMi
pull cable +
No. sockets instaj[
'V transforncr
handrail? 13
fix
sti'Jlf
[eval
test.
pipc
j-•heck
sink drain issue silica.)'lc
pjcssurc test
lay laniitlütc
floor
repair
shower controls plasterboard
boxing in
sink
3
ve-.,o
3
clean floor,
oilcte sillk


### Page 2

power socket
em?runce wi,jc light Lisc
cjftergcncy light
run
edge of
for spit?))
digidjm
plant COttSUtner unit
panel
stroke fix
fire separation
betwcerji
board
ceiling
plaaterbt.btnd
check
and door
opens
'1 ö.av}
fire
Dice
patch
wall from old
light switch


### Page 3

bedroom
lobby
ensuite
install ceiling
conv[cte
wiling Cl.! and
socket/switcli
instali cciliKjE
roae
dali switch
socket second
fix
install ceiling
rosc
fix
sprinkler plates
smoke
finc segæ,Tatioti
Intetfloor
fire separatort
inter floor
n/a
ceiling
patch
lobby
cleat out
piastQiiog.utd to
1
plastc7Eé0ütd
ftfricrrnostat ccillng
vertt
plastcboard
cap toilet waste ceiling
ccntergt vent test
4 31s


### Page 4

ceiling
wiring
bedroom sockct/switct'
install ceiling
gSx
lobby dali switch
socket second
fix
install ceiling
ß53 rose
srt0(Jke
sprinkler
scrti0kc
fire
intc7fllvor
fire separation
irater floor cap toilet waste
ensuite
e..•vve.Ci.L
ceiiiTtg v;jtcil
fire
to lobby
112
to
extra
to
wall
plasterboard
cciling
plastcboard
cci3ing
ccmcnt board
1+
vcvt tr-ct
vert
vtVit


### Page 5

soc.•kct
fix
install
263 Inter
ensuite
lighting
stair lobby
ernergcri7i(-Y
01 lightng
toilet cailing
board
contp!lctc
pressure
pipe tloor! 2
cciling
rupe to fnigher
n/a lovcls n/a
1
3
