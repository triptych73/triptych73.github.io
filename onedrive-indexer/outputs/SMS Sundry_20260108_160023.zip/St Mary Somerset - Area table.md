# Source: St Mary Somerset - Area table.pdf
**Path:** `St Mary Somerset - Area table.pdf`
---

### Page 1

ST MARY SOMERSET – SCOPE OF WORKS FOR BUILDING CONTROL SIGN-OFF 
 
 
 
Room Area 
Proportion 
of Total 
Floor 
Area 
Level 01 Kitchen/WC Shower 7.85 4.5% 
Level 01 Reception 20.42 16.0% 
Level 02 Entrance 7.83 20.5% 
Level 03 Plant Room 6.20 24.0% 
Level 04 Lobby 4.7 26.7% 
Level 04 Ensuite 3.13 28.4% 
Level 04 Bedroom 18.2 38.8% 
Level 05 Lobby 4.7 41.4% 
Level 05 Ensuite 3.13 43.2% 
Level 05 Bedroom 19.04 54.0% 
Level 06 Lobby 4.7 56.7% 
Level 06 WC Laundry 2.93 58.3% 
Level 06 Living Room 18.5 68.8% 
Level 07 Kitchen 18.6 79.4% 
Level 08 Dining Room 13.37 87.0% 
Level 09 Bedroom 23.00 100.0% 
   
   
Total 176.3  
 
Table 1: Square meterage of each room and cumulative proportion of the premises which 
that represents as you work your way up the property. 
 
 
Due the additional space that the extension provides the lower 5 floors will of themselves 
constitute 54% of the total floor area. However, because the lift goes up to the 6th floor and 
we are not able to lock off the top door of the lift, we propose to include the 6th floor 
extension into the total area for which we will be able seek building control sign-off. 
 