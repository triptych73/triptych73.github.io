# Source: stone abundance.xlsx
**Path:** `stone abundance.xlsx`
---

## Sheet: Sheet1
| Unnamed: 0   | Unnamed: 1   | Unnamed: 2   | Unnamed: 3   | Unnamed: 4           | Unnamed: 5          | Unnamed: 6   | Unnamed: 7          | Unnamed: 8   |
|:-------------|:-------------|:-------------|:-------------|:---------------------|:--------------------|:-------------|:--------------------|:-------------|
| quantity     | length       | width        | thickness    | volume               | m2                  | nan          | nan                 | nan          |
| 7            | 1.4          | 0.49         | 0.075        | 0.15                 | 4.802               | nan          | 4 No. @ course 18   | nan          |
|              |              |              |              |                      |                     |              | 1 No. @ course 20   |              |
|              |              |              |              |                      |                     |              | 2 No. @ course 19   |              |
| 5            | 0.9          | 0.381        | 0.075        | 0.1285875            | 1.7145000000000001  | nan          | 2/3 No. @ course 22 | nan          |
|              |              |              |              |                      |                     |              | 2/3 No. @ course 29 |              |
| 1            | 0.82         | 0.53         | 0.075        | 0.032595             | 0.4346              | nan          | course 19           | nan          |
| 1            | 1.01         | 0.327        | 0.075        | 0.02477025           | 0.33027             | nan          | nan                 | nan          |
| 5            | 0.74         | 0.385        | 0.075        | 0.1068375            | 1.4244999999999999  | nan          | 2 No. @ course 30   | nan          |
|              |              |              |              |                      |                     |              | 2 No. @ course 40   |              |
| 1            | 0.825        | 0.505        | 0.075        | 0.031246874999999997 | 0.41662499999999997 | nan          | course 20           | nan          |
| 1            | 0.572        | 0.38         | 0.075        | 0.016302             | 0.21736             | nan          | course 29           | nan          |
| 1            | 1.09         | 0.531        | 0.075        | 0.04340925           | 0.57879             | nan          | course 35           | nan          |
| 1            | 1            | 0.504        | 0.075        | 0.0378               | 0.504               | nan          | course 20?? Or/     | nan          |
|              |              |              |              |                      |                     |              | course 35           |              |
| 1            | 0.83         | 0.383        | 0.075        | 0.02384175           | 0.31789             | nan          | nan                 | nan          |
| 1            | nan          | nan          | 0.075        | 0.075                | 0                   | nan          | nan                 | nan          |
| 1            | nan          | nan          | 0.075        | 0.075                | 0                   | nan          | nan                 | nan          |
| 1            | nan          | nan          | 0.075        | 0.075                | 0                   | nan          | nan                 | nan          |
| 5            | 1            | 0.335        | 0.075        | 0.125625             | 1.675               | nan          | 4 No. @ course 23   | nan          |
|              |              |              |              |                      |                     |              | 1 No. @ course 32   |              |
| 5            | 1            | 0.4          | 0.075        | 0.15                 | 2                   | nan          | 4 No. @ course 34   | nan          |
|              |              |              |              |                      |                     |              | 1 No. @ course 30   |              |
| nan          | nan          | nan          | nan          | 1.0960151249999996   | 14.415534999999998  | nan          | nan                 | nan          |
| nan          | nan          | nan          | nan          | 2630.436299999999    | nan                 | nan          | nan                 | nan          |
| nan          | height 303   | nan          | height 332   | nan                  | nan                 | nan          | nan                 | nan          |
| nan          | course 23    | revision     | course 32    | revision             | nan                 | nan          | nan                 | nan          |
| nan          | 865          | nan          | 980          | nan                  | nan                 | nan          | nan                 | nan          |
| nan          | 962          | nan          | 795          | nan                  | nan                 | nan          | nan                 | nan          |
| nan          | 815          | nan          | 1064         | nan                  | nan                 | nan          | nan                 | nan          |
| nan          | 838          | nan          | 772          | nan                  | nan                 | nan          | nan                 | nan          |
| nan          | 738          | 796          | nan          | nan                  | nan                 | nan          | nan                 | nan          |
| nan          | 504          | nan          | nan          | nan                  | nan                 | nan          | nan                 | nan          |
| nan          | 556          | 498          | nan          | nan                  | nan                 | nan          | nan                 | nan          |
| nan          | 865          | nan          | nan          | nan                  | nan                 | nan          | nan                 | nan          |
| nan          | 6143         | nan          | nan          | nan                  | nan                 | nan          | nan                 | nan          |
| nan          | height 399   | height 376   | height 372   | nan                  | height 384          | nan          | height 374          | nan          |
| nan          | course 34    | course 22    | course 29    | rev                  | course 30           | rev          | course 40           | rev          |
| nan          | 757          | 890          | 1052         | nan                  | 750                 | 740          | 892                 | nan          |
| nan          | 446          | 868          | 909          | 900                  | 1095                | 450          | 960                 | nan          |
| nan          | 539          | 566          | 545          | 554                  | nan                 | 645          | 972                 | nan          |
| nan          | 931          | 486          | 546          | nan                  | 867                 | nan          | 459                 | 469          |
| nan          | 905          | 912          | 880          | nan                  | 889                 | nan          | 748                 | 738          |
| nan          | nan          | nan          | 909          | nan                  | nan                 | nan          | 799                 | nan          |
| nan          | nan          | nan          | nan          | nan                  | nan                 | nan          | 692                 | nan          |
| nan          | height 489   | nan          | nan          | height 459           | height 454          | height 456   | nan                 | nan          |
| nan          | course 18    | revised      | nan          | course 20            | course 19           | course 35    | nan                 | nan          |
| nan          | 934          | 1134         | nan          | 794                  | 909                 | 777          | nan                 | nan          |
| nan          | 645          | 545          | combined     | 997                  | 828                 | 1049         | nan                 | nan          |
| nan          | 859          | 759          | nan          | 482                  | 705                 | 435          | nan                 | nan          |
| nan          | 651          | 1100         | nan          | 1278                 | 891                 | 606          | nan                 | nan          |
| nan          | 449          | nan          | nan          | nan                  | 780                 | 623          | nan                 | nan          |
| nan          | 840          | combined     | nan          | nan                  | 788                 | 843          | nan                 | nan          |
| nan          | 546          | nan          | nan          | nan                  | nan                 | nan          | nan                 | nan          |

---

## Sheet: Sheet2
| Unnamed: 0                    | time              | man 1   | man 2   |
|:------------------------------|:------------------|:--------|:--------|
| determine good sides          | 1 min             | x       | nan     |
| measure from ticket snd mark  | 2 mins            | x       | nan     |
| handle onto saw against guard | 2 mins            | x       | x       |
| cut                           | 4 mins            | nan     | x       |
| clean                         | .5mins            | nan     | x       |
| remove discard stone          | .5 mins           | nan     | x       |
| measure from ticket and mark  | 2 mins            | x       | nan     |
| place against guard           | .5 mins           | x       | x       |
| cut                           | 4 mins            | nan     | x       |
| clean remove discard stone    | .5 mins           | nan     | x       |
| label                         | .5mins            | x       | nan     |
| move to tray                  | 1 min             | x       | x       |
| nan                           | 20                | nan     | nan     |
| nan                           | 20                | nan     | nan     |
| nan                           | 400               | nan     | nan     |
| nan                           | 6.666666666666667 | nan     | nan     |

---
