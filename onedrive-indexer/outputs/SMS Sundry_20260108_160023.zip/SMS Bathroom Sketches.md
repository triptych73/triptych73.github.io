# Source: SMS Bathroom Sketches.pdf
**Path:** `SMS Bathroom Sketches.pdf`
---

### Page 1

[IMAGE CONTENT - REQUIRES OCR]