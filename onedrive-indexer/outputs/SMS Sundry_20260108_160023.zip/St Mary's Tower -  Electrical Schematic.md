# Source: St Mary's Tower -  Electrical Schematic.pdf
**Path:** `St Mary's Tower -  Electrical Schematic.pdf`
---

### Page 1

DUCT IN STEEL
Load Rat CU φ Div D%Radial MainDome lightChandelierB32B6B61111 322.42.41004040
\\
PumpSprinkler elecEmergency lightWet U/F PumpB10B6B6B6111111114.02.42.42.440404040OvenFridgeHobDishwasherRing mainB20B6B32B16B32111111111182.412.86.43240404040100Lights –spotsLights under cabB6B611112.42.44040Lights spot (hi)Ring (extractor, rail)Electric U/FB6B32B161111112.412.86.4404040Radial main (low)UplightersDownlightersB32B6B6333111322.42.41004040Fire panel B6 DB 3 2.4 40Radial mainLiftLightingBoilerImmersionB32C32B6B6B163DB3331A111322.42.46.410040404040
 L1 (Kitchen) CU3φ Main Distrib. UnitL3 (Plant) CU3φ SWITCH3φ METER CAB
FIRE PANEL
PUMP
LIFT
BOILER66L1L2L3
5345WCKITCHENETTE1UNDER LIFT SHAFTPOEENTRANCEPLANTRECEPTION11
WALL PENETRATION2 7812345678 4 CORE 25-SWA16-CPC4 CORE 25-SWA16-CPC10-FLEX4 CORE 25-SWA 16-CPC3 CORE 10-SWA3 CORE 10-SWA4 CORE16-SWA 16-CPCL4L6+L61.1 Electrical Schematic L1 – L3DUCT L4 FLOOR
DUCT L1 FLOOR
R11
R12
R12
R12
R12
R21
R21
R31
GR0

### Page 2

Slide 2
GR0 
L1 (Kitchen) CU partially installed
L3 (Plant) CU, in but not populated
L3 Main DB installed
L6 (Utility) CU not installed
L4 (Lighting) DB not installed
SWA cabling all run
Much T&E cabling yet to be run
Gregory Renwick, 2021-11-27T15:50:36.833

### Page 3

L4L5L6
BEDROOML4 BedroomCU
1RECEPTIONLOBBY2211
BEDROOM
LOBBY54477CEILING VOID
PLANTL1L3
`L6 (Living) CULIVING
WALL PENTRATION
HEAT X
566ENSUITEUTILITYLOBBY
33ENSUITELoad Rat CU φ Div D%RingSpotsWall lightB32B6B6444222322.42.41004040SpotsuplightersB6B633112.42.44040SpotsRing (extractor, rail..)Electric U/FB6B32B163331112.4326.44010040RadialSpotsWall lightB32B6B6444???322.42.41004040SpotsVanity lightB6B633332.42.44040SpotsRadial (extractor, rail)Electric U/FB6B32B163333332.4326.44010040SpotsUplightersB6B633332.42.44040Lights spot (hi)Radial (extract, w/d)Electric U/FB6B32B163333332.4326.44010040Heat exchanger B6 3 3 2.4 40
12345678 89
9
1.2 Electrical Schematic L4 – L6
DUCT L4 FLOOR
NOT IN SCOPE
R41
R42
R43
R51
R52
R53
R62
R63
R64