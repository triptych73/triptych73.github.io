# Source: arc for step.pdf
**Path:** `arc for step.pdf`
---

### Page 1

[IMAGE CONTENT - REQUIRES OCR]