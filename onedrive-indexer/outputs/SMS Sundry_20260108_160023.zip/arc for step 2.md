# Source: arc for step 2.pdf
**Path:** `arc for step 2.pdf`
---

### Page 1

[IMAGE CONTENT - REQUIRES OCR]