# Source: Cadent Cheque to STMS Ltd - £1020.00.pdf
**Path:** `Cadent Cheque to STMS Ltd - £1020.00.pdf`
---

### Page 1

Barclav Cadent
20-00-00
Lot-don E 14 SHP
27.10.2020PAY DATE
AMOUNT OF POUNDS IN WORDS
,020.oo
For and on behalf of Cadent Gas Lrruted
2011100001:
