# Source: 5 Lambeth Hill - Vent Plans and Part F Draft.pdf
**Path:** `5 Lambeth Hill - Vent Plans and Part F Draft.pdf`
---

### Page 1

2 m
八刀
3 m
:RISER
RISER
11V신` NI
3 m
0)乍


### Page 2

4
Part 1 — System details and declarations
The installer should complete this section and include details of the corrrnissioning engineer.
U &tails
Dwelling name/number
Street
Town
County
1-2
System classification*
Enter 'natural ventilation', •mechanical extract ventilation' or •as defined by Approved Document F'.
Manufacturer
Model numbers
Serial number (where avaiWe)
Location of fan cnits
3.
4.
5.
6.
7.
1.3 details
rawv.-.•Engineers name
Set T
Address line 1
Address line 2
Postcode
Telephorr number
L4 engiie«'s details (if different to 1.3)
Engineer's name
Cornpany
Address line 1
Address line 2
Postcode
Telephone number
Email address
*NOTE: If a system has been installed that is not defined in Approved Document F, further installation checks and
commissioning procedures may be required. Seek guidance from the manufacturer for such systems.
Building Regulations 2010 Approved Doctznent F Volume 1, 2021 edition 43


### Page 3

Part 2a — Installation details
The &btaller Judd conVete ttüs section before cornmissionirw is carried
(all
Has in accordance with the manufacturerk
1.12 to 1.830 been followed (if relevant)?
If there are
deviatic»s from
paragraphs 1.12 to 1.83.
give details here
Description of
controls (e.g. timer,
central control.
humidistat. occupancy
sensor. thermal
if applicable, etc.)
Location of manual/
overri& controls
la-2 dedu•ation
Engineers signature
nunber (if
applicable)
Date of inspection
l. All references to tables md gxmagraphs are to Approved Document h, Volume l: Vwellings.
44 Approved Docunent F Volume I, 2021 edition


### Page 4

Part 2b — Inspection of installation
The corrvnissiming engineer should complete this section before completing Part 3.
— Feral (all systens)
What is the total installed ecuivalent area of background ventilators in the dwelling?
What is the total floor area of the dwelling? 400
Does the total installed equivalent ventilator area rneet the standards detailed in Table 1.7 Yes
or paragraph 1.570), as appropriate?
Have all background ventilators been left in the open position?
Have the correct nurnber and location of extract fans/ terminals been installed to satisfy
the standards in Table 1.1 or Table 1.2, as appropriate?
Is the installation complete. with no obvious defects? Yes
Do all intemal doors have enough undercut to allow air transfer between rooms as
detailed in paragraph 1.25 Cie. 10mm above the floor finish or 20mm above the floor
surface)?
Has all protection/packaging been removed (including from background ventilators), so
that the system is fully functional?
Are systems clean internally and extemally? Yes
Has the entire system been installed to allow access for routine maintenance and to
repü/replace components?
rnm•
No
No
No
2b.2 mechanical extract ventilation md mechaical æntilation with heat
æco•y systens
appropriate air terminal devices been installed to allow system balance?
Have the heat recovery unit and all ductwork been effectively insulated and sealed for all
heated and unheated spaces?
Is the condensate connection complete and does the condensate drain to an appropriate
location (mechanical vatilation with heat recovery only)?
Are filters installed?
For ducted systems, has the ductwork been installed so that air resistance and leakage is
kept to a minimcrn?
2b.3 Other ispectiotB— æneral (all systans)
At initial start-up, was there any abnormal sound or vibration, or unusual smelt?
During continuous operation was there any excessive noise?
NOTE
Yes
Yes
Yes
Yes
Yes
No
No
No V/
No
No
No
No
l. All references to tables and paragraphs are to Approved Document F, Volume l: Dwellings.
L-owek
20 
4R31
DOA)
vvl
000
Building Regulations 2010
(VI V H
o
Approved Docunent F Volume I, 2021 edition 45


### Page 5

Part 3 — Commissioning details
The comrnissioning engineer should complete this section after completing Part 2b.
3.1 re,
3.1 N
Schedule of air flow rneasLrement equipment used (model and serial number) Date of last UKAS calibration
3.
3.2 flow measurenents — intermittent extract fans only
Fan reference (from section 1.2 above) Measured extract rate (l/s) Design 
Refer to 
extract 
Table 1.10)
rate (IVs)
Extract fan I RI 2- o
Extract fan 2
Extract fan 3
Extract fan 4
For cooker hoods, only the highest setting needs to be recorded
3.3 meas•ranalts (extract) — contiwous mechanical extract vafiilation and mechanical ventilation with
Room reference Measured air flow — Design air flow — high Measured air flow —
(location of terminals) high rate (l/s) rate (IVs) continuous rate (l/s)
Refer to Table ID
Kitchen
Bathroom
En suite
utility
Other
3.4 Air Row (qpply) — mechmical with heat recovery only
Room reference Measured air flow — Design air flow — high Measured air flow —
(location of terminals) high rate (Vs) rate (l/s) continuous rate (IVs)
Refer to Table 1.2
Living room I
Living room 2
Dining room
Bedroom I R14
Bedroom 2
Bedroom 3
Bedroom 4
Bedroom 5
Study
Other
3.5 engü•eer's declaration
Engineer' signature
Registration number (if applicable)
Date of commissioning
NOTE
J. All references to tables and paragraphs are to Approved Document F, Volume l: Dwellings.
Design air flow —
continuous rate (l/s) a-SC (s
Refer to Table 1.3
Design air flow —
continuous rate (Vs)
Refer to Table 1.3
46 Doctznent F Vol•m.e I, 2021 edition Building Regulations 2010


### Page 6

Table DI Checklist for ventilation provision existing dwellings
Natural ventilatvon-
What is the total equrvalent area of backgroa.nd ventilators currently in dwelling?
Does each habitable room satisfy the minimun equivalent area stardards in Table 1.72?
Have all background ventilators been left in the open position?
Are fans and backgromd in tt-e same room at least 0.5m apart?
Are there working extract fans in all wet roorns?
Is there correct nu•nber of intermittent extract fans to satisfy the standards in Table 1.1?
Does the location of fans satisfy the standards in paragraph 120?
Do all automatic controls have a manual override?
D-cys each room have a system for purge ventilation (eg. windows)?
Do the openings in the rooms satisfy the mintrrum opening area standards in Table 1.4?
Do all intemal doors have suffcient urdercut to allow atr transfer between rooms as detailed
in paragraph' 1.25 (Le- IOrnm above the floor finish or 20rnrn above the floor surface)?
Continuous mechanical extract ventilationn
töe system have a central extract fan. individual room extract fans, or both?
Does the total combined continuous rate cf mechanical extract ventilation satisfy the
standards in Table 1-3?
Does each minimum mechanical extract ventilation high rate satisfy the
Is it certain that there are no background ventilators in wet r
DO al I F±itable roams have a rnnrrurn equival ea of 5000mm2?
Does each room have a systan for ventilation (eg. windows)?
s in Table 1.2?
Do the openings in the satisfy the minnum opening area standards in Table 1.4?
Do all int have sufficient undercut to allow air transfer between rooms as detailed
1.25 (Le- K)rnrn above the floor finish or 20rnrn above the tloor surface)?
Mechanical ventilation with heat recoveryz
Doe eæh habitable room have mechanical supply ventilation?
Does the total continuous rate of mechanical ventilation with heat recovery satisfy the
standards in Table 1.3?
Does each munirnurn rnechanical extract ventilation high rate satisfy the standards tn Table 1-2?
Have all background ventilators been removed or sealed shut?
Dæs each room have a systan for purge ventilation (e.g. wrndæ.•s)?
Do the openings in the rooms satisfy the minirrurn openrng area standards in Table IA?
Yes
Yes
Yes
Yes
Yes
Yes /Ä
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
mm2
No
No
No
No
No
No
No
No
No
No
No
No
No
No
Do all internal have sufficient urdercut to allow air transfer between rooms as detailed
in paragraph 125 (Le- 10rnrn above the floor finish or 20rrrn above the floor surface)?
1. t•.4ake a visual deck 
advice-
for rnodd or If either are install additmal ventilation provisions or
seek speaaiist 
Z All references to tables paragraphs are to Approved Document F. Volurne 1: Dwellrv.
F 1, 2021
48
Regt-Aatkns 2010


### Page 7

Table DI GecHist for ventilation provision in existing dwellings
Natural vent d attorn
is the total equrvalent area of backgrocnd ventilators currently in dwelling? mm
Does each habitable room satisfy the minimum equivalent area standards in Table 1.72'?
Have ail background ventilators been left in the open position?
Are fans and backgromd ventilators in the same room at least 0.5m apart?
Are there ötennittent extract fans in all wet rooms?
Is there corect of intermittent extract fans to satisfy the standards in Table 1.1?
Does the location of fans satisfy the standards in paragraph 1.20?
Do all automatic controls have a manual override?
Does each roeyn have a system for purge ventilation (e.g. windows)?
00 tse in the rooms satisfy the minimum opening area standards in Table 1.4?
Do ali internal doors have sufficient undercut to allow air transfer between rooms as detailed
in paragraph IQS (i.e. 10mm above the floor finish or 20mm above the floor surface)?
Continuous mechanical extract ventilation a
Does the system' have a central extract fan, individual room extract fans. or both?
Does the total combined continuous rate of mechanical extract ventilation satisfy the
Yes
Yes
Yes
Yes
Yes
Yes
Yes //
standards in Table 1.3?
Does each minimum mechanical extract ventilation high rate satisfy the s
is it certain that there are no background ventilators in wet r
Do all habitable rooms have a minrnum equivale ea of 5000mm Z?
Do€3 each room have a systern for ventilation (e.g. windows)?
s in Table 1.2?
Do the opentngs tn the satisfy the minimum opening area standards in Table 1.4?
Do all inte have sufficient undercut to allow air transfer between rooms as detailed
in 1.25 (i.e. 10mm above the floor finish or 20mm above the floor surface)?
Mechanical ventilation with heat recovery(V
Does each habitable room have mechanical supply ventilation?
Does the total continuous rate of mechanical ventilation with heat recovery satisfy the
standards in Table 1.3?
Does each minimurn extract ventilation high rate satisfy the standards in Table 1.2?
Have all background ventilators been removed or sealed shut?
Does each room have a systan for purge ventilation (e.g. windows)?
Do the openings in the rooms satisfy the minimum opening area standards in Table 1.4?
Do all internal doors have sufficient undercut to allow air transfer between rooms as detailed
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes 
Yes
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
Yes 
Yes 
Yes
v'/ No
V/ No
No
in paragraph 1.25 (i.e. 10mm above the floor finish or 20mm above the floor surface)?
I. a visual check for rnouldor condensation. If either are present, install additional ventilation provisions or
seek specialist advice.
Z All réererces to tables and paragraphs are to Approved Document F. Volume 1: Dwellings.
F I, 2021 eation Bülding Regulations 2010
48
