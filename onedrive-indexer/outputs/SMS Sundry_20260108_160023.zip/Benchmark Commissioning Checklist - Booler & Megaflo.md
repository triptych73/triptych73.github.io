# Source: Benchmark Commissioning Checklist - Booler & Megaflo.pdf
**Path:** `Benchmark Commissioning Checklist - Booler & Megaflo.pdf`
---

### Page 1

ecoTEC plus 630 VU 306/5-5 H-GB Rd
GAS BOILER SYSTEM COMMISSIONING CHECKLIST & WARRANTY VALIDATIOr 21182700100218331300208611N2
a¯ch.JEZ. 4.AC;—
$33
CO CIS
CENTRAL '€ATNG
ORB 3.
COSENATON ONLY
Wt•.at
EZod7
WATER
has been at
CO'O€N?-ATE ocspos.u
INsv.LLAno«s
At
pos'..bto) CO
ct»c.l wzh
TH.i ard try
(To rd E&ratve)
• rd&d (LAOC) 
Penme
(HifIC)
0020244997_06 ecoTEC plus Installation and maintenance instructions
Gas
Not
toq.nred
e-v3 Yes
0
NCA
Yes
Yes
Not
•c
Yes •c
• 2- COCO
• Z- COCO
Yes
&0Ctiy a
enchmar
73


### Page 2

SERVICE & INTERIM BOILER WORK RECORDIt is that your heating system are serviced and maintained. in !ine with manufacturers' instnrtions. and that the appropriate serviceinterim record is
Service
*'he n corroebng a service record (as bek'w). please ensure have cari«j out the service as descrit—i in the manufacturers' instructöns. Always use themanufacturers' spare
SERVICEJINTERVM WORK ON BOILER SERVICE"NTERiM WORK ON BOILER Date:
Eng.neer rwne:
Gas Sa'e 
Max CO % 
Min rate CO CO' •s 
Where has a
undoro€en accmiance with marofac:furers•
instructons. are
Gas
Pans
Sy•stem concentratkM
actKV' t*en. in BS 7593
arÉ manufacturers' •
Gas Sato registratön N':
rate CO
Min rate CO
ppm CO, % 
CO. % 
Where 'X)ssible. has a nue been
un&'rtakm in accodanco with manufæturers •
hs tructk»ns . and ate cryrect?•
Gas rate:
parts 
Parts fitted
System 
Yes
has been checked and
BS
Max rate CO
Msn rate CO
WORK ON BOILER 
Ca•npany name.'
Gas 
ppm CO. •s 
CO, % 
apsvopriate taken. in accudance with BS 7593
ary' manufacturers  • •
•A Sysu•m
was to a
SERVICE,'INTERIM WORK ON BOILER 
Tek•phone
Max rato " CO
rate CO
Gas 
ppm CO.
CO,
W*em has a flue
in with manufacturers '
readings
has tx»n and
apprtvi•te taken. in •:codanco With BS 7 S93
marvtacttr«s• •
SERVICE.nNTERiM WORK ON BOILER 
N'
coco,
COCO.
NO
Date:
NE,
COCO,
coco,
Date:
Engineer name: Company name:
Where has a check
undertaken in accordance With
instructims, correct?
Gas rate:
Were parts 
Parts fitted:
Yes
System inhibior cmcentratbn has been
% 
% 
apv%'nate taken. in accordance With BS 7593
and bOIcr manu'acturets' ins tructkyns . •
SERVICE'INTERIM WORK ON BOILER 
COCO,
coco,
No
Date:
N':
COCO.
coco.
Date:
Canpany
Gas Sate registration
Max r" CO com co. % COCO,
Mm CO Ll_C9' % COCO,
has a check
in with
Gas rate mum IOR
Pans
has and
BS 7593
• A 
Engineer
Telephone N':
CO
CO
Cornpany name:
Gas Safe registratOn NE.
•s COCO.
% cocoa
has a chea
undertaken in 
and 
Gas rate:
parts hued:
System 
(LABC) 
then to
with manufacturers  •
are curect?•
Yes NO
has
accÜdarre BS 7593
"stu:txyts. •
a nchmar
J0dusVy (HHiC)
CO
74 Installation and maintenance instructions ecoTEC Plus 0020244997_06


### Page 3

MAINS PRESSURE HOT WATER STORAGE SYSTEM COMMISSIONING CHECKLIST
This Commissioning Checklist is to be completed in full by the Competent person who commissioned the storage system as a means Of
demonstrating compliance with the appropnate Building Regu'ations and then handed to the customer to keep for future reference.
Failure to instan and commission this equipment to the manufacturer's instructions may invalidate the warranty but does not affect statutory rights.
Customer Name telephone Number
Address
Cylinder Make and
Cylinder Serial Number A
Commissioned by name' S Registered Operanvo 10 Number
Telephone Number
Company Address
Commissioning Date
To be corns*eted by the customer on receipt Of a Building Regulations Compliance Certificato•:
Build•ng Fequ'ations  Notification Number (it applicable)
ALL SYSTEMS PRIMARY SETTINGS (indirect heating
Is the prima C•rcuit a sealed open vented system?
What is the maximum flaw temperature?
• zozz
ALL SYSTEMS
V•Vhat is tne incom static cold 
Has a stravner been cleaned of 
pressure at the inlet to the s tern?
ciebns fif fitted)?
Is the installation in a water area (above ?
has a water scale 'educer been fitted?
What type o' scale reducer has been t•tted7
What s hot water thermosta' lure?
Wnat is the mau'rnum hot wate' flow rate at set thermostat tempe•alure measured at hi
Time and t controls havo been fitted •n comp'iance with Part L Of the Buildin
h flow outlet)?
R uLMons?
Yes
Yes
T of control tom app"cable)
Is the cylinder solar COT Other renewable) compatible?
What the Water at the nearest outlet?
S Plan
Yes
All appropriate p•pes havo been 'nsulated up to metre or the point where they become concealed
UNVENTED SYSTEMS ONLY
Where ts the pressure reduci valve situated fitted)?
"VBat is the pressure reduci valve sottin 7
Has a combined temperature and ure relie' valve and enpans•on valve been fitted and discha e tested?
The 'undiSh and e have been Cann•xted and tenninatod to Part G Of tho Bu"d R ulations
Are ail SOMce-s with a out de."ce?
Has me e.oansion vessel or intetnaj air space been checked?
THERMAL STORES ONLY
What store temperature IS ach•evable?
What is the ma•imum hot water temperature?
ALL INSTALLATIONS
hot water s tern com With ate Budd u/a%ons
No
60
Other
3
No
Yes
No
Yes
bar
•c
Vrn/n
bar
s stem been insta)led anc commissioned acccrCanco with 'ho manufacturer's .nstructions
Th. s stem controls havo been demonstrated to and understood the customer
The manufacturers including Benchrnwk Checklist nr,d Service Record. has been explained and lett w.th the customer
Commissioning Enginee"s Signature
Customer's Svona'utO
in must Authc.nty 
then 'g toe
OHea0ng and Industry Council (HHiC)
34
ß_ABC) through a Competent Scheme.
enchmar
