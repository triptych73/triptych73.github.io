# Source: To do list for steel.docx
**Path:** `To do list for steel.docx`
---

St Mary Somerset – Steel Remaining Work and Snagging

Correct S-W slant, loosening bolts if necessary (1-3 hours)

(Rechecked plumb of the columns and they are quite a bit out… Whole structure at the higher level (above bottom column level) seems to be leaning a fair bit to the South and West. Possible this happened while the bolts were being tightened (done in the wrong order?), since everything seemed to be fine when checked near the end of the last day. I have held off concreting in as a result)

Bring up and install cross-beam at roof level (60 mins)

Replace welded studs with bolts on order by Simon (1 hour)

Finish spot welding beams to columns where no allowance was made for bolts, or bolt where bolts missing. (1 hour)

Make corrections to steels of lift shaft, incl cross braces (6-10 hours)

Ensure all Steels in pockets have suitable retaining studs or welded plates in place (90 mins)

Ensure beams all square, level and plumb and in line (string line), adjust as necessary (1 hour)

Further retain structure to tower wall as necessary to keep in position (1-2 hours)

Tighten all bolts (2 hour)

Ensure all still square, level and plumb, adjust as necessary (30-60 mins)

Paint over all welds and also over cutouts where the design was wrong (2 hours)

Cam fix base of columns (2-4 hours)

Cam fix blockwork base beams into retaining wall (1 hour)

Cut off all temporary plates and make good (1 hour)

Tidy and remove spare materials (1 hour)

Total: 23.5-33 man hours.