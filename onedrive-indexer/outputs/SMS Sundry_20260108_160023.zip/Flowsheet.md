# Source: Flowsheet.pdf
**Path:** `Flowsheet.pdf`
---

### Page 1

Patient RENWICK GREGORY HUGH
Flowsheet Print Request
MRN: 6354474 Printed by: Oladele-Abidakun , Abimbola Olabimpe
Last 500 Results
Lab View 05/Aug/2020
General Haematoiogy
Haemoglobin
White Blood Count
Platelet Count
Haematocrit
Red Blood Count
Mean Cell Volume
11:08 BST
138 g/L
L 3.3 xlO A 9/L
327 xlO A 9/L
0.41
4.58 XlO A 12/L
88.9 fL
Red Blood Cell Distribution Width 12.1 %
Mean Cell Haemoglobin ' 30.1 pg
04/Aug/2020
08:10 BST
132 g/L
,4.6 xlO A 9/L
284 xlO A 9/L
0.39
L 4.33 XlO A 12/L
89.6 fL
12.0 %
30.5 pg
Mean Cell Haemoglobin Concentration 339 g/L
Neutrophil Count L 1.5 xlO A 9/L
• Lymphocyte Count 1.4 xlO A 9/L
Monocyte Count 0.3 xlO A 9/L
Eosinophil Count 0.2 xlO A 9/L
Basophil Count 0.0 xlO A 9/L
r ' Nucleated Red Blood Cell Count 0.0 xlO A 9/L
Reticulocyte Count
Reticulocyte Count %
Erythrocyte Sedimentation Rate
Immature Granulocytes 0.0 xlO A 9/L
340 g/L
3.2 xlO A 9/L
1.0 xlO A 9/L
0.4 xlO A 9/L
'0.0 xlO A 9/L
0.0 xlO A 9/L
0.0 xlO A 9/L
Coagulation
Prothrombin Time
PTR / INR
Activated Partial Thromboplastin Time
APTT Ratio
Haematinics
Ferritin Serum
Vitamin B12 Serum
Folate Serum
General Biochemistry
Sodium Serum
Potassium Serum
Chloride Serum
Urea Serum
Creatinine Serum
estimated GFR
138 mmoI/L
. 3.9 mmol/L
101 mmol/L
2.9 mmol/L
71 umol/L
• mL/min
" 138 mmoI/L
4.1 mmol/L
104 mmol/L
L 2.4 mmol/L
68 umol/L
(C) mL/min
Printed on: 05 Au /2020 14 44 EST
03/Aug/2020 03/Aug/2020
18:17 BST 16:39 BST
Total Bilirubin Serum
Alanine Aminotransferase Serum
Alkajine Phosphatase Serum
10 umol/L
H 59 unit/L
73 unit/L
H 22 umol/L
OH 63 unit/L
64 unit/L
Gemma•gjutamyl Transpeptidase Serum
D Total Protein Serum
Albumin Serum
Calcium Serum
Adjusted Calcium Serum
Inorganic Phosphate Serum
72 g/L
41 g/L
2.42 mmoI/L
2.40 mmol/L
0.86 mmoj/L
65 g/L
40 g/L
C-Reactive Protein Serum
Lactate Dehydrogenase Serum
Magnesium Serum
r Urate Serum
Endocrinology
Free T4 Serum
Th roid Stimulatin Hormone Serum
H 159 mg/L
0.9 mmol/L
Page 1
