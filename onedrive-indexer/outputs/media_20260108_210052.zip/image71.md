# Source: image71.jpeg [IMAGE]
**Path:** `image71.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']