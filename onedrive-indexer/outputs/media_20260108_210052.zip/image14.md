# Source: image14.jpeg [IMAGE]
**Path:** `image14.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']