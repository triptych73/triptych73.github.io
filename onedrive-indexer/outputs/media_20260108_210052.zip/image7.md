# Source: image7.jpeg [IMAGE]
**Path:** `image7.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']