# Source: image16.jpeg [IMAGE]
**Path:** `image16.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']