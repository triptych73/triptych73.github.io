# Source: image57.jpeg [IMAGE]
**Path:** `image57.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']