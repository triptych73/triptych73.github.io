# Source: image32.png [IMAGE]
**Path:** `image32.png`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']