# Source: image50.jpeg [IMAGE]
**Path:** `image50.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']