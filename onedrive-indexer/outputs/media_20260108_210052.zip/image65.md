# Source: image65.png [IMAGE]
**Path:** `image65.png`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']