# Source: image75.jpeg [IMAGE]
**Path:** `image75.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']