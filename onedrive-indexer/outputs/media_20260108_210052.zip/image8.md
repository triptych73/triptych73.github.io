# Source: image8.jpeg [IMAGE]
**Path:** `image8.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']