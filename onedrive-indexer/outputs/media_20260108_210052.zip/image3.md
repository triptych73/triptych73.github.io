# Source: image3.jpeg [IMAGE]
**Path:** `image3.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']