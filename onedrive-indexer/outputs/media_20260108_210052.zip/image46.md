# Source: image46.jpeg [IMAGE]
**Path:** `image46.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']