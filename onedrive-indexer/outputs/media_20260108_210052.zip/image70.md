# Source: image70.jpeg [IMAGE]
**Path:** `image70.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']