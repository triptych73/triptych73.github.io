# Source: image11.jpeg [IMAGE]
**Path:** `image11.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']