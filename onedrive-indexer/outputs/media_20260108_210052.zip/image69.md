# Source: image69.jpeg [IMAGE]
**Path:** `image69.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']