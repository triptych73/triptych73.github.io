# Source: image44.jpeg [IMAGE]
**Path:** `image44.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']