# Source: image40.jpeg [IMAGE]
**Path:** `image40.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']