# Source: image9.jpeg [IMAGE]
**Path:** `image9.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']