# Source: image78.jpeg [IMAGE]
**Path:** `image78.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']