# Source: image59.jpeg [IMAGE]
**Path:** `image59.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']