# Source: image4.jpeg [IMAGE]
**Path:** `image4.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']