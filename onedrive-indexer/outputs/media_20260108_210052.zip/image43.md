# Source: image43.jpeg [IMAGE]
**Path:** `image43.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']