# Source: image5.jpeg [IMAGE]
**Path:** `image5.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']