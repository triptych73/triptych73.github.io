# Source: image39.jpeg [IMAGE]
**Path:** `image39.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']