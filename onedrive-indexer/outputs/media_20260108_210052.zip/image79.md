# Source: image79.png [IMAGE]
**Path:** `image79.png`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']