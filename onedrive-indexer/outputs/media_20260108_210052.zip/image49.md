# Source: image49.jpeg [IMAGE]
**Path:** `image49.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']