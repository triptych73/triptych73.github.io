# Source: image74.jpeg [IMAGE]
**Path:** `image74.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']