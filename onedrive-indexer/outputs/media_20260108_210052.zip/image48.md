# Source: image48.jpeg [IMAGE]
**Path:** `image48.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']