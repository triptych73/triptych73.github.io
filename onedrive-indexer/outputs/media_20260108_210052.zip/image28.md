# Source: image28.jpeg [IMAGE]
**Path:** `image28.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']