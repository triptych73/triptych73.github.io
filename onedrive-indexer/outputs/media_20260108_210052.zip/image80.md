# Source: image80.jpeg [IMAGE]
**Path:** `image80.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']