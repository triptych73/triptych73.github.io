# Source: image81.jpeg [IMAGE]
**Path:** `image81.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']