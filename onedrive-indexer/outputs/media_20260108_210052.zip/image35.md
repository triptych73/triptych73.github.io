# Source: image35.jpeg [IMAGE]
**Path:** `image35.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']