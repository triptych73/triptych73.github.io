# Source: image2.jpeg [IMAGE]
**Path:** `image2.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']