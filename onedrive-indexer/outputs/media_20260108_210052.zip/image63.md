# Source: image63.jpeg [IMAGE]
**Path:** `image63.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']