# Source: image61.jpeg [IMAGE]
**Path:** `image61.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']