# Source: image34.jpeg [IMAGE]
**Path:** `image34.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']