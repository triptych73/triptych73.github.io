# Source: image1.jpeg [IMAGE]
**Path:** `image1.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']