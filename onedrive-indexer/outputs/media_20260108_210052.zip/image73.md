# Source: image73.jpeg [IMAGE]
**Path:** `image73.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']