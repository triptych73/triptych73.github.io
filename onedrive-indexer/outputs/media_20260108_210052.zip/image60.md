# Source: image60.jpeg [IMAGE]
**Path:** `image60.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']