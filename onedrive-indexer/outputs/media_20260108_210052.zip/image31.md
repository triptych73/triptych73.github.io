# Source: image31.jpeg [IMAGE]
**Path:** `image31.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']