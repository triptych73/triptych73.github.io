# Source: image27.jpeg [IMAGE]
**Path:** `image27.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']