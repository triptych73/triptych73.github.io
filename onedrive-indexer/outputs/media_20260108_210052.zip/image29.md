# Source: image29.jpeg [IMAGE]
**Path:** `image29.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']