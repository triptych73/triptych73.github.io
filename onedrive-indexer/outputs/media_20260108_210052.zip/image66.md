# Source: image66.jpeg [IMAGE]
**Path:** `image66.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']