# Source: image18.jpeg [IMAGE]
**Path:** `image18.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']