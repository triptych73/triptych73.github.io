# Source: image17.png [IMAGE]
**Path:** `image17.png`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']