# Source: image64.jpeg [IMAGE]
**Path:** `image64.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']