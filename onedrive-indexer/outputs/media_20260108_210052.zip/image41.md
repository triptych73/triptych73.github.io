# Source: image41.jpeg [IMAGE]
**Path:** `image41.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']