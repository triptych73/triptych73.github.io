# Source: image62.jpeg [IMAGE]
**Path:** `image62.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']