# Source: image56.jpeg [IMAGE]
**Path:** `image56.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']