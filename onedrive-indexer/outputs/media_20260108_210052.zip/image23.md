# Source: image23.jpeg [IMAGE]
**Path:** `image23.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']