# Source: image67.jpeg [IMAGE]
**Path:** `image67.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']