# Source: image19.jpeg [IMAGE]
**Path:** `image19.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']