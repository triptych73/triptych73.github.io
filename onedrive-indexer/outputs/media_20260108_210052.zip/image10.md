# Source: image10.jpeg [IMAGE]
**Path:** `image10.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']