# Source: image26.jpeg [IMAGE]
**Path:** `image26.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']