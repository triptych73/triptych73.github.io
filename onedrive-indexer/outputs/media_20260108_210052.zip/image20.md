# Source: image20.jpeg [IMAGE]
**Path:** `image20.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']