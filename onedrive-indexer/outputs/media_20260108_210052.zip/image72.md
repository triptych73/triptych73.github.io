# Source: image72.jpeg [IMAGE]
**Path:** `image72.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']