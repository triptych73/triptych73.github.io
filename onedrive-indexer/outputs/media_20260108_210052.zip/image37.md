# Source: image37.tiff [IMAGE]
**Path:** `image37.tiff`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']