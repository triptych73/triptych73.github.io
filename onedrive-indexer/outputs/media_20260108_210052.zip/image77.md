# Source: image77.jpeg [IMAGE]
**Path:** `image77.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']