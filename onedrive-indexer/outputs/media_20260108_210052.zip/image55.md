# Source: image55.jpeg [IMAGE]
**Path:** `image55.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']