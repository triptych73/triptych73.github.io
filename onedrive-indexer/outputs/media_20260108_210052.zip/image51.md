# Source: image51.jpeg [IMAGE]
**Path:** `image51.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']