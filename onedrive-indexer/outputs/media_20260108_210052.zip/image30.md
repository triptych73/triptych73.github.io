# Source: image30.jpeg [IMAGE]
**Path:** `image30.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']