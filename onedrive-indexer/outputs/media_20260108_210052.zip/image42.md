# Source: image42.jpeg [IMAGE]
**Path:** `image42.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']