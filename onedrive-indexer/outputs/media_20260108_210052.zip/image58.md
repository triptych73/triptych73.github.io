# Source: image58.jpeg [IMAGE]
**Path:** `image58.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']