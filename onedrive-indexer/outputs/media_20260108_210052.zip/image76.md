# Source: image76.jpeg [IMAGE]
**Path:** `image76.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']