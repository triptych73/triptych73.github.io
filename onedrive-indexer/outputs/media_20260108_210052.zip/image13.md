# Source: image13.jpeg [IMAGE]
**Path:** `image13.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']