# Source: image22.jpeg [IMAGE]
**Path:** `image22.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']