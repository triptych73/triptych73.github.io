# Source: image52.jpeg [IMAGE]
**Path:** `image52.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']