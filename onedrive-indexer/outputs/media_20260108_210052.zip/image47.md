# Source: image47.jpeg [IMAGE]
**Path:** `image47.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']