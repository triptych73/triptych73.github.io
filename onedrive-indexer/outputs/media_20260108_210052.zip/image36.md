# Source: image36.jpg [IMAGE]
**Path:** `image36.jpg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']