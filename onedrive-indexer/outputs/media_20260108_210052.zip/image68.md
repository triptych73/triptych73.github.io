# Source: image68.jpeg [IMAGE]
**Path:** `image68.jpeg`
---

[Error calling Google: 'NoneType' object has no attribute 'configure']